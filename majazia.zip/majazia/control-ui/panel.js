'use strict';
/* مجازية — لوحة المؤسس (قسم سري منفصل) */
(() => {
  const $ = (s, el = document) => el.querySelector(s);
  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'style') el.style.cssText = v;
      else if (k in el && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(9)) if (c != null && c !== false) el.append(c instanceof Node ? c : document.createTextNode(String(c)));
    return el;
  }
  function toast(m, err) { const el = h('div', { class: 'toast' + (err ? ' err' : ''), text: m }); $('#toasts').append(el); setTimeout(() => el.remove(), 3500); }
  const BASE = location.pathname.replace(/\/+$/, '');
  async function api(path, body) {
    const opt = { credentials: 'same-origin', headers: { 'X-Majazia': '1' } };
    if (body !== undefined) { opt.method = 'POST'; opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
    const r = await fetch(BASE + path.replace('/api/admin/', '/api/'), opt);
    if (r.status === 401 && !path.endsWith('/login')) { showLogin(); throw Object.assign(new Error('login_required'), { code: 'login_required' }); }
    let d = null; try { d = await r.json(); } catch { /* */ }
    if (!r.ok) { const e = new Error((d && d.error) || 'error'); e.code = e.message; throw e; }
    return d;
  }
  const ERR = { forbidden: 'غير مسموح', not_found: 'غير موجود', bad_action: 'إجراء غير صالح', cannot_block_self: 'لا يمكنك حظر نفسك', bad_credentials: 'البيانات غير صحيحة', too_many_attempts: 'محاولات كثيرة، انتظر قليلاً', bad_role: 'دور غير صالح', bad_days: 'مدة غير صالحة' };
  const fail = (e) => toast(ERR[e.code] || 'حدث خطأ: ' + (e.code || ''), true);
  const ago = (ts) => { const s = (Date.now() - ts) / 1000; if (s < 60) return 'الآن'; if (s < 3600) return 'قبل ' + Math.floor(s / 60) + ' د'; if (s < 86400) return 'قبل ' + Math.floor(s / 3600) + ' س'; return new Date(ts).toLocaleString('ar'); };
  const date = (ts) => new Date(ts).toLocaleDateString('ar', { year: 'numeric', month: 'short', day: 'numeric' });
  const CAT = { quran: 'القرآن', hadith: 'الحديث', seerah: 'السيرة', fiqh: 'الفقه', adhkar: 'الأذكار', mawaiz: 'المواعظ', science: 'العلوم', math: 'الرياضيات', languages: 'اللغات', programming: 'البرمجة' };
  const REASON = { music: 'يحتوي على موسيقى', wrong_info: 'معلومة خاطئة', offensive: 'محتوى مسيء', spam: 'إزعاج أو إعلان', impersonation: 'انتحال شخصية', other: 'سبب آخر' };
  const SEV = { high: 'خطير', medium: 'متوسط', low: 'منخفض', info: 'ملاحظة' };
  // شرح كل نوع تنبيه أمني + الاقتراح
  const SEC = {
    path_probe: ['يبحث عن ملفات حساسة (‎.env، ووردبريس، phpMyAdmin…)', 'أُعطي صفحات وملفات مزيفة وردوداً بطيئة. إذا تكرر احظر الزائر 24 ساعة.'],
    injection_attempt: ['محاولة حقن أوامر (SQL أو سكربت)', 'لم تنجح لأن الموقع يستخدم استعلامات آمنة. احظر الزائر، وإذا كان له حساب فاحظر الحساب أيضاً.'],
    suspicious_search: ['بحث يحتوي نصاً يشبه الحقن', 'غالباً طالب برمجة يبحث عن مصطلح؛ البحث آمن ولا يُحظر صاحبه تلقائياً. راقبه فقط إذا تكرر مع تنبيهات أخرى.'],
    brute_force: ['تخمين كلمة مرور حساب', 'الحساب محمي بمفتاح الأمان فلا يكفي تخمين كلمة المرور. احظر الزائر 24 ساعة.'],
    staff_login_attack: ['محاولة دخول على حساب إداري!', 'احظر الزائر فوراً حظراً دائماً، وتأكد أن مفتاح أمانك وكلمة مرورك لم يتسربا.'],
    admin_api_denied: ['حاول تنفيذ أوامر الإدارة بدون صلاحية', 'هذه محاولة اختراق متعمدة. أُعطي ردوداً مزيفة. احظر الحساب والزائر.'],
    admin_path_visit: ['فتح رابط لوحتك السري وهو ليس إدارياً', 'رابط لوحتك تسرّب! غيّر CONTROL_PATH في إعدادات الخادم وأعد التشغيل، ثم احظر الزائر.'],
    admin_file_probe: ['يحاول الوصول إلى ملفات لوحة الإدارة مباشرة', 'راقبه، واحظره إذا تكرر.'],
    setup_token_guess: ['يحاول إنشاء حساب مؤسس', 'احظر الزائر فوراً حظراً دائماً.'],
    canary_used: ['استخدم مفتاحاً مزيفاً أخذه من الفخ — مخترق مؤكد', 'حظر دائم للزائر ولأي حساب مرتبط به.'],
    decoy_login: ['دخل لوحة الإدارة المزيفة وجرّب كلمات مرور', 'هو يضيّع وقته في فخ. احظره حظراً دائماً متى شئت.'],
    scanning: ['فحص آلي للموقع بأداة بحث عن ثغرات', 'احظر الزائر 24 ساعة.'],
    csrf_attempt: ['طلب من موقع خارجي يحاول تنفيذ أوامر باسم مستخدم', 'تم رفضه. إذا تكرر احظر الزائر.'],
    bad_upload: ['رفع ملفاً متنكراً (ليس صورة أو فيديو حقيقياً)', 'تم رفضه. اسحب صلاحية النشر من الحساب وراجعه.'],
    rate_limited: ['طلبات كثيرة جداً', 'غالباً بوت أو إزعاج. راقب فقط.'],
    malformed_url: ['رابط مشوّه عمداً', 'راقب فقط.'],
    malformed_body: ['بيانات مشوّهة عمداً', 'راقب فقط.'],
    auto_blocked: ['حظر تلقائي 24 ساعة بسبب تكرار المحاولات', 'إذا عاد بعد انتهاء المدة اجعل الحظر دائماً.'],
    control_login_failed: ['محاولة دخول خاطئة إلى لوحتك السرية!', 'إذا لم تكن أنت: رابط لوحتك تسرّب. بعد 3 محاولات يُحظر الجهاز دائماً تلقائياً. غيّر CONTROL_PATH وأعد التشغيل.'],
    control_blocked: ['حظر دائم: 3 محاولات خاطئة على لوحتك', 'تم حظر الجهاز تلقائياً ولا يمكنه الوصول للوحة أبداً. إذا كنت أنت من أخطأ: فك الحظر من هنا أو شغّل الخادم بالأمر ‎--unblock-all.'],
  };
  const secTitle = (k) => (SEC[k] || [k])[0];
  const secSugg = (k) => (SEC[k] || ['', 'راقب.'])[1];

  let STATS = null; let tab = 'overview'; let main;
  const TABS = [
    ['overview', '📊 نظرة عامة'], ['emergency', '🚨 الطوارئ'], ['security', '🛡 الأمان'], ['pending', '⏳ بانتظار الموافقة'],
    ['reports', '🚩 البلاغات'], ['requests', '🙋 طلبات النشر'], ['team', '👮 فريق المشرفين'], ['room', '💬 غرفة المشرفين'],
    ['users', '👥 الحسابات'], ['verify', '✔ طلبات التوثيق'], ['codes', '🔑 أكواد النشر'], ['inbox', '📨 الشكاوى والرسائل'],
    ['posts', '🎬 المحتوى المنشور'], ['settings', '⚙ الإعدادات'],
  ];
  const isFounder = () => true;

  // ------------------------------------------------ الدخول برقم الأمان المتغيّر
  function showLogin(msg) {
    clearInterval(window.__mjzStats);
    const f = { u: h('input', { class: 'input ltr', autocomplete: 'off', autocapitalize: 'off', spellcheck: false }), p: h('input', { class: 'input ltr', type: 'password', autocomplete: 'off' }),
      k: h('input', { class: 'input ltr', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: '000-000-000', style: 'letter-spacing:3px;text-align:center;font-size:20px' }) };
    const err = h('div', { class: 'error-box' + (msg ? '' : ' hidden'), text: msg || '' });
    const btn = h('button', { class: 'btn gold block', type: 'submit', text: 'دخول' });
    $('#adm').replaceChildren(h('div', { class: 'gate', style: 'width:100%' },
      h('img', { class: 'gate-logo', src: '/logo-light.png', alt: 'مجازية' }),
      h('form', { class: 'card', autocomplete: 'off', onsubmit: async (e) => {
        e.preventDefault(); err.classList.add('hidden'); btn.disabled = true;
        try {
          const r = await api('/api/login', { username: f.u.value.trim(), password: f.p.value, key: f.k.value });
          showNewKey(r.next_key, 'رقم الأمان الجديد للدخول القادم', boot);
        } catch (ex) { err.textContent = (ERR[ex.code] || 'حدث خطأ') + ' — تنبيه: 3 محاولات خاطئة تحظر هذا الجهاز نهائياً.'; err.classList.remove('hidden'); btn.disabled = false; }
      } },
        h('h2', { text: '👑 لوحة المؤسس' }), h('p', { class: 'sub', text: 'قسم سري. الدخول بالمستخدم وكلمة المرور ورقم الأمان. رقم الأمان يتغيّر مع كل دخول وكل 3 أيام.' }),
        err,
        h('label', { class: 'field' }, h('span', { text: 'اسم المستخدم' }), f.u),
        h('label', { class: 'field' }, h('span', { text: 'كلمة المرور' }), f.p),
        h('label', { class: 'field' }, h('span', { text: 'رقم الأمان' }), f.k),
        btn)));
  }
  function showNewKey(key, title, after) {
    const ok = h('input', { type: 'checkbox' });
    const go2 = h('button', { class: 'btn gold block', disabled: true, text: 'متابعة' });
    ok.addEventListener('change', () => { go2.disabled = !ok.checked; });
    const bg = h('div', { class: 'sheet-bg', style: 'align-items:center;z-index:300' }, h('div', { class: 'card', style: 'max-width:420px' },
      h('h2', { text: '🔐 ' + title }),
      h('p', { class: 'sub', text: 'احفظه الآن في مكان آمن (ليس في نفس الجهاز إن أمكن). الرقم القديم لم يعد يعمل. لن يظهر هذا الرقم مرة أخرى.' }),
      h('div', { class: 'keybox', style: 'font-size:30px;letter-spacing:4px', text: key }),
      h('button', { class: 'btn ghost sm', style: 'margin-bottom:10px', text: 'نسخ', onclick: () => navigator.clipboard.writeText(key).then(() => toast('تم النسخ')).catch(() => {}) }),
      h('label', { class: 'check' }, ok, h('span', { text: 'حفظت رقم الأمان الجديد' })), go2));
    go2.addEventListener('click', () => { bg.remove(); if (after) after(); });
    document.body.append(bg);
  }
  async function logout() { try { await api('/api/logout', {}); } catch { /* */ } showLogin(); }

  async function boot() {
    let me;
    try { me = await api('/api/me'); } catch { return; }
    try { STATS = await api('/api/admin/stats'); } catch { return; }
    const side = h('nav', { class: 'adm-side' },
      h('a', { href: '/', target: '_blank' }, h('img', { src: '/logo-light.png', alt: 'مجازية' })),
      h('div', { class: 'role', text: '👑 ' + me.name }),
      TABS.map(([k, label]) => h('button', { class: 'adm-tab', 'data-tab': k, onclick: () => go(k) }, h('span', { text: label }), h('span', { class: 'cnt hidden' }))),
      h('button', { class: 'adm-tab', style: 'margin-top:auto', onclick: logout }, '⎋ تسجيل الخروج من اللوحة'));
    if (me.rotated_key) showNewKey(me.rotated_key, 'تغيّر رقم الأمان (كل 3 أيام)');
    main = h('main', { class: 'adm-main' });
    $('#adm').replaceChildren(side, main);
    paintCounts();
    go(location.hash.slice(1) || 'overview');
    window.__mjzStats = setInterval(refreshStats, 20000);
    setInterval(async () => { try { const m = await api('/api/me'); if (m.rotated_key) showNewKey(m.rotated_key, 'تغيّر رقم الأمان (كل 3 أيام)'); } catch { /* */ } }, 600000);
  }
  function paintCounts() {
    const map = { security: [STATS.security_new, STATS.security_high ? 'hot' : 'warn'], pending: [STATS.pending, 'warn'], requests: [STATS.requests, 'warn'], reports: [STATS.reports, 'hot'], verify: [STATS.verify, 'warn'], inbox: [STATS.support_unread, 'warn'] };
    document.querySelectorAll('.adm-tab[data-tab]').forEach((b) => {
      const c = b.querySelector('.cnt'); const m = map[b.dataset.tab];
      if (m && m[0]) { c.textContent = m[0]; c.className = 'cnt ' + m[1]; } else c.className = 'cnt hidden';
    });
  }
  async function refreshStats() {
    if (document.hidden) return;
    try {
      const before = STATS.security_high;
      STATS = await api('/api/admin/stats'); paintCounts();
      if (STATS.security_high > before) toast('⚠ تنبيه أمني خطير جديد — افتح تبويب الأمان', true);
    } catch { /* */ }
  }
  function go(k) {
    if (!TABS.some(([x]) => x === k)) k = 'overview';
    clearInterval(window.__mjzRoom);
    tab = k; history.replaceState(null, '', '#' + k);
    document.querySelectorAll('.adm-tab[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === k));
    main.replaceChildren(h('div', { class: 'spinner' }));
    ({ overview, emergency, security, pending, reports, requests, team, room, users, verify, codes, inbox, posts, settings })[k]().catch((e) => { main.replaceChildren(h('div', { class: 'empty', text: 'تعذّر التحميل' })); console.error(e); });
  }
  const fill = (...a) => main.replaceChildren(...a.flat(9).filter((x) => x != null && x !== false));
  const head = (title, lead) => [h('h2', { text: title }), lead ? h('p', { class: 'lead', text: lead }) : null];
  const empty = (txt) => h('div', { class: 'empty', text: txt });
  async function act(path, body, okMsg) { try { await api(path, body); toast(okMsg || 'تم ✔'); await refreshStats(); go(tab); } catch (e) { fail(e); } }
  function promptText(label) { const v = window.prompt(label); return v === null ? null : v.trim(); }

  // ------------------------------------------------ نظرة عامة
  async function overview() {
    STATS = await api('/api/admin/stats'); paintCounts();
    const s = STATS;
    const card = (n, label, cls, to) => h('button', { class: 'stat ' + (cls || ''), style: 'text-align:start', onclick: to ? () => go(to) : null }, h('b', { text: n }), h('span', { text: label }));
    fill(...head('نظرة عامة', 'ملخص مجازية الآن.'),
      s.security_high ? h('div', { class: 'box', style: 'border-color:rgba(229,72,77,.6);background:rgba(229,72,77,.08)' },
        h('b', { text: `⚠ تنبيهات أمنية خطيرة لم تراجعها: ${s.security_high}` }), h('div', { class: 'btns' }, h('button', { class: 'btn danger sm', text: 'افتح الأمان', onclick: () => go('security') }))) : null,
      h('div', { class: 'stats' },
        card(s.security_new, 'تنبيهات أمنية جديدة', s.security_high ? 'alert' : (s.security_new ? 'warn' : ''), 'security'),
        card(s.pending, 'بانتظار الموافقة', s.pending ? 'warn' : '', 'pending'),
        card(s.preapproved, 'وافق عليها المشرفون — بانتظارك', s.preapproved ? 'alert' : '', 'pending'),
        card(s.requests, 'طلبات صلاحية النشر', s.requests ? 'warn' : '', 'requests'),
        card(s.reports, 'بلاغات مفتوحة', s.reports ? 'alert' : '', 'reports'),
        card(s.verify, 'طلبات توثيق', s.verify ? 'warn' : '', 'verify'),
        card(s.support_unread, 'رسائل غير مقروءة', s.support_unread ? 'warn' : '', 'inbox'),
        card(s.users, 'كل الحسابات', '', 'users'), card(s.active_24h, 'نشطون آخر 24 ساعة'),
        card(s.publishers, 'لديهم صلاحية نشر'), card(s.banned, 'محظورون'),
        card(s.reels, 'ريلز منشورة', '', 'posts'), card(s.posts, 'منشورات منشورة', '', 'posts')),
      h('div', { class: 'box' }, h('b', { text: 'حالة النظام' }),
        h('div', { class: 'small', style: 'margin-top:6px;line-height:1.9' },
          `مراجعة المنشورات قبل النشر: ${s.settings.approval_required ? 'مفعّلة ✔' : 'متوقفة'}`, h('br'),
          `التسجيل: ${s.settings.registration_open ? 'مفتوح' : 'مغلق'}`, h('br'),
          `الموافقة الأخيرة للمؤسس: ${s.settings.founder_final_approval ? 'مفعّلة ✔' : 'متوقفة (موافقة المشرف تنشر مباشرة)'}`, h('br'),
          `حذف المحتوى تلقائياً: ${s.settings.content_ttl_days ? 'بعد ' + s.settings.content_ttl_days + ' يوم' : 'لا'}`, h('br'),
          (s.settings.maintenance || s.settings.freeze_publishing || s.settings.staff_locked) ? h('b', { style: 'color:#ff8b8f', text: '🚨 طوارئ مفعّلة: ' + [s.settings.maintenance && 'الصيانة', s.settings.freeze_publishing && 'تجميد النشر', s.settings.staff_locked && 'قفل المشرفين'].filter(Boolean).join('، ') }) : 'الطوارئ: لا شيء مفعّل ✔', h('br'),
          `ترجمة DeepL: ${s.deepl ? 'مفعّلة ✔' : 'غير مفعّلة — ضع DEEPL_API_KEY في إعدادات الخادم'}`)));
  }

  // ------------------------------------------------ الأمان
  async function security(status = 'new') {
    const d = await api('/api/admin/security?status=' + status);
    const blockBtns = (visitor, usernames) => h('div', { class: 'btns' },
      h('button', { class: 'btn danger sm', text: 'حظر الزائر 24 ساعة', onclick: () => act('/api/admin/security/block', { visitor, hours: 24 }) }),
      h('button', { class: 'btn danger sm', text: 'حظر دائم', onclick: () => { if (confirm('حظر هذا الزائر حظراً دائماً؟ سيرى صفحة صيانة مزيفة.')) act('/api/admin/security/block', { visitor, hours: 0 }); } }),
      (usernames || []).map((u) => h('button', { class: 'btn ghost sm', text: 'إدارة الحساب @' + u, onclick: () => { go('users'); setTimeout(() => { const i = $('#usearch'); if (i) { i.value = u; i.dispatchEvent(new Event('input')); } }, 300); } })),
      h('button', { class: 'btn ghost sm', text: 'تجاهل', onclick: () => act('/api/admin/security/handle', { visitor }) }));
    const offenders = d.offenders.filter((o) => !o.blocked && o.score >= 3);
    fill(...head('الأمان والمراقبة', 'كل محاولة بحث عن ثغرات أو اختراق تظهر هنا. المخترقون يُعطَون صفحات ومفاتيح مزيفة وردوداً بطيئة لتضييع وقتهم، ومن يستخدم مفتاحاً مزيفاً يُكشف فوراً. الموقع لا يحفظ عناوين IP الحقيقية — كل زائر له بصمة مجهولة يمكنك حظرها.'),
      h('div', { class: 'toolbar' },
        h('button', { class: 'btn sm ' + (status === 'new' ? 'primary' : 'ghost'), text: 'الجديدة', onclick: () => security('new') }),
        h('button', { class: 'btn sm ' + (status === 'handled' ? 'primary' : 'ghost'), text: 'تمت مراجعتها', onclick: () => security('handled') }),
        status === 'new' && d.events.length ? h('button', { class: 'btn ghost sm', text: 'تعليم الكل كمُراجَع', onclick: () => act('/api/admin/security/handle', { all: true }) }) : null),
      offenders.length ? h('div', {}, h('h3', { text: '🎯 أخطر الزوار (آخر 7 أيام)', style: 'margin:6px 0 10px' }),
        offenders.slice(0, 10).map((o) => h('div', { class: 'box', style: o.score >= 12 ? 'border-color:rgba(229,72,77,.5)' : '' },
          h('div', { class: 'row' }, h('div', { class: 'grow' },
            h('b', {}, 'زائر ', h('span', { class: 'mono', text: '#' + o.visitor.slice(0, 8) })), ' ',
            h('span', { class: 'pill ' + (o.score >= 12 ? 'high' : 'medium'), text: 'درجة الخطر ' + o.score }), ' ',
            h('span', { class: 'small', text: o.n + ' محاولة · آخرها ' + ago(o.last) }),
            o.usernames.length ? h('div', { class: 'small', style: 'margin-top:4px' }, 'حسابات مرتبطة: ', o.usernames.map((u) => '@' + u).join('، ')) : null,
            h('div', { class: 'small', style: 'margin-top:4px', text: 'ماذا فعل: ' + o.kinds.map(secTitle).join(' · ') }),
            h('div', { class: 'sugg', text: o.score >= 12 ? 'هذا زائر يحاول الاختراق بشكل متكرر — احظره حظراً دائماً' + (o.usernames.length ? ' واحظر حسابه.' : '.') : secSugg(o.kinds[0]) }))),
          blockBtns(o.visitor, o.usernames)))) : null,
      h('h3', { text: status === 'new' ? '🔔 التنبيهات' : '📁 السجل', style: 'margin:16px 0 10px' }),
      d.events.length ? d.events.map((e) => h('div', { class: 'box' },
        h('div', { class: 'row' }, h('div', { class: 'grow' },
          h('span', { class: 'pill ' + e.severity, text: SEV[e.severity] || e.severity }), ' ', h('b', { text: secTitle(e.kind) }),
          h('div', { class: 'small', style: 'margin-top:4px' }, 'زائر ', h('span', { class: 'mono', text: '#' + e.visitor.slice(0, 8) }), e.username ? ' · الحساب @' + e.username : ' · بدون حساب', ' · ', ago(e.created_at)),
          e.detail ? h('div', { style: 'margin-top:4px;font-size:13.5px', dir: 'auto', text: e.detail }) : null,
          e.path ? h('div', { class: 'mono small', style: 'margin-top:4px', text: e.method + ' ' + e.path }) : null,
          h('div', { class: 'sugg', text: secSugg(e.kind) }))),
        status === 'new' ? blockBtns(e.visitor, e.username ? [e.username] : []) : null)) : empty(status === 'new' ? 'لا توجد تنبيهات جديدة — الموقع آمن ✔' : 'السجل فارغ'),
      d.blocked.length ? h('div', {}, h('h3', { text: '⛔ الزوار المحظورون', style: 'margin:18px 0 10px' }),
        h('div', { class: 'box' }, h('table', { class: 't' }, h('tr', {}, h('th', { text: 'الزائر' }), h('th', { text: 'السبب' }), h('th', { text: 'حتى' }), h('th', {})),
          d.blocked.map((b) => h('tr', {}, h('td', { class: 'mono', text: '#' + b.visitor.slice(0, 8) }), h('td', { text: b.reason === 'auto' ? 'حظر تلقائي' : b.reason === 'manual' ? 'يدوي' : b.reason === 'control_login' ? '3 محاولات على لوحتك' : b.reason }),
            h('td', { text: b.until === -1 ? 'دائم' : date(b.until) }), h('td', {}, h('button', { class: 'btn ghost sm', text: 'فك الحظر', onclick: () => act('/api/admin/security/block', { visitor: b.visitor, unblock: true }) }))))))) : null);
  }

  // ------------------------------------------------ مراجعة المنشورات
  async function pending() {
    const d = await api('/api/admin/pending');
    fill(...head('مراجعة المنشورات', 'لا يظهر أي ريلز أو منشور للناس إلا بعد موافقتك. تأكد من عدم وجود موسيقى ومن صحة المعلومة.'),
      d.posts.length ? d.posts.map((p) => h('div', { class: 'box' },
        h('div', { class: 'small' }, (p.kind === 'reel' ? '🎬 ريلز' : '📝 منشور') + ' · ' + (CAT[p.category] || p.category) + ' · لغة: ' + p.source_lang + ' · ' + ago(p.created_at)),
        h('div', { style: 'margin:4px 0' }, h('b', { text: p.author.name }), ' ', h('span', { class: 'mono', text: '@' + p.author.username }),
          p.pre_approved_by ? h('span', { class: 'pill', style: 'color:#7fe0ae;margin-inline-start:8px', text: '✔ وافق عليه مبدئياً @' + p.pre_approved_by }) : null),
        p.title ? h('h3', { dir: 'auto', text: p.title, style: 'margin:6px 0' }) : null,
        p.body ? h('div', { dir: 'auto', style: 'white-space:pre-wrap', text: p.body }) : null,
        h('div', { class: 'media-prev' },
          p.video ? h('video', { src: p.video, controls: true, preload: 'metadata', playsinline: true }) : null,
          p.images.map((src) => h('img', { src, alt: '' }))),
        p.kind === 'reel' ? h('div', { class: 'small', style: 'margin-top:6px', text: `المدة: ${Math.floor(p.duration / 60)}:${String(Math.round(p.duration % 60)).padStart(2, '0')} · الترجمة: ${p.subtitles.length ? p.subtitles.length + ' سطر' : 'لا يوجد'}` }) : null,
        h('div', { class: 'btns' },
          h('button', { class: 'btn primary sm', text: '✔ موافقة ونشر', onclick: () => act(`/api/admin/posts/${p.id}/review`, { action: 'approve' }, 'تم النشر') }),
          h('button', { class: 'btn danger sm', text: '✖ رفض وحذف الملفات', onclick: () => { const r = promptText('سبب الرفض (يراه الناشر). سيُحذف الفيديو/الصور نهائياً فوراً:'); if (r !== null) act(`/api/admin/posts/${p.id}/review`, { action: 'reject', reason: r }, 'تم الرفض والحذف'); } })))) : empty('لا يوجد شيء بانتظار المراجعة ✔'));
  }

  // ------------------------------------------------ البلاغات
  async function reports(status = 'open') {
    const d = await api('/api/admin/reports?status=' + status);
    const tgt = (r) => {
      if (!r.target) return h('div', { class: 'small', text: '(المحتوى حُذف)' });
      if (r.target_type === 'post') return h('div', {}, h('div', { class: 'small', text: (r.target.kind === 'reel' ? '🎬 ريلز' : '📝 منشور') + ' من @' + r.target.author.username }),
        r.target.title ? h('b', { dir: 'auto', text: r.target.title }) : null, r.target.body ? h('div', { dir: 'auto', style: 'white-space:pre-wrap;max-height:120px;overflow:auto', text: r.target.body }) : null,
        h('div', { class: 'media-prev' }, r.target.video ? h('video', { src: r.target.video, controls: true, preload: 'metadata', style: 'max-height:220px' }) : null, r.target.images.map((src) => h('img', { src, alt: '' }))));
      if (r.target_type === 'comment') return h('div', {}, h('div', { class: 'small', text: '💬 تعليق من @' + r.target.username }), h('div', { dir: 'auto', text: r.target.body }));
      return h('div', {}, h('div', { class: 'small', text: '👤 حساب' }), h('b', { text: r.target.name + ' ' }), h('span', { class: 'mono', text: '@' + r.target.username }));
    };
    const authorOf = (r) => r.target && (r.target_type === 'post' ? r.target.author.username : r.target_type === 'comment' ? r.target.username : r.target.username);
    fill(...head('البلاغات', 'ما يبلّغ عنه الناس: منشورات، تعليقات، وحسابات.'),
      h('div', { class: 'toolbar' }, [['open', 'المفتوحة'], ['resolved', 'المحلولة'], ['dismissed', 'المرفوضة']].map(([k, l]) => h('button', { class: 'btn sm ' + (status === k ? 'primary' : 'ghost'), text: l, onclick: () => reports(k) }))),
      d.reports.length ? d.reports.map((r) => h('div', { class: 'box' },
        h('div', {}, h('span', { class: 'pill high', text: REASON[r.reason] || r.reason }), ' ', r.same_count > 1 ? h('span', { class: 'pill medium', text: r.same_count + ' بلاغات على نفس الشيء' }) : null,
          h('span', { class: 'small', text: ' · من @' + (r.reporter || 'محذوف') + ' · ' + ago(r.created_at) })),
        r.details ? h('div', { class: 'small', style: 'margin:6px 0', dir: 'auto', text: '«' + r.details + '»' }) : null,
        h('div', { style: 'margin-top:8px' }, tgt(r)),
        status === 'open' ? h('div', { class: 'btns' },
          r.target && r.target_type !== 'user' ? h('button', { class: 'btn danger sm', text: 'حذف المحتوى', onclick: () => act(`/api/admin/reports/${r.id}`, { action: 'remove_content' }) }) : null,
          authorOf(r) ? h('button', { class: 'btn danger sm', text: 'حظر @' + authorOf(r), onclick: () => banByUsername(authorOf(r), () => act(`/api/admin/reports/${r.id}`, { action: 'resolve' })) }) : null,
          h('button', { class: 'btn ghost sm', text: 'تم الحل', onclick: () => act(`/api/admin/reports/${r.id}`, { action: 'resolve' }) }),
          h('button', { class: 'btn ghost sm', text: 'رفض البلاغ', onclick: () => act(`/api/admin/reports/${r.id}`, { action: 'dismiss' }) })) : null)) : empty('لا توجد بلاغات ✔'));
  }
  async function banByUsername(username, after) {
    try {
      const d = await api('/api/admin/users?q=' + encodeURIComponent(username));
      const u = d.users.find((x) => x.username === username); if (!u) return toast('الحساب غير موجود', true);
      const reason = promptText('سبب الحظر (اختياري):'); if (reason === null) return;
      await api(`/api/admin/users/${u.id}`, { action: 'ban', reason }); toast('تم حظر @' + username); if (after) after(); else go(tab);
    } catch (e) { fail(e); }
  }

  // ------------------------------------------------ الحسابات
  async function users(filter = 'all') {
    const q = h('input', { class: 'input', id: 'usearch', placeholder: 'ابحث باسم المستخدم أو الاسم…', type: 'search' });
    const sel = h('select', { class: 'input' }, [['all', 'الكل'], ['publishers', 'لديهم صلاحية نشر'], ['verified', 'الموثّقون'], ['banned', 'المحظورون'], ['staff', 'الإدارة']].map(([k, l]) => h('option', { value: k, text: l, selected: k === filter })));
    const list = h('div');
    fill(...head('الحسابات', 'الحظر، الحذف، صلاحية النشر، التوثيق' + (isFounder() ? '، وتعيين المشرفين.' : '.')), h('div', { class: 'toolbar' }, q, sel), list);
    let timer;
    const load = async () => {
      list.replaceChildren(h('div', { class: 'spinner' }));
      try {
        const d = await api(`/api/admin/users?filter=${sel.value}&q=${encodeURIComponent(q.value.trim())}`);
        list.replaceChildren(...(d.users.length ? d.users.map(userBox) : [empty('لا يوجد')]));
      } catch (e) { fail(e); }
    };
    q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 300); });
    sel.addEventListener('change', load);
    load();
  }
  function userBox(u) {
    const pub = u.publish_until === -1 ? 'دائمة' : u.publish_until > Date.now() ? 'حتى ' + date(u.publish_until) : 'لا';
    const roleTxt = { founder: '👑 المؤسس', mod1: '🛡 مشرف مستوى 1', mod2: '🛡 مشرف مستوى 2', user: '' }[u.role];
    // بعد أي إجراء: أعد تحميل نفس التبويب (فريق المشرفين يبقى فريق المشرفين) مع الحفاظ على البحث والفلتر
    const reloadUsers = (msg) => async (body) => { try { await api(`/api/admin/users/${u.id}`, body); toast(msg || 'تم ✔'); await refreshStats();
      if (tab !== 'users') return go(tab);
      const sel = $('.adm-main .toolbar select'); const qi = $('#usearch'); const qv = qi ? qi.value : '';
      await users(sel ? sel.value : 'all'); const ni = $('#usearch'); if (ni && qv) { ni.value = qv; ni.dispatchEvent(new Event('input')); } } catch (e) { fail(e); } };
    const run = reloadUsers();
    const grantSel = h('select', { class: 'input', style: 'height:36px;padding:4px 10px;width:auto' }, [[1, 'يوم'], [2, 'يومان'], [3, '3 أيام'], [4, '4 أيام'], [7, 'أسبوع'], [30, 'شهر'], [0, 'دائم']].map(([d, l]) => h('option', { value: d, text: l })));
    return h('div', { class: 'box', style: u.banned ? 'opacity:.75;border-color:rgba(229,72,77,.4)' : '' },
      h('div', { class: 'row' }, h('div', { class: 'grow' },
        h('b', { text: u.name + ' ' }), h('span', { class: 'mono', text: '@' + u.username }), ' ',
        u.verified !== 'none' ? h('span', { class: 'pill', style: u.verified === 'gold' ? 'color:var(--gold)' : 'color:var(--blue)', text: u.verified === 'gold' ? 'موثّق ذهبي' : 'موثّق أزرق' }) : null, ' ',
        roleTxt ? h('span', { class: 'pill', text: roleTxt }) : null, ' ', u.banned ? h('span', { class: 'pill high', text: 'محظور' }) : null,
        h('div', { class: 'small', style: 'margin-top:4px' }, `النشر: ${pub} · منشورات: ${u.posts} · بلاغات مفتوحة: ${u.reports} · آخر نشاط: ${ago(u.last_active)} · انضم: ${date(u.created_at)} · حذف تلقائي بعد غياب ${u.inactivity_days} يوم`),
        u.banned && u.ban_reason ? h('div', { class: 'small', text: 'سبب الحظر: ' + u.ban_reason }) : null),
        h('a', { class: 'btn ghost sm', href: '/#/u/' + u.username, target: '_blank', text: 'عرض' })),
      u.role === 'founder' ? null : h('div', { class: 'btns' },
        u.banned ? h('button', { class: 'btn ghost sm', text: 'فك الحظر', onclick: () => run({ action: 'unban' }) })
          : h('button', { class: 'btn danger sm', text: 'حظر', onclick: () => { const r = promptText('سبب الحظر (اختياري):'); if (r !== null) run({ action: 'ban', reason: r }); } }),
        h('button', { class: 'btn danger sm', text: 'حذف الحساب', onclick: () => { if (confirm(`حذف @${u.username} وكل محتواه نهائياً؟`)) run({ action: 'delete' }); } }),
        isFounder() ? h('span', { style: 'display:inline-flex;gap:4px;align-items:center' }, grantSel, h('button', { class: 'btn primary sm', text: 'منح صلاحية النشر', onclick: () => run({ action: 'grant_publish', days: Number(grantSel.value) }) })) : null,
        isFounder() && u.publish_until !== 0 ? h('button', { class: 'btn ghost sm', text: 'سحب صلاحية النشر', onclick: () => run({ action: 'revoke_publish' }) }) : null,
        isFounder() ? [
          u.verified !== 'blue' ? h('button', { class: 'btn ghost sm', style: 'color:var(--blue)', text: 'توثيق أزرق', onclick: () => run({ action: 'verify', level: 'blue' }) }) : null,
          u.verified !== 'gold' ? h('button', { class: 'btn ghost sm', style: 'color:var(--gold)', text: 'توثيق ذهبي (أولوية)', onclick: () => run({ action: 'verify', level: 'gold' }) }) : null,
          u.verified !== 'none' ? h('button', { class: 'btn ghost sm', text: 'إزالة التوثيق', onclick: () => run({ action: 'verify', level: 'none' }) }) : null,
          u.role !== 'mod1' ? h('button', { class: 'btn gold sm', text: 'مشرف مستوى 1', onclick: () => { if (confirm(`@${u.username} سيراجع المنشورات المنتظرة والمبلّغ عنها فقط. متابعة؟`)) run({ action: 'set_role', role: 'mod1' }); } }) : null,
          u.role !== 'mod2' ? h('button', { class: 'btn gold sm', text: 'مشرف مستوى 2', onclick: () => { if (confirm(`@${u.username} سيراجع المنشورات والبلاغات، ويحذف الحسابات، ويحظر ويفك الحظر، ويستقبل الشكاوى. متابعة؟`)) run({ action: 'set_role', role: 'mod2' }); } }) : null,
          u.role !== 'user' ? h('button', { class: 'btn ghost sm', text: 'إزالة من المشرفين', onclick: () => run({ action: 'set_role', role: 'user' }) }) : null,
        ] : null));
  }

  // ------------------------------------------------ طلبات التوثيق
  async function verify() {
    const d = await api('/api/admin/verify');
    fill(...head('طلبات التوثيق', 'الأزرق = حساب موثوق. الذهبي = أولوية: يظهر أولاً دائماً في الرئيسية والاستكشاف والاقتراحات.'),
      d.requests.length ? d.requests.map((r) => h('div', { class: 'box' },
        h('b', { text: r.name + ' ' }), h('span', { class: 'mono', text: '@' + r.username }), ' ',
        h('span', { class: 'pill', style: r.type === 'gold' ? 'color:var(--gold)' : 'color:var(--blue)', text: 'يطلب: ' + (r.type === 'gold' ? 'ذهبي' : 'أزرق') }),
        h('span', { class: 'small', text: ' · ' + ago(r.created_at) }),
        r.note ? h('div', { dir: 'auto', style: 'margin-top:6px;white-space:pre-wrap', text: r.note }) : null,
        isFounder() ? h('div', { class: 'btns' },
          h('button', { class: 'btn sm', style: 'background:var(--blue);color:#fff', text: 'منح الأزرق', onclick: () => act(`/api/admin/users/${r.user_id}`, { action: 'verify', level: 'blue' }) }),
          h('button', { class: 'btn gold sm', text: 'منح الذهبي', onclick: () => act(`/api/admin/users/${r.user_id}`, { action: 'verify', level: 'gold' }) }),
          h('button', { class: 'btn ghost sm', text: 'رفض', onclick: () => act(`/api/admin/verify/${r.id}/dismiss`, {}) })) : h('div', { class: 'small', style: 'margin-top:6px', text: 'التوثيق بيد المؤسس فقط.' }))) : empty('لا توجد طلبات'));
  }

  // ------------------------------------------------ أكواد النشر
  async function codes() {
    const d = await api('/api/admin/codes');
    const days = h('select', { class: 'input' }, [[1, 'يوم واحد'], [2, 'يومان'], [3, '3 أيام'], [4, '4 أيام'], [7, 'أسبوع'], [30, 'شهر'], [0, 'مفتوح (دائم)']].map(([v, l]) => h('option', { value: v, text: l })));
    const uses = h('input', { class: 'input', type: 'number', min: 1, max: 1000, value: '1', style: 'max-width:110px' });
    const note = h('input', { class: 'input', placeholder: 'ملاحظة: لمن هذا الكود؟' });
    const out = h('div');
    fill(...head('أكواد النشر', 'أنشئ كوداً وأعطه لصفحة أو شخص ليستطيع النشر. الصلاحية تبدأ من لحظة التفعيل. (تظل المنشورات بحاجة إلى موافقتك إذا كانت المراجعة مفعّلة.)'),
      h('div', { class: 'box' },
        h('div', { class: 'toolbar', style: 'margin:0' },
          h('label', {}, h('div', { class: 'small', text: 'مدة الصلاحية' }), days),
          h('label', {}, h('div', { class: 'small', text: 'عدد مرات الاستخدام' }), uses),
          h('label', { style: 'flex:1' }, h('div', { class: 'small', text: 'ملاحظة' }), note),
          h('button', { class: 'btn gold', style: 'align-self:flex-end', text: '+ إنشاء كود', onclick: async () => {
            try { const r = await api('/api/admin/codes', { grant_days: Number(days.value), max_uses: Number(uses.value) || 1, note: note.value });
              out.replaceChildren(h('div', { class: 'box', style: 'border-color:var(--gold);margin-top:10px' }, h('div', { class: 'small', text: 'الكود الجديد:' }), h('div', { class: 'code-big', text: r.code }),
                h('button', { class: 'btn ghost sm', style: 'margin-top:8px', text: 'نسخ', onclick: () => navigator.clipboard.writeText(r.code).then(() => toast('تم النسخ')) })));
              setTimeout(() => codes().then(() => main.querySelector('.box').after(out)), 50);
            } catch (e) { fail(e); } } })),
        out),
      d.codes.length ? h('div', { class: 'box' }, h('table', { class: 't' },
        h('tr', {}, ['الكود', 'المدة', 'الاستخدام', 'استخدمه', 'ملاحظة', 'الحالة', ''].map((x) => h('th', { text: x }))),
        d.codes.map((c) => h('tr', {},
          h('td', { class: 'mono', text: c.code }), h('td', { text: c.grant_days === 0 ? 'دائم' : c.grant_days + ' يوم' }),
          h('td', { text: c.uses + ' / ' + c.max_uses }), h('td', { class: 'small', text: c.users.map((u) => '@' + u).join('، ') || '—' }),
          h('td', { class: 'small', text: c.note || '—' }), h('td', { text: c.active ? (c.uses >= c.max_uses ? 'مُستنفد' : 'فعّال') : 'موقوف' }),
          h('td', {}, h('button', { class: 'btn ghost sm', text: c.active ? 'إيقاف' : 'تفعيل', onclick: () => act(`/api/admin/codes/${c.code}/toggle`, {}) })))))) : null);
  }

  // ------------------------------------------------ الرسائل
  async function inbox(openId) {
    const d = await api('/api/admin/inbox');
    const conv = h('div', { class: 'box', style: 'min-height:200px' }, h('div', { class: 'small', text: 'اختر محادثة' }));
    fill(...head('الرسائل', 'رسائل الناس إلى «إدارة مجازية» وطلبات التوثيق. ردّك يظهر لهم باسم مجازية وليس باسم حسابك.'),
      h('div', { style: 'display:grid;grid-template-columns:minmax(200px,300px) 1fr;gap:12px' },
        h('div', {}, d.threads.length ? d.threads.map((th) => h('button', { class: 'box', style: 'width:100%;text-align:start;display:block' + (th.unread ? ';border-color:var(--gold)' : ''), onclick: () => openConv(th) },
          h('b', { text: th.name + ' ' }), h('span', { class: 'mono', text: '@' + th.username }), th.unread ? h('span', { class: 'pill medium', text: ' ' + th.unread + ' جديدة' }) : null,
          h('div', { class: 'small', text: ago(th.last) }))) : empty('لا توجد رسائل')),
        conv));
    async function openConv(th) {
      const msgs = h('div', { style: 'display:flex;flex-direction:column;gap:6px;max-height:55vh;overflow:auto;margin:10px 0' });
      const input = h('textarea', { class: 'input', placeholder: 'اكتب ردك باسم مجازية…', style: 'min-height:60px' });
      conv.replaceChildren(h('b', { text: th.name + ' ' }), h('span', { class: 'mono', text: '@' + th.username }), msgs, input,
        h('div', { class: 'btns' }, h('button', { class: 'btn primary sm', text: 'إرسال', onclick: async () => { if (!input.value.trim()) return; try { await api(`/api/admin/inbox/${th.id}`, { body: input.value }); input.value = ''; load(); } catch (e) { fail(e); } } }),
          h('button', { class: 'btn ghost sm', text: 'إدارة الحساب', onclick: () => { go('users'); setTimeout(() => { const i = $('#usearch'); if (i) { i.value = th.username; i.dispatchEvent(new Event('input')); } }, 300); } })));
      async function load() {
        const r = await api(`/api/admin/inbox/${th.id}`);
        msgs.replaceChildren(...r.messages.map((m) => h('div', { class: 'msg' + (m.from_user ? '' : ' mine') }, m.body, h('span', { class: 'mt', text: ago(m.at) + (m.by ? ' · ' + m.by : '') }))));
        msgs.scrollTop = msgs.scrollHeight; refreshStats();
      }
      load();
    }
    if (openId) { const th = d.threads.find((x) => x.id === openId); if (th) openConv(th); }
  }

  // ------------------------------------------------ المحتوى المنشور
  async function posts() {
    const q = h('input', { class: 'input', type: 'search', placeholder: 'ابحث في العناوين والنصوص أو اسم المستخدم…' });
    const list = h('div');
    fill(...head('المحتوى المنشور', 'احذف أي ريلز أو منشور مباشرة.'), h('div', { class: 'toolbar' }, q), list);
    let timer;
    const load = async () => {
      const d = await api('/api/admin/posts?q=' + encodeURIComponent(q.value.trim()));
      list.replaceChildren(...(d.posts.length ? d.posts.map((p) => h('div', { class: 'box row' },
        p.thumb ? h('img', { src: p.thumb, alt: '', style: 'width:60px;height:90px;object-fit:cover;border-radius:8px' }) : (p.images[0] ? h('img', { src: p.images[0], alt: '', style: 'width:60px;height:60px;object-fit:cover;border-radius:8px' }) : null),
        h('div', { class: 'grow' }, h('div', { class: 'small', text: (p.kind === 'reel' ? '🎬 ريلز' : '📝 منشور') + ' · @' + p.author.username + ' · ' + (CAT[p.category] || '') + ' · ' + p.views + ' مشاهدة · ' + p.likes + ' إعجاب · ' + ago(p.created_at) }),
          h('div', { dir: 'auto', style: 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis', text: p.title || p.body })),
        h('div', { style: 'display:flex;gap:6px;flex-direction:column' },
          h('a', { class: 'btn ghost sm', href: '/#/' + (p.kind === 'reel' ? 'reel/' : 'post/') + p.id, target: '_blank', text: 'عرض' }),
          h('button', { class: 'btn danger sm', text: 'حذف', onclick: () => { if (confirm('حذف نهائي؟')) act(`/api/posts/${p.id}/delete`, {}); } })))) : [empty('لا يوجد')]));
    };
    q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 300); });
    load();
  }

  // ------------------------------------------------ الإعدادات
  async function settings() {
    STATS = await api('/api/admin/stats');
    const ap = h('input', { type: 'checkbox', checked: STATS.settings.approval_required });
    const ro = h('input', { type: 'checkbox', checked: STATS.settings.registration_open });
    ap.addEventListener('change', () => act('/api/admin/settings', { approval_required: ap.checked }));
    ro.addEventListener('change', () => act('/api/admin/settings', { registration_open: ro.checked }));
    const ff = h('input', { type: 'checkbox', checked: STATS.settings.founder_final_approval });
    ff.addEventListener('change', () => act('/api/admin/settings', { founder_final_approval: ff.checked }));
    const ttl = h('select', { class: 'input', style: 'max-width:200px' }, [[0, 'يبقى دائماً'], [7, 'بعد أسبوع'], [30, 'بعد شهر'], [90, 'بعد 3 أشهر'], [180, 'بعد 6 أشهر'], [365, 'بعد سنة']].map(([v, l]) => h('option', { value: v, text: l, selected: v === STATS.settings.content_ttl_days })));
    ttl.addEventListener('change', () => { if (Number(ttl.value) === 0 || confirm('سيُحذف كل محتوى أقدم من هذه المدة نهائياً بشكل تلقائي. متابعة؟')) act('/api/admin/settings', { content_ttl_days: Number(ttl.value) }); });
    const log = await api('/api/admin/audit');
    const A = { approve_post: 'وافق على منشور', reject_post: 'رفض منشوراً', delete_post: 'حذف منشوراً', delete_comment: 'حذف تعليقاً', create_code: 'أنشأ كوداً', settings: 'غيّر الإعدادات', block_visitor: 'حظر زائراً', unblock_visitor: 'فك حظر زائر', user_ban: 'حظر حساباً', user_unban: 'فك حظر حساب', user_delete: 'حذف حساباً', user_grant_publish: 'منح صلاحية نشر', user_revoke_publish: 'سحب صلاحية نشر', user_verify: 'غيّر التوثيق', user_make_mod: 'عيّن مشرفاً', user_remove_mod: 'أزال مشرفاً', report_remove_content: 'حذف محتوى مبلَّغ عنه', report_resolve: 'أغلق بلاغاً', report_dismiss: 'رفض بلاغاً', preapprove_post: 'وافق مبدئياً على منشور', user_set_role: 'غيّر دور حساب', control_login: 'دخل لوحة المؤسس', control_rotate_key: 'غيّر رقم الأمان', emergency_lockdown: '🚨 أغلق الموقع بالكامل', emergency_reopen: 'أعاد فتح الموقع', emergency_logout_all: 'سجّل خروج الجميع', emergency_logout_staff: 'سجّل خروج المشرفين', publish_request_grant: 'منح صلاحية نشر (طلب)', publish_request_dismiss: 'رفض طلب نشر' };
    fill(...head('الإعدادات', 'إعدادات المؤسس فقط.'),
      h('div', { class: 'box' },
        h('label', { class: 'switch' }, h('div', {}, h('b', { text: 'مراجعة كل المنشورات قبل ظهورها' }), h('div', { class: 'small', text: 'إذا أوقفتها ينشر أصحاب الصلاحية مباشرة.' })), ap),
        h('label', { class: 'switch' }, h('div', {}, h('b', { text: 'الموافقة الأخيرة لي فقط' }), h('div', { class: 'small', text: 'موافقة المشرفين تكون مبدئية، ولا يُنشر شيء إلا بعد موافقتك أنت.' })), ff),
        h('label', { class: 'switch' }, h('div', {}, h('b', { text: 'التسجيل مفتوح للحسابات الجديدة' })), ro),
        h('div', { class: 'switch', style: 'border:0' }, h('div', {}, h('b', { text: 'حذف المحتوى تلقائياً' }), h('div', { class: 'small', text: 'لا يبقى أي فيديو أو منشور بعد هذه المدة.' })), ttl)),
      h('div', { class: 'box' }, h('b', { text: '🔐 حماية الملفات' }), h('div', { class: 'small', style: 'margin-top:6px;line-height:1.9' },
        'كل الفيديوهات والصور محفوظة مشفّرة (AES-256)، ومُسحت منها البيانات المخفية (الموقع، الجهاز، التاريخ). المرفوض يُحذف فوراً.', h('br'),
        STATS.media_key_env ? 'مفتاح التشفير محفوظ خارج القرص (MEDIA_KEY) ✔' : '⚠ مفتاح التشفير محفوظ داخل مجلد البيانات. للأمان الأعلى ضعه في متغير البيئة MEDIA_KEY واحذف ملف media.key.')),
      h('h3', { text: '📜 سجل أعمال الإدارة' }),
      h('div', { class: 'box' }, log.audit.length ? h('table', { class: 't' }, log.audit.map((a) => h('tr', {}, h('td', { class: 'mono', text: '@' + (a.username || '—') }), h('td', { text: A[a.action] || a.action }), h('td', { class: 'mono small', text: a.target }), h('td', { class: 'small', text: ago(a.created_at) })))) : empty('لا يوجد')));
  }

  // ------------------------------------------------ الطوارئ
  async function emergency() {
    STATS = await api('/api/admin/stats'); const st = STATS.settings;
    const sw = (key, title, desc, danger) => { const i = h('input', { type: 'checkbox', checked: st[key] }); i.addEventListener('change', () => act('/api/admin/settings', { [key]: i.checked })); return h('label', { class: 'switch' }, h('div', {}, h('b', { text: title, style: danger && st[key] ? 'color:#ff8b8f' : '' }), h('div', { class: 'small', text: desc })), i); };
    const doAct = (action, msg) => { if (confirm(msg)) act('/api/emergency', { action }); };
    fill(...head('🚨 الطوارئ', 'تحكّم كامل مهما صار. كل زر يعمل فوراً على الموقع كله.'),
      (st.maintenance || st.staff_locked || st.freeze_publishing) ? h('div', { class: 'box', style: 'border-color:rgba(229,72,77,.6);background:rgba(229,72,77,.08)' }, h('b', { text: '⚠ يوجد إجراء طوارئ مفعّل الآن' })) : null,
      h('div', { class: 'box' },
        sw('maintenance', 'إغلاق الموقع (وضع الصيانة)', 'الناس يرون «الموقع تحت الصيانة»، والمشرفون وأنت فقط تدخلون.', true),
        sw('freeze_publishing', 'تجميد النشر', 'لا أحد يستطيع رفع أو نشر أي شيء (إلا أنت).', true),
        sw('staff_locked', 'قفل غرفة المشرفين', 'كل المشرفين يفقدون صلاحياتهم فوراً حتى تفتحها.', true),
        sw('registration_open', 'التسجيل مفتوح', 'إيقافه يمنع إنشاء حسابات جديدة.')),
      h('div', { class: 'box' }, h('b', { text: 'أزرار فورية' }),
        h('div', { class: 'btns' },
          h('button', { class: 'btn danger', text: '🔒 إغلاق كامل الآن', onclick: () => doAct('lockdown', 'إغلاق الموقع + تجميد النشر + قفل المشرفين + إيقاف التسجيل + تسجيل خروج الجميع. متابعة؟') }),
          h('button', { class: 'btn primary', text: '🔓 إعادة فتح كل شيء', onclick: () => doAct('reopen', 'إعادة فتح الموقع والنشر والمشرفين والتسجيل؟') }),
          h('button', { class: 'btn ghost', text: 'تسجيل خروج كل المستخدمين', onclick: () => doAct('logout_all', 'كل الناس سيحتاجون تسجيل الدخول من جديد. متابعة؟') }),
          h('button', { class: 'btn ghost', text: 'تسجيل خروج المشرفين', onclick: () => doAct('logout_staff', 'تسجيل خروج كل المشرفين من الموقع؟') }))),
      h('div', { class: 'box' }, h('b', { text: '🔐 رقم أمان اللوحة' }),
        h('div', { class: 'small', style: 'margin:6px 0', text: `عمر الرقم الحالي: ${STATS.control_key_age_days} يوم. يتغيّر تلقائياً مع كل دخول وكل 3 أيام. 3 محاولات خاطئة = حظر دائم للجهاز.` }),
        h('button', { class: 'btn gold sm', text: 'تغيير رقم الأمان الآن', onclick: async () => { try { const r = await api('/api/rotate-key', {}); showNewKey(r.next_key, 'رقم الأمان الجديد'); } catch (e) { fail(e); } } })));
  }

  // ------------------------------------------------ طلبات النشر
  async function requests() {
    const d = await api('/api/publish-requests');
    const box = (r) => {
      const sel = h('select', { class: 'input', style: 'height:36px;padding:4px 10px;width:auto' }, [[1, 'يوم'], [2, 'يومان'], [3, '3 أيام'], [4, '4 أيام'], [7, 'أسبوع'], [30, 'شهر'], [0, 'دائم']].map(([v, l]) => h('option', { value: v, text: l })));
      return h('div', { class: 'box' },
        h('b', { text: r.name + ' ' }), h('span', { class: 'mono', text: '@' + r.username }), ' ', r.reports_on_user ? h('span', { class: 'pill high', text: r.reports_on_user + ' بلاغات على الحساب' }) : null,
        h('div', { class: 'small', text: 'طلب ' + ago(r.created_at) + ' · انضم ' + date(r.joined) }),
        r.note ? h('div', { dir: 'auto', style: 'margin-top:6px;white-space:pre-wrap', text: r.note }) : null,
        h('div', { class: 'btns' }, sel, h('button', { class: 'btn primary sm', text: 'منح صلاحية النشر', onclick: () => act(`/api/publish-requests/${r.id}`, { action: 'grant', days: Number(sel.value) }) }),
          h('button', { class: 'btn ghost sm', text: 'رفض', onclick: () => act(`/api/publish-requests/${r.id}`, { action: 'dismiss' }) }),
          h('a', { class: 'btn ghost sm', href: '/#/u/' + r.username, target: '_blank', text: 'عرض الحساب' })));
    };
    fill(...head('طلبات النشر', 'الأشخاص الذين يريدون صلاحية النشر. المشرفون يرونها في غرفتهم، والقرار لك.'), d.requests.length ? d.requests.map(box) : empty('لا توجد طلبات'));
  }

  // ------------------------------------------------ فريق المشرفين
  async function team() {
    const d = await api('/api/admin/users?filter=staff');
    const add = h('input', { class: 'input', placeholder: 'اسم المستخدم لإضافته مشرفاً' });
    fill(...head('فريق المشرفين', 'لا أحد من الناس يعرف من هم المشرفون. المستوى 1: يراجع المنشورات المنتظرة والمبلّغ عنها. المستوى 2: الصلاحيات نفسها، إضافةً إلى حذف الحسابات والحظر وفكّه واستقبال الشكاوى. لوحة المؤسس هذه لك وحدك.'),
      h('div', { class: 'box' }, h('div', { class: 'toolbar', style: 'margin:0' }, add,
        h('button', { class: 'btn gold sm', text: 'إضافة مستوى 1', onclick: () => setRoleBy(add.value, 'mod1') }),
        h('button', { class: 'btn gold sm', text: 'إضافة مستوى 2', onclick: () => setRoleBy(add.value, 'mod2') }))),
      d.users.filter((u) => u.role !== 'founder').length ? d.users.filter((u) => u.role !== 'founder').map(userBox) : empty('لا يوجد مشرفون بعد'));
  }
  async function setRoleBy(username, role) {
    username = String(username).trim().replace(/^@/, '').toLowerCase(); if (!username) return;
    try { const d = await api('/api/admin/users?q=' + encodeURIComponent(username)); const u = d.users.find((x) => x.username === username); if (!u) return toast('الحساب غير موجود', true);
      await api(`/api/admin/users/${u.id}`, { action: 'set_role', role }); toast('تم ✔'); go('team'); } catch (e) { fail(e); }
  }

  // ------------------------------------------------ غرفة المشرفين (قراءة ومشاركة)
  async function room() {
    const msgs = h('div', { style: 'display:flex;flex-direction:column;gap:6px;max-height:60vh;overflow:auto;margin:10px 0' });
    const input = h('textarea', { class: 'input', placeholder: 'اكتب للمشرفين…', style: 'min-height:60px' });
    let last = 0;
    const RL = { founder: '👑', mod2: '🛡2', mod1: '🛡1' };
    async function load() {
      const r = await api('/api/room?since=' + last);
      for (const m of r.messages) { msgs.append(h('div', { class: 'msg' + (m.author && m.author.role === 'founder' ? ' mine' : '') }, h('b', { style: 'display:block;font-size:12px;opacity:.8', text: m.author ? `${RL[m.author.role] || ''} ${m.author.name} @${m.author.username}` : 'محذوف' }), m.body, h('span', { class: 'mt', text: ago(m.at) }))); last = Math.max(last, m.at); }
      if (r.messages.length) msgs.scrollTop = msgs.scrollHeight;
    }
    fill(...head('غرفة المشرفين', 'الغرفة نفسها التي يراها المشرفون داخل الموقع.'), h('div', { class: 'box' }, msgs, input,
      h('div', { class: 'btns' }, h('button', { class: 'btn primary sm', text: 'إرسال', onclick: async () => { if (!input.value.trim()) return; try { await api('/api/room', { body: input.value }); input.value = ''; load(); } catch (e) { fail(e); } } }))));
    await load();
    window.__mjzRoom = setInterval(() => { if (!document.hidden) load().catch(() => {}); }, 5000);
  }

  boot();
})();
