'use strict';
(() => {
  const $ = (id) => document.getElementById(id);
  const base = location.pathname.replace(/\/setup\/?$/, '');
  const token = new URLSearchParams(location.search).get('token') || '';
  $('f').addEventListener('submit', async (e) => {
    e.preventDefault(); $('err').classList.add('hidden'); $('btn').disabled = true;
    try {
      const r = await fetch(base + '/api/setup', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Majazia': '1' },
        body: JSON.stringify({ token, name: $('name').value, username: $('username').value.trim().toLowerCase(), password: $('password').value }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      $('f').classList.add('hidden'); $('done').classList.remove('hidden');
      $('skey').textContent = d.site_key; $('ckey').textContent = d.control_key; $('path').textContent = location.origin + base;
      $('go').href = base;
      history.replaceState(null, '', base + '/setup');
    } catch (ex) {
      const m = { bad_token: 'رمز الإعداد غير صحيح', weak_password: 'كلمة المرور قصيرة (10 أحرف على الأقل)', bad_username: 'اسم المستخدم: أحرف إنجليزية صغيرة وأرقام و _ . (3–20)', username_taken: 'اسم المستخدم مستخدم', not_found: 'تم إنشاء حساب المؤسس من قبل' };
      $('err').textContent = m[ex.message] || 'حدث خطأ'; $('err').classList.remove('hidden'); $('btn').disabled = false;
    }
  });
})();
