'use strict';
/* مجازية — غرفة المشرفين (تُرسل للمشرفين فقط) */
window.MJZ_STAFF = (root, X) => {
  const { h, api, toast, avatar, timeAgo, confirmSheet, catName, loader, emptyState } = X;
  const fail = (e) => toast(X.errText(e.code), true);
  const REASON = { music: 'يحتوي على موسيقى', wrong_info: 'معلومة خاطئة', offensive: 'محتوى مسيء', spam: 'إزعاج أو إعلان', impersonation: 'انتحال شخصية', other: 'سبب آخر' };
  const LV = (m) => m.founder ? '👑 المؤسس' : m.level === 2 ? 'مشرف · المستوى 2' : 'مشرف · المستوى 1';
  let me = null; let counts = {}; let tab = sessionStorage.getItem('mjz_staff_tab') || 'room'; let timer = null;
  const body = h('div', { class: 'panel', style: 'padding-top:10px' });
  const tabsEl = h('div', { class: 'chips', style: 'padding:10px 12px;border-bottom:1px solid var(--border);flex-wrap:wrap' });
  const membersEl = h('div', { style: 'display:flex;gap:8px;overflow-x:auto;padding:10px 12px;border-bottom:1px solid var(--border)' });
  root.setAttribute('dir', 'rtl'); root.setAttribute('lang', 'ar');
  root.replaceChildren(membersEl, tabsEl, body);

  const box = (...kids) => h('div', { class: 'aside-box', style: 'margin-bottom:10px' }, ...kids);
  const small = (txt) => h('div', { class: 'muted', style: 'font-size:12.5px', text: txt });
  const at = (u) => h('bdi', { dir: 'ltr', text: '@' + u });
  const pill = (txt, color) => h('span', { class: 'status-pill', style: `background:${color || 'var(--surface-2)'};margin-inline-end:6px`, text: txt });
  const prompt2 = (label) => { const v = window.prompt(label); return v === null ? null : v.trim(); };

  async function overview() {
    const d = await api('/api/staff/overview');
    me = d.me; counts = d.counts;
    membersEl.replaceChildren(...d.members.map((m) => h('div', { style: 'display:flex;flex-direction:column;align-items:center;gap:3px;min-width:64px;font-size:11px;text-align:center' },
      h('div', { style: 'position:relative' }, avatar(m, 'sm'), m.online ? h('span', { style: 'position:absolute;bottom:0;inset-inline-end:0;width:10px;height:10px;border-radius:50%;background:#2bd17e;border:2px solid var(--bg)' }) : null),
      h('b', { text: m.name, style: 'max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }), h('span', { class: 'muted', text: LV(m) }))));
    const tabs = [['room', '💬 الغرفة', counts.room], ['pending', '⏳ بانتظار الموافقة', counts.pending], ['reports', '🚩 البلاغات', counts.reports], ['requests', '🙋 طلبات النشر', counts.requests]];
    if (me.level === 2 || me.founder) tabs.push(['complaints', '📨 الشكاوى', counts.complaints], ['users', '👥 الحسابات', 0]);
    if (!tabs.some(([k]) => k === tab)) tab = 'room';
    tabsEl.replaceChildren(...tabs.map(([k, label, n]) => h('button', { class: 'chip' + (tab === k ? ' on' : ''), onclick: () => { tab = k; sessionStorage.setItem('mjz_staff_tab', k); render(); } }, label + (n ? ` (${n})` : ''))));
  }
  async function render() {
    clearInterval(timer);
    body.replaceChildren(loader());
    try { await overview(); await ({ room, pending, reports, requests, complaints, users })[tab](); }
    catch (e) { body.replaceChildren(emptyState(X.errText(e.code), null, 'shield')); }
    X.refresh();
  }
  const act = async (path, payload, msg) => { try { const r = await api(path, { method: 'POST', body: payload }); toast(msg || 'تم ✔'); render(); return r; } catch (e) { fail(e); return null; } };

  // ---------------- الغرفة (جروب المشرفين)
  async function room() {
    const msgs = h('div', { class: 'msgs', style: 'max-height:58vh;min-height:240px;border:1px solid var(--border);border-radius:16px;margin-bottom:8px' });
    const input = h('textarea', { class: 'input', placeholder: 'اكتب للفريق…', style: 'min-height:50px' });
    const send = h('button', { class: 'btn primary', text: 'إرسال' });
    body.replaceChildren(small('هذه الغرفة لا يراها إلا المشرفون والمؤسس. ناقشوا البلاغات والمنشورات هنا.'), h('div', { style: 'height:8px' }), msgs, h('div', { style: 'display:flex;gap:8px;align-items:flex-end' }, input, send));
    let last = 0;
    async function load() {
      const r = await api('/api/staff/room?since=' + last);
      if (!last && !r.messages.length && !msgs.querySelector('.empty')) msgs.append(h('div', { class: 'empty', style: 'padding:30px', text: 'ابدأوا النقاش' }));
      for (const m of r.messages) {
        const e = msgs.querySelector('.empty'); if (e) e.remove();
        msgs.append(h('div', { class: 'msg' + (m.mine ? ' mine' : '') }, m.mine ? null : h('b', { style: 'display:block;font-size:11.5px;opacity:.85', text: m.author ? `${m.author.name} · ${LV(m.author)}` : 'محذوف' }), m.body, h('span', { class: 'mt', text: timeAgo(m.at) })));
        last = Math.max(last, m.at);
      }
      if (r.messages.length) msgs.scrollTop = msgs.scrollHeight;
    }
    const doSend = async () => { const v = input.value.trim(); if (!v) return; send.disabled = true; try { await api('/api/staff/room', { method: 'POST', body: { body: v } }); input.value = ''; await load(); } catch (e) { fail(e); } send.disabled = false; };
    send.addEventListener('click', doSend);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); } });
    await load();
    // عند فقد الصلاحية (قفل الغرفة/خروج) يتوقف التحديث بدل تكرار طلبات مرفوضة
    timer = setInterval(() => { if (!document.hidden && document.body.contains(msgs)) load().catch(() => clearInterval(timer)); else if (!document.body.contains(msgs)) clearInterval(timer); }, 4000);
  }

  // ---------------- بانتظار النشر
  function media(p) {
    return h('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;margin-top:8px' },
      p.video ? h('video', { src: p.video, controls: true, preload: 'metadata', playsinline: true, style: 'max-height:340px;max-width:100%;border-radius:12px;background:#000' }) : null,
      p.images.map((src) => h('img', { src, alt: '', style: 'max-height:150px;border-radius:10px' })));
  }
  async function pending() {
    const d = await api('/api/staff/pending');
    const list = d.posts.map((p) => box(
      small((p.kind === 'reel' ? '🎬 ريلز' : '📝 منشور') + ' · ' + catName(p.category) + ' · ' + timeAgo(p.created_at)),
      h('div', { style: 'margin:4px 0;display:flex;gap:6px;align-items:center;flex-wrap:wrap' }, h('b', { text: p.author.name }), h('span', { class: 'muted', dir: 'ltr', text: '@' + p.author.username }),
        p.pre_approved_by ? pill('✔ موافقة مبدئية من @' + p.pre_approved_by + ' — بانتظار المؤسس', 'rgba(31,164,99,.15)') : null),
      p.title ? h('h3', { dir: 'auto', text: p.title, style: 'margin:6px 0' }) : null,
      p.body ? h('div', { dir: 'auto', style: 'white-space:pre-wrap', text: p.body }) : null,
      media(p),
      p.kind === 'reel' ? small(`المدة: ${X.fmtDur(p.duration)} · الترجمة: ${p.subtitles.length ? p.subtitles.length + ' سطر' : 'لا يوجد'}`) : null,
      p.pre_approved_by && !me.founder ? null : h('div', { style: 'display:flex;gap:8px;margin-top:10px;flex-wrap:wrap' },
        h('button', { class: 'btn primary sm', text: d.founder_final && !me.founder ? '✔ موافقة مبدئية' : '✔ موافقة ونشر', onclick: async () => { const r = await act(`/api/staff/posts/${p.id}/review`, { action: 'approve' }, d.founder_final && !me.founder ? 'تمت الموافقة المبدئية — بانتظار المؤسس' : 'تم النشر'); } }),
        h('button', { class: 'btn danger sm', text: '✖ رفض', onclick: () => { const r = prompt2('سبب الرفض (يراه الناشر). ستُحذف الملفات فوراً:'); if (r !== null) act(`/api/staff/posts/${p.id}/review`, { action: 'reject', reason: r }, 'تم الرفض والحذف'); } }))));
    body.replaceChildren(small(d.founder_final ? 'لا يُنشر شيء إلا بعد موافقة المؤسس. موافقتكم مبدئية وتنتقل إليه، والرفض يحذف الملفات فوراً.' : 'موافقتكم تنشر المحتوى مباشرة. تأكدوا من عدم وجود موسيقى ومن صحة المعلومة.'), h('div', { style: 'height:8px' }),
      ...(list.length ? list : [emptyState('لا يوجد شيء بانتظار المراجعة ✔', null, 'video')]));
  }

  // ---------------- البلاغات
  async function reports(status = 'open') {
    const d = await api('/api/staff/reports?status=' + status);
    const tgt = (r) => {
      if (!r.target) return small('(المحتوى حُذف)');
      if (r.target_type === 'post') return h('div', {}, h('div', { class: 'muted', style: 'font-size:12.5px' }, (r.target.kind === 'reel' ? '🎬 ريلز' : '📝 منشور') + ' من ', at(r.target.author.username)),
        r.target.title ? h('b', { dir: 'auto', text: r.target.title }) : null, r.target.body ? h('div', { dir: 'auto', style: 'white-space:pre-wrap;max-height:120px;overflow:auto', text: r.target.body }) : null, media(r.target));
      if (r.target_type === 'comment') return h('div', {}, h('div', { class: 'muted', style: 'font-size:12.5px' }, '💬 تعليق من ', at(r.target.username)), h('div', { dir: 'auto', text: r.target.body }));
      return h('div', {}, small('👤 حساب'), h('b', { text: r.target.name + ' ' }), h('span', { class: 'muted', dir: 'ltr', text: '@' + r.target.username }));
    };
    const seg = h('div', { style: 'display:flex;gap:6px;margin-bottom:10px' }, [['open', 'المفتوحة'], ['resolved', 'المحلولة'], ['dismissed', 'المرفوضة']].map(([k, l]) => h('button', { class: 'btn sm ' + (status === k ? 'primary' : 'ghost'), text: l, onclick: () => reports(k) })));
    const list = d.reports.map((r) => box(
      h('div', {}, pill(REASON[r.reason] || r.reason, 'rgba(229,72,77,.15)'), r.same_count > 1 ? pill(r.same_count + ' بلاغات على نفس الشيء', 'rgba(212,175,55,.15)') : null),
      h('div', { class: 'muted', style: 'font-size:12.5px' }, 'المُبلِّغ: ', r.reporter_name ? [h('bdi', { text: r.reporter_name }), ' ', at(r.reporter)] : 'محذوف', ' · ' + timeAgo(r.created_at), r.handled_by ? [' · عالجه ', at(r.handled_by)] : null),
      r.details ? h('div', { dir: 'auto', style: 'margin:6px 0;font-size:14px', text: '«' + r.details + '»' }) : null,
      h('div', { style: 'margin-top:8px' }, tgt(r)),
      status === 'open' ? h('div', { style: 'display:flex;gap:8px;margin-top:10px;flex-wrap:wrap' },
        r.target && r.target_type !== 'user' ? h('button', { class: 'btn danger sm', text: 'حذف المحتوى', onclick: () => confirmSheet('حذف المحتوى المبلّغ عنه نهائياً؟', () => act(`/api/staff/reports/${r.id}`, { action: 'remove_content' })) }) : null,
        h('button', { class: 'btn ghost sm', text: 'تمت المعالجة', onclick: () => act(`/api/staff/reports/${r.id}`, { action: 'resolve' }) }),
        h('button', { class: 'btn ghost sm', text: 'البلاغ غير صحيح', onclick: () => act(`/api/staff/reports/${r.id}`, { action: 'dismiss' }) })) : null));
    body.replaceChildren(seg, ...(list.length ? list : [emptyState('لا توجد بلاغات ✔', null, 'flag')]));
  }

  // ---------------- من يريد النشر
  async function requests() {
    const d = await api('/api/staff/publish-requests');
    body.replaceChildren(small('هؤلاء طلبوا صلاحية النشر. القرار للمؤسس — ناقشوا رأيكم في الغرفة.'), h('div', { style: 'height:8px' }),
      ...(d.requests.length ? d.requests.map((r) => box(
        h('div', { style: 'display:flex;gap:6px;align-items:center' }, h('b', { text: r.name }), h('span', { class: 'muted', dir: 'ltr', text: '@' + r.username }), r.reports_on_user ? pill(r.reports_on_user + ' بلاغات', 'rgba(229,72,77,.15)') : null),
        small('طلب ' + timeAgo(r.created_at)),
        r.note ? h('div', { dir: 'auto', style: 'margin-top:6px;white-space:pre-wrap', text: r.note }) : null,
        h('a', { class: 'btn ghost sm', style: 'margin-top:8px', href: '#/u/' + r.username, text: 'عرض الحساب' }))) : [emptyState('لا توجد طلبات', null, 'user')]));
  }

  // ---------------- الشكاوى (مستوى 2)
  async function complaints() {
    const d = await api('/api/staff/inbox');
    const conv = h('div');
    body.replaceChildren(small('رسائل الناس إلى «إدارة مجازية». ردّكم يظهر لهم باسم مجازية، لا بأسمائكم.'), h('div', { style: 'height:8px' }),
      ...(d.threads.length ? d.threads.map((th) => h('button', { class: 'thread', style: 'border:1px solid var(--border);border-radius:14px;margin-bottom:6px' + (th.unread ? ';border-color:var(--gold)' : ''), onclick: () => open(th) },
        avatar(th, 'sm'), h('div', { class: 'tb' }, h('div', { class: 'tn', text: th.name }), h('div', { class: 'tl', text: '@' + th.username + ' · ' + timeAgo(th.last) })), th.unread ? h('span', { class: 'ub', text: th.unread }) : null)) : [emptyState('لا توجد شكاوى', null, 'chat')]), conv);
    async function open(th) {
      const msgs = h('div', { class: 'msgs', style: 'max-height:50vh;border:1px solid var(--border);border-radius:16px;margin:10px 0' });
      const input = h('textarea', { class: 'input', placeholder: 'ردّ باسم مجازية…', style: 'min-height:50px' });
      conv.replaceChildren(h('b', { text: th.name + ' @' + th.username }), msgs, input,
        h('button', { class: 'btn primary sm', style: 'margin-top:8px', text: 'إرسال', onclick: async () => { if (!input.value.trim()) return; try { await api(`/api/staff/inbox/${th.id}`, { method: 'POST', body: { body: input.value } }); input.value = ''; load(); } catch (e) { fail(e); } } }));
      async function load() {
        const r = await api(`/api/staff/inbox/${th.id}`);
        msgs.replaceChildren(...r.messages.map((m) => h('div', { class: 'msg' + (m.from_user ? '' : ' mine') }, m.body, h('span', { class: 'mt', text: timeAgo(m.at) + (m.by ? ' · @' + m.by : '') }))));
        msgs.scrollTop = msgs.scrollHeight;
      }
      await load(); conv.scrollIntoView({ behavior: 'smooth' });
    }
  }

  // ---------------- الحسابات (مستوى 2)
  async function users() {
    const q = h('input', { class: 'input', type: 'search', placeholder: 'ابحث باسم المستخدم أو الاسم…' });
    const onlyBanned = h('input', { type: 'checkbox' });
    const list = h('div');
    body.replaceChildren(small('المستوى 2: الحظر وفك الحظر وحذف الحسابات. لا يمكن التصرف بحسابات الإدارة.'), h('div', { style: 'height:8px' }), q,
      h('label', { class: 'check' }, onlyBanned, h('span', { text: 'المحظورون فقط' })), list);
    let tmr;
    const load = async () => {
      list.replaceChildren(loader());
      try {
        const d = await api(`/api/staff/users?q=${encodeURIComponent(q.value.trim())}${onlyBanned.checked ? '&filter=banned' : ''}`);
        list.replaceChildren(...(d.users.length ? d.users.map((u) => box(
          h('div', { style: 'display:flex;gap:8px;align-items:center' }, avatar(u, 'sm'), h('div', { style: 'flex:1;min-width:0' }, h('b', { text: u.name }), ' ', h('span', { class: 'muted', dir: 'ltr', text: '@' + u.username }),
            small(`منشورات: ${u.posts} · بلاغات مفتوحة: ${u.reports} · آخر نشاط: ${timeAgo(u.last_active)}`)), u.banned ? pill('محظور', 'rgba(229,72,77,.15)') : null),
          u.banned && u.ban_reason ? small('سبب الحظر: ' + u.ban_reason) : null,
          h('div', { style: 'display:flex;gap:8px;margin-top:10px;flex-wrap:wrap' },
            u.banned ? h('button', { class: 'btn ghost sm', text: 'فك الحظر', onclick: () => act(`/api/staff/users/${u.id}`, { action: 'unban' }) })
              : h('button', { class: 'btn danger sm', text: 'حظر', onclick: () => { const r = prompt2('سبب الحظر:'); if (r !== null) act(`/api/staff/users/${u.id}`, { action: 'ban', reason: r }); } }),
            h('button', { class: 'btn danger sm', text: 'حذف الحساب', onclick: () => confirmSheet(`حذف @${u.username} وكل محتواه نهائياً؟`, () => act(`/api/staff/users/${u.id}`, { action: 'delete' })) }),
            h('a', { class: 'btn ghost sm', href: '#/u/' + u.username, text: 'عرض' })))) : [emptyState('لا يوجد', null, 'user')]));
      } catch (e) { fail(e); }
    };
    q.addEventListener('input', () => { clearTimeout(tmr); tmr = setTimeout(load, 300); });
    onlyBanned.addEventListener('change', load);
    load();
  }

  render();
};
