'use strict';
/* مجازية — Majazia · واجهة المستخدم */
(() => {
  // ================================================================ أدوات
  const $ = (sel, el = document) => el.querySelector(sel);
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch { /* تجاهل */ } },
  };
  const S = {
    cfg: null, me: null,
    lang: LS.get('mjz_lang', ''),
    category: '', unread: 0,
    cc: LS.get('mjz_cc', '1') === '1',
    mainRoute: null, viewer: null, viewerList: null,
    chatOpen: false, inApp: 0,
  };
  const t = (k) => (I18N[S.lang] || I18N.ar)[k] ?? I18N.ar[k] ?? k;
  const errText = (code) => { const k = 'err_' + code; const d = I18N[S.lang] || I18N.ar; return d[k] || I18N.ar[k] ? t(k) : t('err_generic'); };

  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    if (props) for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v; // فقط لأيقونات SVG ثابتة من الكود
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'style') el.style.cssText = v;
      else if (k in el && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat(9)) if (c != null && c !== false) el.append(c instanceof Node ? c : document.createTextNode(String(c)));
    return el;
  }
  const I = {
    home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    heart: '<path d="M12 20s-7.5-4.6-9.3-9.4C1.4 7 3.6 4 6.9 4c2 0 3.4 1.1 5.1 3 1.7-1.9 3.1-3 5.1-3 3.3 0 5.5 3 4.2 6.6C19.5 15.4 12 20 12 20z"/>',
    comment: '<path d="M4 5h16v11H8l-4 4z"/>',
    share: '<path d="M4 12v7a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-7M16 6l-4-4-4 4M12 2v13"/>',
    download: '<path d="M12 3v12m0 0-5-5m5 5 5-5M4 20h16"/>',
    flag: '<path d="M5 21V4h11l-1.5 4L16 12H5"/>',
    more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
    back: '<path d="M15 5l-7 7 7 7"/>',
    close: '<path d="M6 6l12 12M18 6 6 18"/>',
    send: '<path d="M4 12 20 4l-6 16-3-7z"/>',
    play: '<path d="M7 4v16l13-8z"/>',
    video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3z"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5-5-9 9"/>',
    cc: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10.5a2 2 0 1 0 0 3M17 10.5a2 2 0 1 0 0 3"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9m-4 4 3 3"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    link: '<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    crown: '<path d="m3 8 4 4 5-7 5 7 4-4-2 11H5z"/>',
    logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
    upload: '<path d="M12 16V4m0 0-5 5m5-5 5 5M4 20h16"/>',
    star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1-4.4-4.3 6.1-.9z"/>',
  };
  const icon = (n, cls = '') => h('span', { style: 'display:inline-flex', html: `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${I[n]}</svg>` });
  const BADGE = {
    blue: '<svg viewBox="0 0 24 24"><path fill="#1d9bf0" d="M22.5 12.5c0-1.6-.9-2.9-2.1-3.6.3-1.4-.1-3-1.2-4-1.1-1.1-2.6-1.5-4-1.2C14.5 2.4 13.2 1.5 11.6 1.5S8.7 2.4 8 3.7c-1.4-.3-3 .1-4 1.2-1.1 1.1-1.5 2.6-1.2 4C1.5 9.6.6 10.9.6 12.5s.9 2.9 2.2 3.6c-.3 1.4.1 3 1.2 4 1.1 1.1 2.6 1.5 4 1.2.7 1.3 2 2.2 3.6 2.2s2.9-.9 3.6-2.2c1.4.3 3-.1 4-1.2 1.1-1.1 1.5-2.6 1.2-4 1.3-.7 2.1-2 2.1-3.6z"/><path fill="#fff" d="m9.9 16.6-3.5-3.5 1.4-1.4 2.1 2.1 5.4-5.4 1.4 1.4z"/></svg>',
    gold: '<svg viewBox="0 0 24 24"><path fill="#d9b23c" d="M22.5 12.5c0-1.6-.9-2.9-2.1-3.6.3-1.4-.1-3-1.2-4-1.1-1.1-2.6-1.5-4-1.2C14.5 2.4 13.2 1.5 11.6 1.5S8.7 2.4 8 3.7c-1.4-.3-3 .1-4 1.2-1.1 1.1-1.5 2.6-1.2 4C1.5 9.6.6 10.9.6 12.5s.9 2.9 2.2 3.6c-.3 1.4.1 3 1.2 4 1.1 1.1 2.6 1.5 4 1.2.7 1.3 2 2.2 3.6 2.2s2.9-.9 3.6-2.2c1.4.3 3-.1 4-1.2 1.1-1.1 1.5-2.6 1.2-4 1.3-.7 2.1-2 2.1-3.6z"/><path fill="#3a2a03" d="m9.9 16.6-3.5-3.5 1.4-1.4 2.1 2.1 5.4-5.4 1.4 1.4z"/></svg>',
  };
  const badge = (v) => (v === 'blue' || v === 'gold') ? h('span', { class: 'badge', title: v === 'gold' ? t('verifiedGold') : t('verifiedBlue'), html: BADGE[v] }) : null;
  const COLORS = ['#1f8a5a', '#2a6f97', '#8a5a1f', '#6b3fa0', '#a03f5c', '#3f7f8a', '#7a8a1f', '#5a4a8a'];
  function avatar(u, size = '') {
    let x = 0; for (const c of String(u.username || '')) x = (x * 31 + c.charCodeAt(0)) >>> 0;
    const bg = u.verified === 'gold' ? 'linear-gradient(135deg,#e2bd4a,#9c7412)' : COLORS[x % COLORS.length];
    return h('span', { class: 'avatar ' + size, style: `background:${bg}`, text: (u.name || u.username || '?').trim().charAt(0) || '?' });
  }
  function timeAgo(ts) {
    const s = Math.max(0, (Date.now() - ts) / 1000);
    if (s < 60) return t('now');
    if (s < 3600) return Math.floor(s / 60) + t('m');
    if (s < 86400) return Math.floor(s / 3600) + t('h');
    if (s < 86400 * 30) return Math.floor(s / 86400) + t('d');
    return new Date(ts).toLocaleDateString(S.lang === 'ar' ? 'ar' : S.lang);
  }
  const fmtNum = (n) => n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K' : String(n);
  const fmtDur = (s) => { s = Math.round(s || 0); const hh = Math.floor(s / 3600), mm = Math.floor(s % 3600 / 60), ss = s % 60; return (hh ? hh + ':' + String(mm).padStart(2, '0') : mm) + ':' + String(ss).padStart(2, '0'); };
  const fmtDate = (ts) => new Date(ts).toLocaleDateString(S.lang === 'ar' ? 'ar' : S.lang, { year: 'numeric', month: 'long', day: 'numeric' });
  const textDir = (s) => /[؀-ۿ]/.test(String(s).slice(0, 80)) ? 'rtl' : 'ltr';

  function toast(msg, err = false) {
    const el = h('div', { class: 'toast' + (err ? ' err' : ''), text: msg });
    $('#toasts').append(el);
    setTimeout(() => el.remove(), 3200);
  }
  async function api(path, { method = 'GET', body, raw, headers = {} } = {}) {
    let res;
    try {
      res = await fetch(path, {
        method, credentials: 'same-origin',
        headers: { 'X-Majazia': '1', ...(body !== undefined && !raw ? { 'Content-Type': 'application/json' } : {}), ...headers },
        body: raw || (body !== undefined ? JSON.stringify(body) : undefined),
      });
    } catch { const e = new Error('network'); e.code = 'network'; throw e; }
    let data = null;
    try { data = await res.json(); } catch { data = null; }
    if (!res.ok) {
      const e = new Error((data && data.error) || 'generic'); e.code = (data && data.error) || 'generic'; e.status = res.status;
      if (e.code === 'login_required') { S.me = null; boot(); }
      if (e.code === 'banned' && S.me) { S.me.banned = true; renderBanned(); }
      if (e.code === 'maintenance') renderMaintenance();
      throw e;
    }
    return data;
  }
  const catName = (c) => t('cat_' + c);
  function setLang(l) {
    S.lang = I18N[l] ? l : 'ar';
    LS.set('mjz_lang', S.lang);
    document.documentElement.lang = S.lang;
    document.documentElement.dir = I18N[S.lang].dir;
  }
  function observeMore(sentinel, cb) {
    const io = new IntersectionObserver((ents) => { if (ents.some((e) => e.isIntersecting)) cb(); }, { rootMargin: '600px' });
    io.observe(sentinel); return io;
  }

  // ================================================================ البداية
  async function boot() {
    if (S.lang) setLang(S.lang);
    try { S.cfg = await api('/api/config'); }
    catch (e) {
      const root = $('#root'); root.replaceChildren(h('div', { class: 'empty', style: 'margin-top:30vh' }, h('h4', { text: errText(e.code) }), h('button', { class: 'btn ghost', onclick: boot, text: 'Retry · إعادة المحاولة' })));
      return;
    }
    S.me = S.cfg.me; S.unread = S.cfg.unread || 0;
    if (S.me && I18N[S.me.lang] && !S.lang) setLang(S.me.lang);
    if (!S.lang) return renderLangGate();
    setLang(S.lang);
    if (!S.me) return renderAuth('login');
    if (S.me.banned) return renderBanned();
    if (S.cfg.maintenance && !S.cfg.staff) return renderMaintenance();
    renderShell();
  }

  function langMini(onChange) {
    return h('div', { class: 'lang-mini' }, ['ar', 'en', 'fr'].map((l) => h('button', { class: S.lang === l ? 'on' : '', text: l === 'ar' ? 'ع' : l.toUpperCase(), onclick: () => { setLang(l); onChange(); } })));
  }
  function renderLangGate() {
    document.documentElement.dir = 'rtl';
    const root = $('#root');
    root.replaceChildren(h('div', { class: 'gate' },
      h('img', { class: 'gate-logo', src: '/logo-light.png', alt: 'مجازية Majazia' }),
      h('div', { class: 'gate-tag', style: 'display:flex;flex-direction:column;gap:2px;align-items:center' }, h('span', { text: 'محتوى تعليمي هادف', dir: 'rtl' }), h('span', { text: 'Educational content', dir: 'ltr' }), h('span', { text: 'Contenu éducatif', dir: 'ltr' })),
      h('div', { class: 'card' },
        h('h2', { text: 'اختر لغتك · Choose your language · Choisissez votre langue', style: 'font-size:17px;text-align:center;margin-bottom:18px;line-height:1.7' }),
        h('div', { class: 'lang-list' },
          [['ar', 'العربية', 'Arabic'], ['en', 'English', 'الإنجليزية'], ['fr', 'Français', 'الفرنسية']].map(([code, name, sub]) =>
            h('button', { class: 'lang-btn', dir: code === 'ar' ? 'rtl' : 'ltr', onclick: () => { setLang(code); renderAuth('register'); } }, h('span', { text: name }), h('small', { text: sub })))))));
  }

  function renderAuth(mode, opts = {}) {
    const root = $('#root');
    const err = h('div', { class: 'error-box hidden' });
    const showErr = (m) => { err.textContent = m; err.classList.remove('hidden'); };
    const field = (label, input, hint) => h('label', { class: 'field' }, h('span', { text: label }), input, hint ? h('div', { class: 'hint', text: hint }) : null);
    const inp = (name, type = 'text', extra = {}) => h('input', { class: 'input', name, type, autocomplete: 'off', autocapitalize: 'off', spellcheck: false, ...extra });
    let card;
    if (mode === 'register') {
      let inact = 30;
      const seg = h('div', { class: 'seg' }, [3, 7, 30, 60].map((d) => h('button', { type: 'button', class: d === inact ? 'on' : '', text: t('inact_' + d), onclick: (e) => { inact = d; [...seg.children].forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); } })));
      const f = { name: inp('name', 'text', { maxlength: 40 }), username: inp('username', 'text', { maxlength: 20, class: 'input ltr' }), password: inp('password', 'password', { autocomplete: 'new-password', class: 'input ltr' }), confirm: inp('confirm', 'password', { autocomplete: 'new-password', class: 'input ltr' }) };
      const btn = h('button', { class: 'btn primary block', type: 'submit', text: t('register') });
      card = h('form', { class: 'card', onsubmit: async (e) => {
        e.preventDefault(); err.classList.add('hidden');
        const username = f.username.value.trim().toLowerCase();
        if (!f.name.value.trim() || !username || !f.password.value) return showErr(t('err_missing_fields'));
        if (!/^[a-z0-9_.]{3,20}$/.test(username)) return showErr(t('err_bad_username'));
        if (f.password.value.length < 8) return showErr(t('err_weak_password'));
        if (f.password.value !== f.confirm.value) return showErr(t('err_password_mismatch'));
        btn.disabled = true;
        try {
          const r = await api('/api/auth/register', { method: 'POST', body: { name: f.name.value, username, password: f.password.value, lang: S.lang, inactivity_days: inact } });
          S.me = r.me; renderKey(r.security_key, username);
        } catch (ex) { showErr(errText(ex.code)); btn.disabled = false; }
      } },
        h('h2', { text: t('register'), style: 'margin-bottom:14px' }),
        h('div', { class: 'privacy' }, icon('shield'), h('span', { text: t('privacyNote') })),
        err,
        field(t('name'), f.name), field(t('username'), f.username, t('usernameHint')),
        field(t('password'), f.password, t('passwordHint')), field(t('confirmPassword'), f.confirm),
        h('div', { class: 'field' }, h('span', { text: t('inactivityLabel'), style: 'display:block;font-size:13px;color:var(--muted);margin-bottom:8px' }), seg),
        btn,
        h('div', { class: 'switch-line' }, t('haveAccount') + ' ', h('button', { type: 'button', text: t('login'), onclick: () => renderAuth('login') })));
    } else if (mode === 'login') {
      const f = { username: inp('username', 'text', { maxlength: 20, class: 'input ltr', value: opts.username || '' }), password: inp('password', 'password', { autocomplete: 'current-password', class: 'input ltr' }), key: inp('key', 'text', { class: 'input ltr', placeholder: 'MJZ-XXXX-XXXX-XXXX-XXXX' }) };
      const btn = h('button', { class: 'btn primary block', type: 'submit', text: t('login') });
      card = h('form', { class: 'card', onsubmit: async (e) => {
        e.preventDefault(); err.classList.add('hidden');
        if (!f.username.value.trim() || !f.password.value || !f.key.value.trim()) return showErr(t('err_missing_fields'));
        btn.disabled = true;
        try { const r = await api('/api/auth/login', { method: 'POST', body: { username: f.username.value.trim(), password: f.password.value, security_key: f.key.value } }); S.me = r.me; if (I18N[r.me.lang] && !LS.get('mjz_lang', '')) setLang(r.me.lang); boot(); }
        catch (ex) { showErr(errText(ex.code)); btn.disabled = false; }
      } },
        h('h2', { text: t('login'), style: 'margin-bottom:14px' }), err,
        field(t('username'), f.username), field(t('password'), f.password), field(t('securityKey'), f.key),
        btn,
        h('div', { class: 'switch-line' }, h('button', { type: 'button', text: t('forgot'), style: 'color:var(--muted);font-weight:400', onclick: () => renderAuth('reset') })),
        h('div', { class: 'switch-line', style: 'margin-top:8px' }, t('noAccount') + ' ', h('button', { type: 'button', text: t('register'), onclick: () => renderAuth('register') })));
    } else {
      const f = { username: inp('username', 'text', { class: 'input ltr' }), key: inp('key', 'text', { class: 'input ltr', placeholder: 'MJZ-XXXX-XXXX-XXXX-XXXX' }), pw: inp('pw', 'password', { autocomplete: 'new-password', class: 'input ltr' }) };
      const btn = h('button', { class: 'btn primary block', type: 'submit', text: t('resetBtn') });
      card = h('form', { class: 'card', onsubmit: async (e) => {
        e.preventDefault(); err.classList.add('hidden');
        if (f.pw.value.length < 8) return showErr(t('err_weak_password'));
        btn.disabled = true;
        try { await api('/api/auth/reset', { method: 'POST', body: { username: f.username.value.trim(), security_key: f.key.value, new_password: f.pw.value } }); toast(t('resetDone')); renderAuth('login', { username: f.username.value.trim() }); }
        catch (ex) { showErr(errText(ex.code)); btn.disabled = false; }
      } },
        h('h2', { text: t('resetTitle') }), h('p', { class: 'sub', text: t('securityKey') }), err,
        field(t('username'), f.username), field(t('securityKey'), f.key), field(t('newPassword'), f.pw, t('passwordHint')),
        btn, h('div', { class: 'switch-line' }, h('button', { type: 'button', text: t('back'), onclick: () => renderAuth('login') })));
    }
    root.replaceChildren(h('div', { class: 'gate' }, langMini(() => renderAuth(mode, opts)), h('img', { class: 'gate-logo', src: '/logo-light.png', alt: 'مجازية Majazia' }), h('p', { class: 'gate-tag', text: t('tagline') }), card));
  }

  function renderKey(key, username) {
    const ok = h('input', { type: 'checkbox' });
    const go = h('button', { class: 'btn primary block', disabled: true, text: t('enterSite'), onclick: () => boot() });
    ok.addEventListener('change', () => { go.disabled = !ok.checked; });
    $('#root').replaceChildren(h('div', { class: 'gate' },
      h('img', { class: 'gate-logo', src: '/logo-light.png', alt: 'مجازية Majazia' }),
      h('div', { class: 'card' },
        h('div', { style: 'display:flex;justify-content:center;color:var(--gold);margin-bottom:8px' }, icon('key')),
        h('h2', { text: t('keyTitle'), style: 'text-align:center' }),
        h('p', { class: 'sub', text: t('keyBody'), style: 'text-align:center;margin-bottom:0' }),
        h('div', { class: 'keybox', text: key }),
        h('div', { style: 'display:flex;gap:8px;margin-bottom:6px' },
          h('button', { class: 'btn ghost sm', style: 'flex:1', text: t('copy'), onclick: async () => { try { await navigator.clipboard.writeText(key); toast(t('copied')); } catch { toast(key); } } }),
          h('button', { class: 'btn ghost sm', style: 'flex:1', text: t('downloadKey'), onclick: () => {
            const blob = new Blob([`Majazia — مجازية\n${t('username')}: ${username}\n${t('securityKey')}: ${key}\n`], { type: 'text/plain' });
            const a = h('a', { href: URL.createObjectURL(blob), download: `majazia-key-${username}.txt` }); document.body.append(a); a.click(); a.remove();
          } })),
        h('label', { class: 'check' }, ok, h('span', { text: t('keySaved') })), go)));
  }

  function renderMaintenance() {
    $('#root').replaceChildren(h('div', { class: 'gate' }, h('img', { class: 'gate-logo', src: '/logo-light.png', alt: 'مجازية Majazia' }),
      h('div', { class: 'card', style: 'text-align:center' }, h('h2', { text: t('maintenanceTitle') }), h('p', { class: 'sub', text: t('maintenanceHint') }),
        h('button', { class: 'btn ghost block', text: t('refresh'), onclick: boot }))));
  }
  function renderBanned() {
    $('#root').replaceChildren(h('div', { class: 'gate' }, h('img', { class: 'gate-logo', src: '/logo-light.png', alt: '' }),
      h('div', { class: 'card', style: 'text-align:center' }, h('h2', { text: t('banned') }), h('p', { class: 'sub', text: t('bannedHint') }),
        S.me && S.me.ban_reason ? h('p', { class: 'muted', text: S.me.ban_reason }) : null,
        h('button', { class: 'btn ghost block', text: t('logout'), onclick: logout }))));
  }
  async function logout() { try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* */ } S.me = null; location.hash = ''; boot(); }

  // ================================================================ الهيكل
  let shell = null;
  function navLinks() {
    return [
      ['home', '#/home', t('home')], ['search', '#/explore', t('explore')], ['plus', '#/publish', t('publish')],
      ['chat', 'chat', t('chat')], ['user', '#/u/' + S.me.username, t('profile')],
    ];
  }
  function staffBadge() {
    if (!S.cfg.staff) return null;
    const c = S.cfg.staff.counts || {};
    const n = (c.pending || 0) + (c.reports || 0) + (c.room || 0) + (c.complaints || 0);
    return n ? h('span', { class: 'dot', text: n > 99 ? '99+' : n }) : null;
  }
  function renderShell() {
    const main = h('main', { class: 'main', id: 'main' });
    const side = h('nav', { class: 'side' },
      h('a', { href: '#/home' }, h('img', { class: 'logo', src: '/logo-light.png', alt: 'مجازية Majazia' })),
      navLinks().map(([ic, href, label]) => href === 'chat'
        ? h('button', { class: 'nav-item', 'data-nav': 'chat', onclick: () => toggleChat(true) }, icon(ic), h('span', { text: label }), S.unread ? h('span', { class: 'dot', text: S.unread }) : null)
        : h('a', { class: 'nav-item', href, 'data-nav': href }, icon(ic), h('span', { text: label }))),
      S.cfg.staff ? h('a', { class: 'nav-item', href: '#/staff', 'data-nav': '#/staff' }, icon('shield'), h('span', { text: t('staffRoom'), class: 'gold' }), staffBadge()) : null,
      h('a', { class: 'btn primary block publish-big', href: '#/publish' }, icon('plus'), t('publish')),
      h('a', { class: 'me-mini', href: '#/settings' }, avatar(S.me, 'sm'), h('div', { style: 'min-width:0' }, h('b', { style: 'display:flex;gap:4px;align-items:center' }, S.me.name, badge(S.me.verified)), h('small', { class: 'muted', dir: 'ltr', text: '@' + S.me.username })), h('span', { style: 'margin-inline-start:auto;color:var(--muted)' }, icon('settings'))));
    const bottom = h('nav', { class: 'bottom-nav' }, navLinks().map(([ic, href, label]) => {
      if (href === 'chat') return h('button', { 'data-nav': 'chat', onclick: () => toggleChat(true) }, icon(ic), h('span', { text: label }), S.unread ? h('span', { class: 'dot', text: S.unread }) : null);
      if (ic === 'plus') return h('a', { href, 'data-nav': href, 'aria-label': label }, h('span', { class: 'plus' }, icon('plus')));
      return h('a', { href, 'data-nav': href }, icon(ic), h('span', { text: label }));
    }));
    const searchIn = h('input', { class: 'input', type: 'search', placeholder: t('searchPh'), onkeydown: (e) => { if (e.key === 'Enter' && searchIn.value.trim()) location.hash = '#/explore?q=' + encodeURIComponent(searchIn.value.trim()); } });
    const aside = h('aside', { class: 'aside' },
      h('div', { class: 'search-wrap' }, icon('search'), searchIn),
      publishCard(),
      h('div', { class: 'muted', style: 'font-size:12px;padding:0 6px' }, 'مجازية · Majazia — ', t('tagline')));
    shell = { main, side, bottom, aside };
    $('#root').replaceChildren(h('div', { class: 'app' }, side, main, aside), bottom);
    S.mainRoute = null;
    route();
    startPolling();
  }
  function publishCard() {
    if (!S.me) return null;
    if (S.me.can_publish) {
      return h('div', { class: 'aside-box', style: 'border-color:rgba(31,164,99,.4)' },
        h('h4', { style: 'display:flex;gap:6px;align-items:center;color:#7fe0ae' }, icon('upload'), t('publish')),
        h('p', { class: 'muted', style: 'margin:0 0 10px;font-size:13px', text: S.me.publish_until === -1 || S.me.role !== 'user' ? t('canPublishForever') : t('canPublishUntil') + ' ' + fmtDate(S.me.publish_until) }),
        h('div', { style: 'display:flex;gap:8px' }, h('a', { class: 'btn primary sm', style: 'flex:1', href: '#/publish?type=reel' }, icon('video'), t('reels')), h('a', { class: 'btn ghost sm', style: 'flex:1', href: '#/publish?type=post' }, icon('image'), t('posts'))));
    }
    return null;
  }
  function markNav() {
    const hash = location.hash || '#/home';
    document.querySelectorAll('[data-nav]').forEach((el) => {
      const n = el.getAttribute('data-nav');
      el.classList.toggle('on', n !== 'chat' && (hash === n || hash.startsWith(n + '?') || (n.startsWith('#/u/') && hash === n)));
    });
  }
  function updateUnreadDots() {
    document.querySelectorAll('[data-nav=chat]').forEach((el) => {
      const d = el.querySelector('.dot');
      if (S.unread && !d) el.append(h('span', { class: 'dot', text: S.unread }));
      else if (d) { if (S.unread) d.textContent = S.unread; else d.remove(); }
    });
  }
  let pollTimer = null;
  function startPolling() {
    clearInterval(pollTimer);
    pollTimer = setInterval(async () => {
      if (document.hidden || !S.me) return;
      try { const c = await api('/api/config'); S.unread = c.unread || 0; S.cfg.staff = c.staff; S.cfg.maintenance = c.maintenance; if (c.maintenance && !c.staff) { renderMaintenance(); return; } if (c.me) { const was = S.me.can_publish; S.me = c.me; if (was !== c.me.can_publish) renderShell(); } updateUnreadDots(); } catch { /* */ }
    }, 30000);
  }

  // ================================================================ الموجّه
  function parseHash() {
    const raw = (location.hash || '#/home').slice(1);
    const [p, qs] = raw.split('?');
    const parts = p.split('/').filter(Boolean);
    return { parts, query: new URLSearchParams(qs || ''), key: raw };
  }
  function route() {
    if (!S.me || !shell) return;
    const r = parseHash();
    if (r.parts[0] === 'reel') { openViewerRoute(Number(r.parts[1])); return; }
    if (S.viewer) closeViewer(true);
    if (S.mainRoute === r.key) return;
    S.mainRoute = r.key;
    markNav();
    const main = shell.main;
    main.replaceChildren();
    window.scrollTo(0, 0);
    const v = r.parts[0] || 'home';
    if (v === 'home') return viewHome(main);
    if (v === 'explore') return viewExplore(main, r.query.get('q') || '');
    if (v === 'u') return viewProfile(main, decodeURIComponent(r.parts[1] || ''));
    if (v === 'post') return viewPost(main, Number(r.parts[1]));
    if (v === 'publish') return viewPublish(main, r.query.get('type'));
    if (v === 'settings') return viewSettings(main);
    if (v === 'staff' && S.cfg.staff) return viewStaff(main);
    location.hash = '#/home';
  }
  window.addEventListener('hashchange', () => { S.inApp++; route(); });

  function topbar(title, { backBtn = false, extra = null, chipsRow = null } = {}) {
    return h('header', { class: 'topbar' },
      h('div', { class: 'topbar-row' },
        h('div', { style: 'display:flex;align-items:center;gap:6px;min-width:0' },
          backBtn ? h('button', { class: 'icon-btn', 'aria-label': t('back'), onclick: goBack }, h('span', { style: S.lang === 'ar' ? 'transform:scaleX(-1);display:inline-flex' : 'display:inline-flex' }, icon('back'))) : null,
          title === 'logo' ? h('a', { href: '#/home' }, h('img', { class: 'logo', src: '/logo-light.png', alt: 'مجازية Majazia' })) : h('h1', { text: title })),
        h('div', { style: 'display:flex;align-items:center;gap:2px' }, extra)),
      chipsRow);
  }
  function goBack() { if (S.inApp > 0) history.back(); else location.hash = '#/home'; }
  function chipsBar(onPick) {
    const wrap = h('div', { class: 'chips' });
    const make = () => wrap.replaceChildren(...['', ...S.cfg.categories].map((c) => h('button', { class: 'chip' + (S.category === c ? ' on' : ''), text: c ? catName(c) : t('all'), onclick: () => { S.category = c; make(); onPick(); } })));
    make(); return wrap;
  }
  const loader = () => h('div', { class: 'spinner' });
  function emptyState(title, hint, ic = 'video') { return h('div', { class: 'empty' }, h('div', { html: `<svg class="i" viewBox="0 0 24 24" style="width:52px;height:52px;margin:0 auto 12px;display:block;color:#3c5248">${I[ic]}</svg>` }), h('h4', { text: title }), hint ? h('div', { text: hint }) : null); }
  function errorState(retry) { return h('div', { class: 'empty' }, h('h4', { text: t('err_network') }), h('button', { class: 'btn ghost sm', text: t('retry'), onclick: retry })); }

  // ================================================================ الرئيسية: ريلز فوق، ثم المنشورات
  function viewHome(main) {
    const reelsBox = h('div');
    const postsBox = h('div');
    const reload = () => { loadReels(); loadPosts(true); };
    const mobileTools = [
      h('a', { class: 'icon-btn', href: '#/explore', 'aria-label': t('explore') }, icon('search')),
      h('button', { class: 'icon-btn', 'aria-label': t('chat'), 'data-nav': 'chat', onclick: () => toggleChat(true) }, icon('chat'), S.unread ? h('span', { class: 'dot', text: S.unread, style: 'top:2px;inset-inline-end:2px' }) : null),
    ];
    main.append(topbar('logo', { extra: h('div', { class: 'mobile-only', style: 'display:flex' }, mobileTools), chipsRow: chipsBar(reload) }));
    if (S.me.can_publish) {
      main.append(h('a', { class: 'publish-banner', href: '#/publish' },
        h('div', { style: 'width:42px;height:42px;border-radius:12px;background:var(--primary);display:flex;align-items:center;justify-content:center;color:#fff' }, icon('plus')),
        h('div', { class: 'grow' }, h('b', { text: t('publish') }), h('small', { text: S.me.publish_until === -1 || S.me.role !== 'user' ? t('canPublishForever') : t('canPublishUntil') + ' ' + fmtDate(S.me.publish_until) })),
        h('span', { class: 'btn primary sm', text: t('reels') + ' / ' + t('posts') })));
    }
    main.append(reelsBox, h('div', { class: 'divider' }), h('div', { class: 'section-h' }, h('h3', {}, icon('comment'), t('posts'))), postsBox);

    let reelList = [];
    async function loadReels() {
      reelsBox.replaceChildren(h('div', { class: 'section-h' }, h('h3', {}, icon('video'), t('reels'))), h('div', { class: 'reel-strip' }, Array.from({ length: 4 }, () => h('div', { class: 'reel-card skeleton' }))));
      try {
        const r = await api('/api/feed?kind=reel&limit=20' + (S.category ? '&category=' + S.category : ''));
        reelList = r.posts;
        const head = h('div', { class: 'section-h' }, h('h3', {}, icon('video'), t('reels')), reelList.length ? h('button', { text: t('seeAll'), onclick: () => openViewer(reelList, 0) }) : null);
        if (!reelList.length) { reelsBox.replaceChildren(head, emptyState(t('noContent'), t('noContentHint'))); return; }
        reelsBox.replaceChildren(head, h('div', { class: 'reel-strip' }, reelList.map((p, i) => reelCard(p, () => openViewer(reelList, i)))));
      } catch { reelsBox.replaceChildren(errorState(loadReels)); }
    }
    let offset = 0, done = false, busy = false, io = null;
    async function loadPosts(reset) {
      if (reset) { offset = 0; done = false; postsBox.replaceChildren(loader()); if (io) io.disconnect(); }
      if (busy || done) return; busy = true;
      try {
        const r = await api(`/api/feed?kind=post&limit=15&offset=${offset}` + (S.category ? '&category=' + S.category : ''));
        if (reset) postsBox.replaceChildren();
        if (!r.posts.length && offset === 0) postsBox.append(emptyState(t('noContent'), t('noContentHint'), 'comment'));
        r.posts.forEach((p) => postsBox.append(postCard(p)));
        offset += r.posts.length;
        if (r.posts.length < 15) done = true;
        else { const s = h('div', { class: 'loadmore' }); postsBox.append(s); io = observeMore(s, () => { s.remove(); loadPosts(false); }); }
      } catch { if (reset) postsBox.replaceChildren(errorState(() => loadPosts(true))); }
      busy = false;
    }
    reload();
  }

  function reelCard(p, onclick) {
    const gold = p.author && p.author.verified === 'gold';
    return h('button', { class: 'reel-card' + (gold ? ' gold-card' : ''), onclick, 'aria-label': p.title },
      p.thumb ? h('img', { src: p.thumb, alt: '', loading: 'lazy' }) : h('div', { class: 'ph' }, icon('play')),
      h('div', { class: 'shade' }),
      p.duration ? h('span', { class: 'dur', text: fmtDur(p.duration) }) : null,
      gold ? h('span', { class: 'top-tag', text: '★' }) : null,
      p.part_no ? h('span', { class: 'part-tag', text: t('part') + ' ' + p.part_no }) : null,
      h('div', { class: 'meta', dir: 'auto', text: p.title }));
  }

  // ---------------------------------------------------------------- بطاقة منشور (مثل إكس)
  function postCard(p, { detail = false } = {}) {
    const a = p.author;
    const textEl = h('div', { class: 'post-text', dir: 'auto', text: p.body });
    let translated = false;
    const transBtn = (S.cfg.deepl && p.source_lang !== S.lang && p.body) ? h('button', { class: 'trans-link', text: t('translate'), onclick: async (e) => {
      e.stopPropagation();
      if (translated) { textEl.textContent = p.body; transBtn.textContent = t('translate'); translated = false; return; }
      transBtn.textContent = t('loading');
      try { const r = await api(`/api/posts/${p.id}?lang=${S.lang}`); if (r.post.translation) { textEl.textContent = r.post.translation.body; transBtn.textContent = t('showOriginal') + ' · ' + t('translatedBy'); translated = true; } else transBtn.textContent = t('translate'); }
      catch { transBtn.textContent = t('translate'); }
    } }) : null;
    const likeBtn = h('button', { class: 'act' + (p.liked ? ' liked' : ''), 'aria-label': t('like') }, icon('heart'), h('span', { text: p.likes ? fmtNum(p.likes) : '' }));
    likeBtn.addEventListener('click', async (e) => { e.stopPropagation(); await toggleLike(p, likeBtn); });
    const card = h('article', { class: 'post' + (a.verified === 'gold' ? ' gold-post' : ''), onclick: () => { if (!detail) location.hash = '#/post/' + p.id; } },
      h('a', { href: '#/u/' + a.username, onclick: (e) => e.stopPropagation() }, avatar(a)),
      h('div', { class: 'post-body' },
        h('div', { class: 'post-head' },
          h('a', { class: 'nm', href: '#/u/' + a.username, onclick: (e) => e.stopPropagation(), text: a.name }), badge(a.verified),
          h('span', { class: 'un', text: '@' + a.username }), h('span', { class: 'tm', text: '· ' + timeAgo(p.created_at) }),
          h('button', { class: 'more icon-btn', style: 'width:32px;height:32px', 'aria-label': t('more'), onclick: (e) => { e.stopPropagation(); moreSheet(p, () => card.remove()); } }, icon('more'))),
        h('span', { class: 'post-cat', text: catName(p.category) }),
        p.body ? textEl : null, transBtn,
        p.images.length ? h('div', { class: 'imgs n' + p.images.length }, p.images.map((src, i) => h('img', { src, alt: '', loading: 'lazy', onclick: (e) => { e.stopPropagation(); openImage(p, i); } }))) : null,
        h('div', { class: 'actions' },
          h('button', { class: 'act', 'aria-label': t('comments'), onclick: (e) => { e.stopPropagation(); if (detail) $('#cmt-input') && $('#cmt-input').focus(); else commentsSheet(p); } }, icon('comment'), h('span', { text: p.comments ? fmtNum(p.comments) : '' })),
          likeBtn,
          p.images.length ? h('button', { class: 'act dl', 'aria-label': t('download'), onclick: (e) => { e.stopPropagation(); downloadSheet(p); } }, icon('download'), h('span', { text: t('download') })) : null,
          h('button', { class: 'act', 'aria-label': t('share'), onclick: (e) => { e.stopPropagation(); share(p); } }, icon('share')))));
    return card;
  }
  function openImage(p, i) {
    const bg = h('div', { class: 'sheet-bg', style: 'align-items:center;background:rgba(0,0,0,.92)', onclick: () => bg.remove() },
      h('img', { src: p.images[i], alt: '', style: 'max-width:96vw;max-height:84vh;border-radius:8px' }),
      h('div', { style: 'position:fixed;bottom:calc(20px + var(--safe-b));left:50%;transform:translateX(-50%);display:flex;gap:10px' },
        h('button', { class: 'btn primary sm', onclick: (e) => { e.stopPropagation(); bg.remove(); downloadSheet(p, i); } }, icon('download'), t('download'))));
    document.body.append(bg);
  }
  async function toggleLike(p, btn) {
    try {
      const r = await api(`/api/posts/${p.id}/like`, { method: 'POST' });
      p.liked = r.liked; p.likes = r.likes;
      btn.classList.toggle('liked', r.liked);
      const span = btn.lastElementChild; if (span) span.textContent = r.likes || btn.closest('.side-acts') ? fmtNum(r.likes) : '';
    } catch (e) { toast(errText(e.code), true); }
  }
  async function share(p) {
    const url = location.origin + '/#/' + (p.kind === 'reel' ? 'reel/' : 'post/') + p.id;
    try { if (navigator.share) { await navigator.share({ title: p.title || 'Majazia', url }); return; } } catch { return; }
    try { await navigator.clipboard.writeText(url); toast(t('linkCopied')); } catch { toast(url); }
  }

  // ---------------------------------------------------------------- النوافذ السفلية
  function sheet(title, body, footer) {
    const bg = h('div', { class: 'sheet-bg' });
    const close = () => { bg.remove(); document.removeEventListener('keydown', esc); };
    const esc = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', esc);
    bg.addEventListener('click', (e) => { if (e.target === bg) close(); });
    const sh = h('div', { class: 'sheet', role: 'dialog' },
      h('div', { class: 'sheet-h' }, h('h3', { text: title }), h('button', { class: 'icon-btn', 'aria-label': t('close'), onclick: close }, icon('close'))),
      h('div', { class: 'sheet-b' }, body), footer || null);
    bg.append(sh); document.body.append(bg);
    return { close, body: sh.querySelector('.sheet-b'), el: sh };
  }
  function confirmSheet(msg, onYes, danger = true) {
    const s = sheet(t('sure'), h('div', {}, h('p', { text: msg, style: 'margin-top:0' }),
      h('div', { style: 'display:flex;gap:10px' }, h('button', { class: 'btn ghost', style: 'flex:1', text: t('cancel'), onclick: () => s.close() }),
        h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), style: 'flex:1', text: t('yes'), onclick: () => { s.close(); onYes(); } }))));
  }
  function moreSheet(p, onDeleted) {
    const own = S.me && p.author && S.me.id === p.author.id;
    const staff = !!S.cfg.staff;
    const s = sheet(t('more'), h('div', {},
      (p.images.length || p.kind === 'reel') ? h('button', { class: 'opt', onclick: () => { s.close(); downloadSheet(p); } }, h('span', { class: 'ic' }, icon('download')), h('div', {}, h('b', { text: t('download') }))) : null,
      h('button', { class: 'opt', onclick: () => { s.close(); share(p); } }, h('span', { class: 'ic' }, icon('link')), h('div', {}, h('b', { text: t('share') }))),
      !own ? h('button', { class: 'opt', onclick: () => { s.close(); reportSheet('post', p.id); } }, h('span', { class: 'ic', style: 'background:rgba(229,72,77,.12);color:#ff8b8f' }, icon('flag')), h('div', {}, h('b', { text: t('report') }))) : null,
      !own && p.author ? h('button', { class: 'opt', onclick: () => { s.close(); reportSheet('user', p.author.id); } }, h('span', { class: 'ic', style: 'background:rgba(229,72,77,.12);color:#ff8b8f' }, icon('user')), h('div', {}, h('b', { text: t('report') + ' @' + p.author.username }))) : null,
      (own || staff) ? h('button', { class: 'opt', onclick: () => { s.close(); confirmSheet(t('delete') + ({ ar: '؟', fr: ' ?' }[S.lang] || '?'), async () => { try { await api(`/api/posts/${p.id}/delete`, { method: 'POST' }); toast(t('saved')); onDeleted && onDeleted(); } catch (e) { toast(errText(e.code), true); } }); } }, h('span', { class: 'ic', style: 'background:rgba(229,72,77,.12);color:#ff8b8f' }, icon('trash')), h('div', {}, h('b', { text: t('delete') }))) : null));
  }
  function reportSheet(type, id) {
    let reason = '';
    const details = h('textarea', { class: 'input', placeholder: t('reportDetails'), maxlength: 500, style: 'min-height:70px' });
    const send = h('button', { class: 'btn primary block', disabled: true, text: t('send') });
    const list = h('div', { class: 'radio-list' }, S.cfg.report_reasons.map((r) => h('label', {}, h('input', { type: 'radio', name: 'rr', value: r, onchange: () => { reason = r; send.disabled = false; } }), h('span', { text: t('rr_' + r) }))));
    const s = sheet(t('reportTitle'), h('div', {}, list, h('div', { style: 'height:12px' }), details, h('div', { style: 'height:12px' }), send));
    send.addEventListener('click', async () => {
      send.disabled = true;
      try { await api('/api/reports', { method: 'POST', body: { target_type: type, target_id: id, reason, details: details.value } }); s.close(); toast(t('reportSent')); }
      catch (e) { toast(errText(e.code), true); send.disabled = false; }
    });
  }
  function downloadSheet(p, index = 0) {
    const s = sheet(t('downloadTitle'), h('div', {},
      h('button', { class: 'opt goldopt', onclick: () => doDownload(true) }, h('span', { class: 'ic', style: 'width:auto;padding:0 8px' }, h('img', { src: '/logo-light.png', alt: '', style: 'height:26px' })), h('div', {}, h('b', { text: t('downloadWith') }), h('small', { text: t('downloadWithHint') }))),
      h('button', { class: 'opt', onclick: () => doDownload(false) }, h('span', { class: 'ic' }, icon('download')), h('div', {}, h('b', { text: t('downloadWithout') }), h('small', { text: t('downloadWithoutHint') })))));
    async function doDownload(mark) {
      const bar = h('div'); const lbl = h('div', { class: 'muted', text: t('preparing'), style: 'text-align:center' });
      const prog = h('div', { class: 'progress' }, bar);
      s.body.replaceChildren(lbl, prog);
      try {
        let r = await api(`/api/posts/${p.id}/export`, { method: 'POST', body: { mark, index } });
        const job = r.job;
        while (r.status !== 'done') {
          if (r.status === 'error') throw new Error('export_failed');
          bar.style.width = Math.max(5, r.progress || 0) + '%';
          await new Promise((res) => setTimeout(res, 1500));
          if (!document.body.contains(s.el)) return;
          r = await api('/api/export/' + job);
        }
        bar.style.width = '100%';
        const name = `majazia-${p.id}${mark ? '-majazia' : ''}`;
        lbl.textContent = t('downloadReady');
        const a = h('a', { class: 'btn primary block', href: r.url, download: name, text: t('downloadNow'), onclick: () => setTimeout(() => s.close(), 400) });
        s.body.append(h('div', { style: 'height:12px' }), a);
        a.click();
      } catch { lbl.textContent = t('downloadFailed'); }
    }
  }
  function commentsSheet(p, onCount) {
    const list = h('div', {}, loader());
    const input = h('textarea', { class: 'input', placeholder: t('writeComment'), maxlength: 500, rows: 1 });
    const sendBtn = h('button', { class: 'icon-btn', style: 'background:var(--primary);color:#fff', 'aria-label': t('send') }, icon('send'));
    const partsBox = h('div');
    const s = sheet(t('comments'), h('div', {}, partsBox, list), h('div', { class: 'sheet-f' }, input, sendBtn));
    // الأجزاء مثبّتة أعلى التعليقات (جزء 1، جزء 2…)
    if (p.series_id) {
      api(`/api/posts/${p.id}/parts`).then((r) => {
        if (!r.parts || r.parts.length < 2) return;
        partsBox.replaceChildren(h('div', { class: 'parts-pin' },
          h('div', { class: 'parts-h' }, icon('link'), h('b', { text: t('allParts') + ' (' + r.parts.length + ')' })),
          h('div', { class: 'parts-row' }, r.parts.map((x, i) => h('button', { class: 'part-chip' + (x.id === p.id ? ' on' : ''), onclick: () => { s.close(); openSeries(r.parts, i); } },
            x.thumb ? h('img', { src: x.thumb, alt: '' }) : h('span', { class: 'ph' }, icon('play')),
            h('span', {}, h('b', { text: t('part') + ' ' + x.part_no }), h('small', { dir: 'auto', text: x.title })))))));
      }).catch(() => {});
    }
    async function load() {
      try {
        const r = await api(`/api/posts/${p.id}/comments`);
        list.replaceChildren(...(r.comments.length ? r.comments.map((c) => commentEl(c, p, load)) : [h('div', { class: 'empty', style: 'padding:30px', text: t('noComments') })]));
        p.comments = r.comments.length; onCount && onCount(p.comments);
      } catch { list.replaceChildren(errorState(load)); }
    }
    sendBtn.addEventListener('click', async () => {
      const body = input.value.trim(); if (!body) return;
      sendBtn.disabled = true;
      try { await api(`/api/posts/${p.id}/comments`, { method: 'POST', body: { body } }); input.value = ''; await load(); s.body.scrollTop = 0; }
      catch (e) { toast(errText(e.code), true); }
      sendBtn.disabled = false;
    });
    load();
  }
  function commentEl(c, p, reload) {
    const mine = S.me && c.author.id === S.me.id;
    const canDel = mine || !!S.cfg.staff || (p.author && S.me && p.author.id === S.me.id);
    return h('div', { class: 'comment' },
      h('a', { href: '#/u/' + c.author.username }, avatar(c.author, 'sm')),
      h('div', { class: 'cb' },
        h('div', { class: 'ch' }, h('b', { text: c.author.name }), badge(c.author.verified), h('span', { class: 'muted', dir: 'ltr', text: '@' + c.author.username })),
        h('div', { class: 'ct', text: c.body }),
        h('div', { class: 'cx' }, h('span', { text: timeAgo(c.created_at) }),
          !mine ? h('button', { text: t('report'), onclick: () => reportSheet('comment', c.id) }) : null,
          canDel ? h('button', { text: t('delete'), onclick: () => confirmSheet(t('delete') + ({ ar: '؟', fr: ' ?' }[S.lang] || '?'), async () => { try { await api(`/api/comments/${c.id}/delete`, { method: 'POST' }); reload(); } catch (e) { toast(errText(e.code), true); } }) }) : null)));
  }

  // ================================================================ عارض الريلز
  async function openViewerRoute(id) {
    if (S.viewer && S.viewer.currentId === id) return;
    if (S.viewer) { if (S.viewer.goTo(id)) return; S.viewer.destroy(); S.viewer = null; S.viewerList = null; }
    let list = S.viewerList;
    let start = list ? list.findIndex((p) => p.id === id) : -1;
    if (start < 0) {
      try {
        const [one, more] = await Promise.all([api('/api/posts/' + id), api('/api/feed?kind=reel&limit=20')]);
        list = [one.post, ...more.posts.filter((x) => x.id !== id)]; start = 0;
      } catch { toast(t('err_not_found'), true); location.hash = '#/home'; return; }
      if (!shell.main.childElementCount) { S.mainRoute = '/home'; viewHome(shell.main); markNav(); }
    }
    buildViewer(list, start);
  }
  function openSeries(parts, idx) {
    if (S.viewer) { S.viewer.destroy(); S.viewer = null; }
    if (!location.hash.startsWith('#/reel/')) { S.viewerList = parts.slice(); location.hash = '#/reel/' + parts[idx].id; return; }
    history.replaceState(null, '', '#/reel/' + parts[idx].id);
    buildViewer(parts, idx);
  }
  function openViewer(list, idx) {
    S.viewerList = list.slice();
    location.hash = '#/reel/' + list[idx].id;
  }
  function closeViewer(fromRoute) {
    if (!S.viewer) return;
    S.viewer.destroy(); S.viewer = null;
    document.body.style.overflow = '';
    if (!fromRoute) goBack();
  }
  function buildViewer(list, start) {
    document.body.style.overflow = 'hidden';
    const scroller = h('div', { class: 'viewer-scroll' });
    const ccBtn = h('button', { class: 'icon-btn cc' + (S.cc ? ' on' : ''), 'aria-label': t('subtitles'), onclick: () => { S.cc = !S.cc; LS.set('mjz_cc', S.cc ? '1' : '0'); ccBtn.classList.toggle('on', S.cc); slides.forEach((sl) => sl.renderSub()); } }, icon('cc'));
    const root = h('div', { class: 'viewer' }, scroller,
      h('div', { class: 'viewer-top' },
        h('button', { class: 'icon-btn', 'aria-label': t('back'), onclick: () => closeViewer(false) }, h('span', { style: S.lang === 'ar' ? 'transform:scaleX(-1);display:inline-flex' : 'display:inline-flex' }, icon('back'))),
        h('img', { src: '/logo-light.png', alt: 'Majazia', style: 'height:30px;opacity:.9' }),
        ccBtn),
      h('div', { class: 'viewer-hint', text: '↕ ' + t('swipeHint') }));
    document.body.append(root);
    const slides = [];
    let active = -1, loadingMore = false, noMore = false;

    function makeSlide(p, i) {
      const video = h('video', { playsinline: true, 'webkit-playsinline': true, preload: 'none', loop: true, poster: p.thumb || undefined });
      video.disablePictureInPicture = true;
      const sub = h('div', { class: 'subline' });
      const range = h('input', { type: 'range', min: 0, max: 1000, value: 0, 'aria-label': 'seek' });
      const tm = h('span', { class: 't', text: '0:00 / ' + fmtDur(p.duration) });
      const likeB = h('button', { class: p.liked ? 'liked' : '', 'aria-label': t('like') }, h('span', { class: 'circle' }, icon('heart')), h('span', { text: fmtNum(p.likes || 0) }));
      const cmtB = h('button', { 'aria-label': t('comments') }, h('span', { class: 'circle' }, icon('comment')), h('span', { text: fmtNum(p.comments || 0) }));
      const titleEl = h('p', { class: 'ttl', dir: 'auto', text: p.title });
      const descEl = p.body ? h('p', { class: 'desc', dir: 'auto', text: p.body, onclick: (e) => e.currentTarget.classList.toggle('open') }) : null;
      const transTag = h('span', { class: 'muted', style: 'font-size:11px;display:none' });
      const el = h('section', { class: 'slide is-paused', 'data-i': i },
        p.thumb ? h('img', { class: 'poster', src: p.thumb, alt: '' }) : null,
        video, h('div', { class: 'tap' }), h('div', { class: 'paused' }, icon('play', 'fill')), sub,
        h('div', { class: 'side-acts' },
          h('a', { href: '#/u/' + p.author.username, onclick: (e) => { e.preventDefault(); closeViewer(true); location.hash = '#/u/' + p.author.username; } }, avatar(p.author)),
          likeB, cmtB,
          h('button', { class: 'dl', 'aria-label': t('download'), onclick: () => downloadSheet(p) }, h('span', { class: 'circle' }, icon('download')), h('span', { text: t('download') })),
          h('button', { 'aria-label': t('share'), onclick: () => share(p) }, h('span', { class: 'circle' }, icon('share')), h('span', { text: t('share') })),
          h('button', { 'aria-label': t('more'), onclick: () => moreSheet(p, () => { closeViewer(false); }) }, h('span', { class: 'circle' }, icon('more')))),
        h('div', { class: 'reel-info' },
          h('div', { class: 'who' }, h('span', { text: p.author.name }), badge(p.author.verified), h('span', { class: 'muted', dir: 'ltr', style: 'font-weight:400;font-size:13px', text: '@' + p.author.username })),
          p.part_no ? h('div', { class: 'part-line' }, h('span', { class: 'part-badge', text: t('part') + ' ' + p.part_no + (p.part_count > 1 ? ' / ' + p.part_count : '') }),
            p.part_no < p.part_count ? h('button', { class: 'part-next', onclick: () => api(`/api/posts/${p.id}/parts`).then((r) => { const k = r.parts.findIndex((x) => x.part_no > p.part_no); if (k >= 0) openSeries(r.parts, k); }).catch(() => {}) }, t('nextPart'), ' ›') : null,
            p.part_count > 1 ? h('button', { class: 'part-next', onclick: () => commentsSheet(p) }, t('allParts')) : null) : null,
          titleEl, descEl, h('span', { class: 'cat', text: '#' + catName(p.category) }), ' ', transTag),
        h('div', { class: 'scrub' }, range, tm));
      likeB.addEventListener('click', () => toggleLike(p, likeB));
      cmtB.addEventListener('click', () => commentsSheet(p, (n) => { cmtB.lastChild.textContent = fmtNum(n); }));
      el.querySelector('.tap').addEventListener('click', () => { if (video.paused) video.play().catch(() => {}); else video.pause(); });
      video.addEventListener('play', () => el.classList.remove('is-paused'));
      video.addEventListener('pause', () => el.classList.add('is-paused'));
      let seeking = false;
      range.addEventListener('input', () => { seeking = true; const d = video.duration || p.duration; if (d) tm.textContent = fmtDur(range.value / 1000 * d) + ' / ' + fmtDur(d); });
      range.addEventListener('change', () => { const d = video.duration || p.duration; if (d) video.currentTime = range.value / 1000 * d; seeking = false; });
      let cues = null; let lastCue = -1;
      function renderSub() {
        if (!S.cc || !cues || !cues.length) { sub.replaceChildren(); lastCue = -1; return; }
        const ct = video.currentTime;
        let k = -1;
        for (let j = 0; j < cues.length; j++) { if (ct >= cues[j].start && ct <= cues[j].end) { k = j; break; } if (cues[j].start > ct) break; }
        if (k === lastCue) return; lastCue = k;
        sub.replaceChildren(...(k >= 0 ? [h('span', { text: cues[k].text })] : []));
      }
      video.addEventListener('timeupdate', () => {
        const d = video.duration || p.duration;
        if (d && !seeking) { range.value = Math.round(video.currentTime / d * 1000); tm.textContent = fmtDur(video.currentTime) + ' / ' + fmtDur(d); }
        renderSub();
      });
      let detailsLoaded = false; let viewed = false;
      async function loadDetails() {
        if (detailsLoaded) return; detailsLoaded = true;
        try {
          const r = await api(`/api/posts/${p.id}?lang=${S.lang}`);
          const tr = r.post.translation;
          cues = tr && tr.subtitles && tr.subtitles.length ? tr.subtitles : r.post.subtitles;
          if (tr) {
            if (tr.title) titleEl.textContent = tr.title;
            if (tr.body && descEl) descEl.textContent = tr.body;
            transTag.textContent = '· ' + t('translatedBy'); transTag.style.display = '';
          }
          renderSub();
        } catch { detailsLoaded = false; }
      }
      return {
        el, p, renderSub,
        activate() {
          if (!video.src) { video.src = p.video; video.preload = 'auto'; }
          loadDetails();
          video.play().catch(() => { el.classList.add('is-paused'); });
          if (!viewed) { viewed = true; api(`/api/posts/${p.id}/view`, { method: 'POST' }).catch(() => {}); }
        },
        prepare() { if (!video.src) { video.preload = 'metadata'; video.src = p.video; } loadDetails(); },
        deactivate() { video.pause(); },
        unload() { if (video.src) { video.pause(); video.removeAttribute('src'); video.load(); } },
      };
    }
    function addSlides(items) {
      for (const p of items) { const sl = makeSlide(p, slides.length); slides.push(sl); scroller.append(sl.el); io.observe(sl.el); }
    }
    const io = new IntersectionObserver((ents) => {
      for (const e of ents) if (e.isIntersecting && e.intersectionRatio >= 0.6) setActive(Number(e.target.dataset.i));
    }, { root: scroller, threshold: [0.6] });
    function setActive(i) {
      if (i === active) return;
      if (slides[active]) slides[active].deactivate();
      active = i;
      const cur = slides[i];
      S.viewer.currentId = cur.p.id;
      history.replaceState(null, '', '#/reel/' + cur.p.id);
      cur.activate();
      if (slides[i + 1]) slides[i + 1].prepare();
      slides.forEach((sl, j) => { if (Math.abs(j - i) > 2) sl.unload(); });
      if (i >= slides.length - 3) loadMore();
    }
    async function loadMore() {
      if (loadingMore || noMore) return; loadingMore = true;
      try {
        const r = await api(`/api/feed?kind=reel&limit=15&offset=${slides.length}` + (S.category ? '&category=' + S.category : ''));
        const have = new Set(slides.map((s) => s.p.id));
        const fresh = r.posts.filter((x) => !have.has(x.id));
        if (!fresh.length) noMore = true; else addSlides(fresh);
      } catch { /* */ }
      loadingMore = false;
    }
    const onKey = (e) => {
      if (document.querySelector('.sheet-bg')) return;
      if (e.key === 'ArrowDown') scroller.scrollBy({ top: innerHeight, behavior: 'smooth' });
      if (e.key === 'ArrowUp') scroller.scrollBy({ top: -innerHeight, behavior: 'smooth' });
      if (e.key === 'Escape') closeViewer(false);
      if (e.key === ' ') { e.preventDefault(); const v = slides[active] && slides[active].el.querySelector('video'); if (v) { if (v.paused) v.play().catch(() => {}); else v.pause(); } }
    };
    document.addEventListener('keydown', onKey);
    const onVis = () => { if (document.hidden && slides[active]) slides[active].deactivate(); };
    document.addEventListener('visibilitychange', onVis);
    S.viewer = {
      currentId: list[start].id,
      goTo(id) { const k = slides.findIndex((s) => s.p.id === id); if (k >= 0) { slides[k].el.scrollIntoView(); return true; } return false; },
      destroy() { io.disconnect(); slides.forEach((s) => s.unload()); root.remove(); document.removeEventListener('keydown', onKey); document.removeEventListener('visibilitychange', onVis); },
    };
    addSlides(list);
    requestAnimationFrame(() => { slides[start].el.scrollIntoView({ block: 'start' }); setActive(start); });
  }

  // ================================================================ استكشف + البحث
  function viewExplore(main, initialQ) {
    const input = h('input', { class: 'input', type: 'search', placeholder: t('searchPh'), value: initialQ, enterkeyhint: 'search' });
    const results = h('div');
    let timer = null;
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(load, 380); });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { clearTimeout(timer); load(); input.blur(); } });
    main.append(topbar(t('explore'), { chipsRow: h('div', {}, h('div', { style: 'padding:0 12px 10px' }, h('div', { class: 'search-wrap' }, icon('search'), input)), chipsBar(load)) }));
    main.append(results);
    async function load() {
      const q = input.value.trim();
      history.replaceState(null, '', '#/explore' + (q ? '?q=' + encodeURIComponent(q) : ''));
      S.mainRoute = parseHash().key;
      results.replaceChildren(loader());
      const qs = (q ? '&q=' + encodeURIComponent(q.replace(/^@/, '')) : '') + (S.category ? '&category=' + S.category : '');
      try {
        const [reels, posts] = await Promise.all([api('/api/feed?kind=reel&order=explore&limit=30' + qs), api('/api/feed?kind=post&order=explore&limit=30' + qs)]);
        const ql = q.replace(/^@/, '').toLowerCase(); const people = new Map();
        if (ql) {
          [...reels.posts, ...posts.posts].forEach((p) => { const a = p.author; if (a && (a.username.includes(ql) || String(a.name).toLowerCase().includes(ql))) people.set(a.username, a); });
          if (/^[a-z0-9_.]{3,20}$/.test(ql) && !people.has(ql)) { try { const u = (await api('/api/users/' + ql)).user; people.set(u.username, u); } catch { /* لا يوجد */ } }
        }
        results.replaceChildren();
        if (people.size) {
          results.append(h('div', { class: 'section-h' }, h('h3', {}, icon('user'), (I18N[S.lang] || I18N.ar).accounts || { ar: 'الحسابات', en: 'Accounts', fr: 'Comptes' }[S.lang])),
            ...[...people.values()].slice(0, 5).map((u) => h('a', { class: 'list-item', href: '#/u/' + u.username }, avatar(u), h('div', { class: 'grow' }, h('b', { style: 'display:flex;gap:4px;align-items:center' }, u.name, badge(u.verified)), h('small', { dir: 'ltr', text: '@' + u.username })))));
        }
        if (!reels.posts.length && !posts.posts.length) { if (people.size) return; results.append(emptyState(q ? t('noResults') : t('noContent'), q ? null : t('noContentHint'), 'search')); return; }
        if (reels.posts.length) {
          results.append(h('div', { class: 'section-h' }, h('h3', {}, icon('video'), t('reels'))),
            h('div', { class: 'reel-grid' }, reels.posts.map((p, i) => reelCard(p, () => openViewer(reels.posts, i)))));
        }
        if (posts.posts.length) {
          results.append(h('div', { class: 'divider' }), h('div', { class: 'section-h' }, h('h3', {}, icon('comment'), t('posts'))));
          posts.posts.forEach((p) => results.append(postCard(p)));
        }
      } catch { results.replaceChildren(errorState(load)); }
    }
    load();
    if (!initialQ && matchMedia('(min-width: 900px)').matches) input.focus();
  }

  // ================================================================ الحساب العام
  async function viewProfile(main, username) {
    main.append(topbar('', { backBtn: true }));
    const body = h('div', {}, loader()); main.append(body);
    let data;
    try { data = await api('/api/users/' + encodeURIComponent(username)); }
    catch (e) { body.replaceChildren(emptyState(errText(e.code), null, 'user')); return; }
    const u = data.user; const self = S.me.id === u.id;
    main.querySelector('.topbar-row > div').append(h('div', {}, h('b', { style: 'display:flex;gap:4px;align-items:center' }, u.name, badge(u.verified)), h('small', { class: 'muted', text: (data.counts.reels + data.counts.posts) + ' ' + t('posts') })));
    const actions = self
      ? h('a', { class: 'btn ghost sm', href: '#/settings' }, icon('settings'), t('editProfile'))
      : h('div', { style: 'display:flex;gap:8px' },
          h('button', { class: 'icon-btn', style: 'border:1px solid var(--border)', 'aria-label': t('report'), onclick: () => reportSheet('user', u.id) }, icon('flag')),
          h('button', { class: 'btn primary sm', onclick: () => toggleChat(true, u.username) }, icon('chat'), t('message')));
    let tab = 'reel';
    const list = h('div');
    const tabs = h('div', { class: 'tabs' },
      h('button', { class: 'on', text: t('reels') + ' · ' + data.counts.reels, onclick: (e) => setTab('reel', e.currentTarget) }),
      h('button', { text: t('posts') + ' · ' + data.counts.posts, onclick: (e) => setTab('post', e.currentTarget) }));
    function setTab(k, btn) { tab = k; [...tabs.children].forEach((b) => b.classList.toggle('on', b === btn)); loadTab(); }
    async function loadTab() {
      list.replaceChildren(loader());
      try {
        const r = await api(`/api/users/${encodeURIComponent(u.username)}?kind=${tab}`);
        if (!r.posts.length) { list.replaceChildren(emptyState(t('noContent'), null, tab === 'reel' ? 'video' : 'comment')); return; }
        list.replaceChildren(tab === 'reel' ? h('div', { class: 'reel-grid' }, r.posts.map((p, i) => reelCard(p, () => openViewer(r.posts, i)))) : h('div', {}, r.posts.map((p) => postCard(p))));
      } catch { list.replaceChildren(errorState(loadTab)); }
    }
    body.replaceChildren(
      h('div', { class: 'cover' }, h('img', { src: '/logo-light.png', alt: '' })),
      h('div', { class: 'prof' },
        h('div', { class: 'prof-top' }, avatar(u, 'lg'), actions),
        h('h2', {}, h('span', { text: u.name }), badge(u.verified)),
        h('span', { class: 'un', text: '@' + u.username }),
        u.verified !== 'none' ? h('div', { class: u.verified === 'gold' ? 'gold' : '', style: 'font-size:13px;margin-top:4px;' + (u.verified === 'blue' ? 'color:var(--blue)' : ''), text: u.verified === 'gold' ? t('verifiedGold') : t('verifiedBlue') }) : null,
        u.bio ? h('p', { class: 'bio', dir: 'auto', text: u.bio }) : h('div', { style: 'height:10px' }),
        h('div', { class: 'stats' }, h('span', {}, h('b', { text: data.counts.reels }), ' ' + t('reelsCount')), h('span', {}, h('b', { text: data.counts.posts }), ' ' + t('postsCount')), h('span', { text: t('joined') + ' ' + fmtDate(u.created_at) }))),
      tabs, list);
    loadTab();
  }

  // ================================================================ صفحة منشور + التعليقات
  async function viewPost(main, id) {
    main.append(topbar(t('posts'), { backBtn: true }));
    const body = h('div', {}, loader()); main.append(body);
    try {
      const r = await api('/api/posts/' + id);
      const p = r.post;
      if (p.kind === 'reel') { S.viewerList = null; location.replace('#/reel/' + p.id); return; }
      const list = h('div', { style: 'padding:0 14px' }, loader());
      const input = h('textarea', { class: 'input', id: 'cmt-input', placeholder: t('writeComment'), maxlength: 500, rows: 1 });
      const btn = h('button', { class: 'btn primary sm', text: t('send') });
      body.replaceChildren(postCard(p, { detail: true }), h('div', { class: 'sheet-f', style: 'border-top:0;border-bottom:1px solid var(--border)' }, input, btn), list);
      async function load() {
        try { const c = await api(`/api/posts/${p.id}/comments`); list.replaceChildren(...(c.comments.length ? c.comments.map((x) => commentEl(x, p, load)) : [h('div', { class: 'empty', style: 'padding:30px', text: t('noComments') })])); }
        catch { list.replaceChildren(errorState(load)); }
      }
      btn.addEventListener('click', async () => {
        const v = input.value.trim(); if (!v) return; btn.disabled = true;
        try { await api(`/api/posts/${p.id}/comments`, { method: 'POST', body: { body: v } }); input.value = ''; load(); } catch (e) { toast(errText(e.code), true); }
        btn.disabled = false;
      });
      load();
    } catch (e) { body.replaceChildren(emptyState(errText(e.code), null, 'comment')); }
  }

  // ================================================================ النشر
  function viewPublish(main, type) {
    main.append(topbar(t('publishTitle'), { backBtn: true }));
    const wrap = h('div', { class: 'panel' }); main.append(wrap);
    if (!S.me.can_publish) {
      const code = h('input', { class: 'input ltr', placeholder: 'XXXXX-XXXXX', maxlength: 14, style: 'text-transform:uppercase;letter-spacing:2px;text-align:center;font-size:18px' });
      const btn = h('button', { class: 'btn primary block', text: t('redeem') });
      btn.addEventListener('click', async () => {
        if (!code.value.trim()) return; btn.disabled = true;
        try { await api('/api/me/redeem', { method: 'POST', body: { code: code.value } }); toast(t('codeOk')); const c = await api('/api/config'); S.me = c.me; renderShell(); }
        catch (e) { toast(errText(e.code), true); btn.disabled = false; }
      });
      wrap.append(h('div', { class: 'card', style: 'max-width:none' },
        h('div', { style: 'color:var(--gold);margin-bottom:6px' }, icon('lock')),
        h('h2', { text: t('noPublish') }), h('p', { class: 'sub', text: t('noPublishHint') }),
        h('label', { class: 'field' }, h('span', { text: t('codePh') }), code), btn,
        h('div', { style: 'height:16px' }),
        h('button', { class: 'btn ghost block', onclick: requestPublishSheet }, icon('upload'), t('requestPublish')),
        h('div', { style: 'height:10px' }),
        h('button', { class: 'btn ghost block', onclick: () => toggleChat(true, 'majazia') }, icon('chat'), t('contactAdmin'))));
      if (S.cfg.freeze_publishing) wrap.prepend(h('div', { class: 'error-box', text: t('publishingFrozen') }));
      return;
    }
    if (type !== 'reel' && type !== 'post') {
      wrap.append(
        h('a', { class: 'opt', href: '#/publish?type=reel' }, h('span', { class: 'ic' }, icon('video')), h('div', {}, h('b', { text: t('newReel') }), h('small', { text: t('videoRules') }))),
        h('a', { class: 'opt', href: '#/publish?type=post' }, h('span', { class: 'ic' }, icon('image')), h('div', {}, h('b', { text: t('newPost') }), h('small', { text: t('addImages') }))),
        h('p', { class: 'muted', style: 'font-size:13px', text: S.me.publish_until === -1 || S.me.role !== 'user' ? t('canPublishForever') : t('canPublishUntil') + ' ' + fmtDate(S.me.publish_until) }));
      return;
    }
    const staff = S.me.role === 'founder'; // منشورات المشرفين تمر بالمراجعة أيضاً
    const err = h('div', { class: 'error-box hidden' });
    const showErr = (m) => { err.textContent = m; err.classList.remove('hidden'); err.scrollIntoView({ block: 'center' }); };
    const catSel = h('select', { class: 'input' }, S.cfg.categories.map((c) => h('option', { value: c, text: catName(c) })));
    const langSel = h('select', { class: 'input' }, ['ar', 'en', 'fr'].map((l) => h('option', { value: l, text: I18N[l].langName, selected: l === S.lang })));
    const progWrap = h('div', { class: 'hidden' }, h('div', { class: 'muted', style: 'font-size:13px' }), h('div', { class: 'progress' }, h('div')));
    const setProg = (label, pct) => { progWrap.classList.remove('hidden'); progWrap.firstChild.textContent = label + (pct != null ? ' ' + pct + '%' : ''); progWrap.querySelector('.progress > div').style.width = (pct || 0) + '%'; };
    const submit = h('button', { class: 'btn primary block', text: staff ? t('submitNow') : t('submit') });
    const field = (label, input, hint) => h('label', { class: 'field' }, h('span', { text: label }), input, hint ? h('div', { class: 'hint', text: hint }) : null);

    if (type === 'reel') {
      let file = null, duration = 0;
      const fileIn = h('input', { type: 'file', accept: 'video/mp4,video/quicktime,video/webm,video/*', class: 'sr' });
      const preview = h('div');
      const drop = h('label', { class: 'drop' }, fileIn, h('div', { html: `<svg class="i" viewBox="0 0 24 24" style="width:40px;height:40px;margin:0 auto 8px;display:block;color:var(--primary)">${I.upload}</svg>` }), h('b', { text: t('pickVideo') }), h('div', { class: 'muted', style: 'font-size:13px', text: t('videoRules') }));
      let previewVideo = null;
      fileIn.addEventListener('change', () => {
        const f = fileIn.files[0]; if (!f) return;
        err.classList.add('hidden');
        if (f.size > S.cfg.max_video_mb * 1024 * 1024) { showErr(t('videoTooBig')); return; }
        const url = URL.createObjectURL(f);
        const v = h('video', { src: url, controls: true, playsinline: true, preload: 'metadata', muted: true });
        v.addEventListener('loadedmetadata', () => {
          duration = v.duration;
          if (duration > S.cfg.max_video_seconds + 1) { showErr(t('videoTooLong') + ' (' + fmtDur(duration) + ')'); file = null; preview.replaceChildren(); drop.classList.remove('hidden'); return; }
          file = f; previewVideo = v;
          v.currentTime = Math.min(1, duration / 3);
        });
        v.addEventListener('error', () => showErr(t('err_bad_file_type')));
        preview.replaceChildren(h('div', { class: 'vid-prev' }, v), h('button', { class: 'btn ghost sm', style: 'margin:8px 0 14px', text: t('changeVideo'), onclick: () => fileIn.click() }));
        drop.classList.add('hidden');
      });
      const title = h('input', { class: 'input', maxlength: 120 });
      const desc = h('textarea', { class: 'input', maxlength: 2000 });
      const subsInput = h('input', { type: 'file', accept: '.srt,.vtt,text/vtt,application/x-subrip,text/plain', class: 'sr' });
      const subsName = h('span', { class: 'muted', style: 'font-size:13px', dir: 'auto' });
      const subsFile = h('label', { style: 'display:flex;gap:10px;align-items:center;cursor:pointer' }, subsInput, h('span', { class: 'btn ghost sm' }, icon('upload'), t('subsFile').split(' (')[0]), subsName);
      const subsText = h('textarea', { class: 'input ltr', placeholder: '1\n00:00:01,000 --> 00:00:04,000\n…', style: 'min-height:80px;font-size:13px;font-variant-numeric:tabular-nums' });
      subsInput.addEventListener('change', async () => { const f = subsInput.files[0]; if (f && f.size < 2 * 1024 * 1024) { subsText.value = await f.text(); subsName.textContent = f.name; } });
      const noMusic = h('input', { type: 'checkbox' });
      const seriesSel = h('select', { class: 'input' }, h('option', { value: '', text: t('seriesNone') }));
      api('/api/my/reels').then((r) => { for (const x of r.reels) seriesSel.append(h('option', { value: x.id, text: (x.part_no ? t('part') + ' ' + x.part_no + ' · ' : '') + x.title })); }).catch(() => {});
      wrap.append(err, drop, preview,
        field(t('title'), title), field(t('description'), desc),
        field(t('seriesLabel'), seriesSel, t('seriesHint')),
        h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' }, field(t('category'), catSel), field(t('videoLang'), langSel)),
        field(t('subsFile'), subsFile, t('subsHint')), field(t('subsPaste'), subsText),
        h('label', { class: 'check' }, noMusic, h('span', { text: t('noMusicConfirm') })),
        progWrap, submit);
      submit.addEventListener('click', async () => {
        err.classList.add('hidden');
        if (!file) return showErr(t('err_video_required'));
        if (!title.value.trim()) return showErr(t('err_title_required'));
        if (!noMusic.checked) return showErr(t('err_confirm_no_music'));
        submit.disabled = true;
        try {
          let thumbId = null;
          try {
            const blob = await captureFrame(previewVideo);
            if (blob) thumbId = (await api('/api/upload/image', { method: 'POST', raw: blob, headers: { 'Content-Type': 'application/octet-stream' } })).id;
          } catch { /* الصورة المصغرة اختيارية */ }
          const up = await uploadWithProgress('/api/upload/video', file, { 'X-Duration': String(Math.round(duration)) }, (pct) => setProg(t('uploading'), pct));
          setProg(t('processing'), 100);
          const r = await api('/api/posts', { method: 'POST', body: { kind: 'reel', title: title.value, body: desc.value, category: catSel.value, source_lang: langSel.value, video_id: up.id, thumb_id: thumbId, subtitles: subsText.value, no_music: true, continues: seriesSel.value ? Number(seriesSel.value) : undefined } });
          toast(r.status === 'approved' ? t('publishedOk') : t('sentForReview'));
          location.hash = '#/settings';
        } catch (e) { showErr(errText(e.code)); submit.disabled = false; progWrap.classList.add('hidden'); }
      });
    } else {
      const text = h('textarea', { class: 'input', placeholder: t('postText'), maxlength: 2000, style: 'min-height:140px;font-size:16px' });
      const imgs = [];
      const prev = h('div', { class: 'img-prev' });
      const imgIn = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif', multiple: true, class: 'sr' });
      const addBtn = h('label', { class: 'btn ghost sm', style: 'margin-bottom:14px' }, imgIn, icon('image'), t('addImages'));
      const draw = () => { prev.replaceChildren(...imgs.map((f, i) => h('div', {}, h('img', { src: f.url, alt: '' }), h('button', { text: '×', 'aria-label': t('delete'), onclick: () => { imgs.splice(i, 1); draw(); } })))); addBtn.classList.toggle('hidden', imgs.length >= 4); };
      imgIn.addEventListener('change', () => { for (const f of imgIn.files) { if (imgs.length >= 4) break; if (f.size > 10 * 1024 * 1024) { toast(t('err_too_large'), true); continue; } imgs.push({ f, url: URL.createObjectURL(f) }); } imgIn.value = ''; draw(); });
      wrap.append(err, text, prev, addBtn,
        h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:10px' }, field(t('category'), catSel), field(t('language'), langSel)),
        progWrap, submit);
      submit.addEventListener('click', async () => {
        err.classList.add('hidden');
        if (!text.value.trim() && !imgs.length) return showErr(t('err_empty_post'));
        submit.disabled = true;
        try {
          const ids = [];
          for (let i = 0; i < imgs.length; i++) {
            setProg(t('uploading'), Math.round(i / imgs.length * 100));
            ids.push((await api('/api/upload/image', { method: 'POST', raw: await cleanImage(imgs[i].f), headers: { 'Content-Type': 'application/octet-stream' } })).id);
          }
          setProg(t('processing'), 100);
          const r = await api('/api/posts', { method: 'POST', body: { kind: 'post', body: text.value, category: catSel.value, source_lang: langSel.value, images: ids } });
          toast(r.status === 'approved' ? t('publishedOk') : t('sentForReview'));
          location.hash = '#/settings';
        } catch (e) { showErr(errText(e.code)); submit.disabled = false; progWrap.classList.add('hidden'); }
      });
    }
  }
  function requestPublishSheet() {
    const note = h('textarea', { class: 'input', placeholder: t('requestPublishNote'), maxlength: 500 });
    const btn = h('button', { class: 'btn primary block', text: t('send') });
    const s = sheet(t('requestPublish'), h('div', {}, note, h('div', { style: 'height:12px' }), btn));
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try { await api('/api/publish-request', { method: 'POST', body: { note: note.value } }); s.close(); toast(t('requestSent')); }
      catch (e) { if (e.code === 'request_pending') { s.close(); toast((I18N[S.lang] || I18N.ar).err_publish_request_pending || t('requestSent')); return; } toast(errText(e.code), true); btn.disabled = false; }
    });
  }
  // تنظيف الصور قبل الرفع: يمسح البيانات المخفية (GPS…) ويصحّح الاتجاه ويصغّر الحجم
  async function cleanImage(file) {
    if (file.type === 'image/gif') return file;
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
      const max = 2048; const sc = Math.min(1, max / Math.max(bmp.width, bmp.height));
      const c = document.createElement('canvas'); c.width = Math.round(bmp.width * sc); c.height = Math.round(bmp.height * sc);
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      const type = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
      const blob = await new Promise((r) => c.toBlob(r, type, 0.9));
      return blob || file;
    } catch { return file; }
  }
  function captureFrame(video) {
    return new Promise((resolve) => {
      if (!video || !video.videoWidth) return resolve(null);
      const go = () => {
        try {
          const w = Math.min(540, video.videoWidth); const hh = Math.round(w * video.videoHeight / video.videoWidth);
          const c = document.createElement('canvas'); c.width = w; c.height = hh;
          c.getContext('2d').drawImage(video, 0, 0, w, hh);
          c.toBlob((b) => resolve(b), 'image/jpeg', 0.82);
        } catch { resolve(null); }
      };
      if (video.readyState >= 2) go(); else { video.addEventListener('seeked', go, { once: true }); setTimeout(() => resolve(null), 4000); }
    });
  }
  function uploadWithProgress(url, file, headers, onProgress) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open('POST', url);
      x.setRequestHeader('X-Majazia', '1');
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      for (const [k, v] of Object.entries(headers)) x.setRequestHeader(k, v);
      x.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round(e.loaded / e.total * 100)); };
      x.onload = () => { let d = null; try { d = JSON.parse(x.responseText); } catch { /* */ } if (x.status >= 200 && x.status < 300) resolve(d); else { const e = new Error('upload'); e.code = (d && d.error) || 'generic'; reject(e); } };
      x.onerror = () => { const e = new Error('network'); e.code = 'network'; reject(e); };
      x.send(file);
    });
  }

  // ================================================================ الإعدادات وحسابي
  async function viewSettings(main) {
    main.append(topbar(t('settings'), { backBtn: true }));
    const wrap = h('div'); main.append(wrap);
    const me = S.me;
    const name = h('input', { class: 'input', value: me.name, maxlength: 40 });
    const bio = h('textarea', { class: 'input', maxlength: 200 }); bio.value = me.bio || '';
    let inact = me.inactivity_days; let lang = S.lang;
    const inactSeg = h('div', { class: 'seg' }, [3, 7, 30, 60].map((d) => h('button', { type: 'button', class: d === inact ? 'on' : '', text: t('inact_' + d), onclick: (e) => { inact = d; [...inactSeg.children].forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); } })));
    const langSeg = h('div', { class: 'seg', style: 'grid-template-columns:repeat(3,1fr)' }, ['ar', 'en', 'fr'].map((l) => h('button', { type: 'button', class: l === lang ? 'on' : '', text: I18N[l].langName, onclick: (e) => { lang = l; [...langSeg.children].forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); } })));
    const save = h('button', { class: 'btn primary block', text: t('save') });
    save.addEventListener('click', async () => {
      save.disabled = true;
      try {
        const r = await api('/api/me', { method: 'POST', body: { name: name.value, bio: bio.value, lang, inactivity_days: inact } });
        S.me = r.me; toast(t('saved'));
        if (lang !== S.lang) { setLang(lang); renderShell(); return; }
      } catch (e) { toast(errText(e.code), true); }
      save.disabled = false;
    });
    const subs = h('div', {}, loader());
    wrap.append(h('div', {},
      h('a', { class: 'list-item', href: '#/u/' + me.username }, avatar(me), h('div', { class: 'grow' }, h('b', { style: 'display:flex;gap:4px;align-items:center' }, me.name, badge(me.verified)), h('small', { dir: 'ltr', text: '@' + me.username }))),
      S.cfg.staff ? h('a', { class: 'list-item', href: '#/staff', style: 'color:var(--gold)' }, icon('shield'), h('div', { class: 'grow' }, h('b', { text: t('staffRoom') })), staffBadge()) : null,
      h('div', { class: 'panel' },
        h('label', { class: 'field' }, h('span', { text: t('name') }), name),
        h('label', { class: 'field' }, h('span', { text: t('bio') }), bio),
        h('div', { class: 'field' }, h('span', { text: t('language'), style: 'display:block;font-size:13px;color:var(--muted);margin-bottom:6px' }), langSeg),
        h('div', { class: 'field' }, h('span', { text: t('autoDelete'), style: 'display:block;font-size:13px;color:var(--muted);margin-bottom:6px' }), inactSeg),
        save),
      h('div', { class: 'divider' }),
      h('a', { class: 'list-item', href: '#/publish' }, icon('upload'), h('div', { class: 'grow' }, h('b', { text: t('publish') }), h('small', { text: me.can_publish ? (me.publish_until === -1 || me.role !== 'user' ? t('canPublishForever') : t('canPublishUntil') + ' ' + fmtDate(me.publish_until)) : t('noPublish') }))),
      me.verified !== 'gold' ? h('button', { class: 'list-item', onclick: verifySheet }, icon('shield'), h('div', { class: 'grow' }, h('b', { text: t('requestVerify') }), h('small', { text: t('verifyBlue') + ' · ' + t('verifyGold') }))) : null,
      h('button', { class: 'list-item', onclick: () => toggleChat(true, 'majazia') }, icon('chat'), h('div', { class: 'grow' }, h('b', { text: t('contactAdmin') }))),
      h('div', { class: 'divider' }),
      h('div', { class: 'section-h' }, h('h3', { text: t('mySubmissions') })), subs,
      h('div', { class: 'divider' }),
      h('button', { class: 'list-item', onclick: logout }, icon('logout'), h('div', { class: 'grow' }, h('b', { text: t('logout') }))),
      me.role !== 'founder' ? h('button', { class: 'list-item', style: 'color:#ff8b8f', onclick: deleteAccountSheet }, icon('trash'), h('div', { class: 'grow' }, h('b', { text: t('deleteAccount') }))) : null,
      h('div', { style: 'height:30px' })));
    try {
      const r = await api('/api/my/posts');
      subs.replaceChildren(...(r.posts.length ? r.posts.map((p) => h('div', { class: 'list-item' },
        p.thumb ? h('img', { src: p.thumb, alt: '', style: 'width:44px;height:60px;object-fit:cover;border-radius:8px' }) : h('span', { style: 'width:44px;display:flex;justify-content:center;color:var(--muted)' }, icon(p.kind === 'reel' ? 'video' : 'comment')),
        h('div', { class: 'grow' }, h('b', { dir: 'auto', style: 'display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis', text: p.title || p.body || (p.images.length + ' 🖼') }),
          h('small', { text: (p.kind === 'reel' ? t('reels') : t('posts')) + ' · ' + timeAgo(p.created_at) + (p.reject_reason ? ' · ' + p.reject_reason : '') })),
        h('span', { class: 'status-pill ' + p.status, text: t('st_' + p.status) }))) : [h('div', { class: 'empty', style: 'padding:24px', text: t('noContent') })]));
    } catch { subs.replaceChildren(); }
  }
  function verifySheet() {
    let type = 'blue';
    const note = h('textarea', { class: 'input', placeholder: t('verifyNote'), maxlength: 500 });
    const opts = h('div', {}, [['blue', t('verifyBlue')], ['gold', t('verifyGold')]].map(([k, label]) => h('label', { class: 'opt' + (k === 'gold' ? ' goldopt' : ''), style: 'cursor:pointer' }, h('input', { type: 'radio', name: 'vt', checked: k === 'blue', style: 'accent-color:var(--primary)', onchange: () => { type = k; } }), h('span', { style: 'display:inline-flex;width:24px;height:24px', html: BADGE[k] }), h('b', { text: label }))));
    const btn = h('button', { class: 'btn primary block', text: t('send') });
    const s = sheet(t('requestVerify'), h('div', {}, opts, note, h('div', { style: 'height:12px' }), btn));
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try { await api('/api/verify-request', { method: 'POST', body: { type, note: note.value } }); s.close(); toast(t('verifySent')); }
      catch (e) { toast(errText(e.code), true); btn.disabled = false; }
    });
  }
  function deleteAccountSheet() {
    const pw = h('input', { class: 'input ltr', type: 'password', autocomplete: 'current-password' });
    const btn = h('button', { class: 'btn danger block', text: t('deleteAccount') });
    const s = sheet(t('deleteAccount'), h('div', {}, h('p', { style: 'margin-top:0', text: t('deleteConfirm') }), pw, h('div', { style: 'height:12px' }), btn));
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try { await api('/api/me/delete', { method: 'POST', body: { password: pw.value } }); s.close(); S.me = null; location.hash = ''; boot(); }
      catch (e) { toast(errText(e.code), true); btn.disabled = false; }
    });
  }

  // ================================================================ الشات الجانبي الصغير
  let chatEl = null, chatTimer = null;
  function toggleChat(open, withUser) {
    if (!open || (chatEl && !withUser)) { if (chatEl) { chatEl.remove(); chatEl = null; clearInterval(chatTimer); } if (!open || !withUser) return; }
    if (chatEl) { chatEl.remove(); clearInterval(chatTimer); }
    chatEl = h('div', { class: 'chat-panel', role: 'dialog' });
    document.body.append(chatEl);
    if (withUser) openThread(withUser); else showThreads();
  }
  function chatHeader(title, onBack, extra) {
    return h('div', { class: 'chat-h' },
      onBack ? h('button', { class: 'icon-btn', 'aria-label': t('back'), onclick: onBack }, h('span', { style: S.lang === 'ar' ? 'transform:scaleX(-1);display:inline-flex' : 'display:inline-flex' }, icon('back'))) : null,
      h('b', {}, title), extra || null,
      h('button', { class: 'icon-btn', 'aria-label': t('close'), onclick: () => toggleChat(false) }, icon('close')));
  }
  async function showThreads() {
    clearInterval(chatTimer);
    const list = h('div', { class: 'chat-list' }, loader());
    const newIn = h('input', { class: 'input ltr', placeholder: t('chatWith'), style: 'border-radius:999px;padding:9px 14px' });
    const startNew = () => { const u = newIn.value.trim().replace(/^@/, '').toLowerCase(); if (u === S.me.username) { toast(t('err_not_found'), true); return; } if (u) openThread(u); };
    newIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') startNew(); });
    chatEl.replaceChildren(chatHeader(t('chat')), h('div', { style: 'display:flex;gap:6px;padding:8px;border-bottom:1px solid var(--border)' }, newIn, h('button', { class: 'btn primary sm', text: t('start'), onclick: startNew })), list);
    async function load() {
      try {
        const r = await api('/api/chat/threads');
        list.replaceChildren(...r.threads.map((th) => h('button', { class: 'thread', onclick: () => openThread(th.peer.support ? 'majazia' : th.peer.username) },
          th.peer.support ? h('span', { class: 'avatar sm', style: 'background:#0f3a26;padding:3px' }, h('img', { src: '/logo-light.png', alt: '', style: 'width:100%' })) : avatar(th.peer, 'sm'),
          h('div', { class: 'tb' }, h('div', { class: 'tn' }, th.peer.support ? t('majaziaTeam') : th.peer.name, badge(th.peer.verified)), h('div', { class: 'tl', dir: 'auto', text: th.last || (th.peer.support ? t('requestVerify') + ' · ' + t('contactAdmin') : '') })),
          th.unread ? h('span', { class: 'ub', text: th.unread }) : null)));
      } catch { list.replaceChildren(errorState(load)); }
    }
    load();
    chatTimer = setInterval(() => { if (!document.hidden) load(); }, 15000);
  }
  async function openThread(peer) {
    clearInterval(chatTimer);
    const isSupport = peer === 'majazia';
    const msgs = h('div', { class: 'msgs' }, loader());
    const input = h('input', { class: 'input', placeholder: t('typeMessage'), maxlength: 1000 });
    const send = h('button', { class: 'icon-btn', 'aria-label': t('send') }, h('span', { style: S.lang === 'ar' ? 'transform:scaleX(-1);display:inline-flex' : 'display:inline-flex' }, icon('send')));
    const title = isSupport ? h('span', { style: 'display:flex;gap:5px;align-items:center' }, t('majaziaTeam'), badge('gold')) : h('a', { href: '#/u/' + peer, dir: 'ltr', text: '@' + peer });
    chatEl.replaceChildren(chatHeader(title, showThreads, isSupport ? h('button', { class: 'btn ghost sm', text: t('requestVerify'), onclick: verifySheet }) : null), msgs, h('div', { class: 'chat-f' }, input, send));
    let last = 0; let first = true;
    async function load() {
      try {
        const r = await api(`/api/chat/with/${encodeURIComponent(peer)}?since=${last}`);
        if (first) { msgs.replaceChildren(); first = false; if (!r.messages.length) msgs.append(h('div', { class: 'empty', style: 'padding:30px', text: t('noMessages') })); }
        if (r.messages.length) { const e = msgs.querySelector('.empty'); if (e) e.remove(); }
        for (const m of r.messages) { msgs.append(h('div', { class: 'msg' + (m.mine ? ' mine' : '') }, m.body, h('span', { class: 'mt', text: timeAgo(m.at) }))); last = Math.max(last, m.at); }
        if (r.messages.length) msgs.scrollTop = msgs.scrollHeight;
        refreshUnread();
      } catch (e) { if (first) { msgs.replaceChildren(emptyState(errText(e.code), null, 'chat')); first = false; clearInterval(chatTimer); } }
    }
    async function doSend() {
      const body = input.value.trim(); if (!body) return;
      send.disabled = true;
      try { await api(`/api/chat/with/${encodeURIComponent(peer)}`, { method: 'POST', body: { body } }); input.value = ''; await load(); }
      catch (e) { toast(errText(e.code), true); }
      send.disabled = false; input.focus();
    }
    send.addEventListener('click', doSend);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doSend(); });
    await load();
    chatTimer = setInterval(() => { if (!document.hidden) load(); }, 4000);
  }
  async function refreshUnread() { try { const c = await api('/api/config'); S.unread = c.unread || 0; updateUnreadDots(); } catch { /* */ } }

  // ================================================================ غرفة المشرفين (تُحمَّل للمشرفين فقط)
  function loadStaffScript() {
    if (window.MJZ_STAFF) return Promise.resolve();
    return new Promise((resolve, reject) => { const sc = document.createElement('script'); sc.src = '/staff.js?v=' + Date.now(); sc.onload = resolve; sc.onerror = reject; document.head.append(sc); });
  }
  async function viewStaff(main) {
    main.append(topbar(t('staffRoom'), { backBtn: true }));
    const body = h('div', {}, loader()); main.append(body);
    try { await loadStaffScript(); window.MJZ_STAFF(body, { h, api, icon, toast, avatar, badge, timeAgo, sheet, confirmSheet, catName, fmtDur, errText, loader, emptyState, S, refresh: async () => { try { const c = await api('/api/config'); S.cfg.staff = c.staff; } catch { /* */ } } }); }
    catch { body.replaceChildren(errorState(() => { S.mainRoute = null; route(); })); }
  }

  // ================================================================ تشغيل
  const style = document.createElement('style');
  style.textContent = '@media (min-width:900px){.mobile-only{display:none!important}}';
  document.head.append(style);
  boot();
})();
