'use strict';
/*
 * مجازية — Majazia · النواة المشتركة
 * يستخدمها خادم الموقع (server.js) وخادم لوحة التحكم المنفصل (control.js).
 * بلا مكتبات خارجية: Node.js 22.13+ (node:sqlite مدمج).
 */
process.removeAllListeners('warning');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');

// ---------------------------------------------------------------- الإعدادات
const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const MEDIA_DIR = path.join(DATA_DIR, 'media');
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DEEPL_KEY = process.env.DEEPL_API_KEY || '';
const SECURE_COOKIE = process.env.SECURE_COOKIE === '1';
const MAX_VIDEO_MB = Number(process.env.MAX_VIDEO_MB || 2048);
const MAX_IMAGE_MB = 10;
const MAX_VIDEO_SECONDS = 60; // دقيقة واحدة كحد أقصى
const SESSION_DAYS = 30;

fs.mkdirSync(MEDIA_DIR, { recursive: true });

const CATEGORIES = ['quran', 'hadith', 'seerah', 'fiqh', 'adhkar', 'mawaiz', 'science', 'math', 'languages', 'programming'];
const REPORT_REASONS = ['music', 'wrong_info', 'offensive', 'spam', 'impersonation', 'other'];
const INACTIVITY_CHOICES = [3, 7, 30, 60];
const LANGS = ['ar', 'en', 'fr'];

// ---------------------------------------------------------------- قاعدة البيانات
const db = new DatabaseSync(path.join(DATA_DIR, 'majazia.db'));
db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_hash TEXT NOT NULL,
  key_hash TEXT NOT NULL,
  bio TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'user',            -- user | mod | founder
  verified TEXT NOT NULL DEFAULT 'none',        -- none | blue | gold
  publish_until INTEGER NOT NULL DEFAULT 0,     -- 0 لا يوجد، -1 دائم، وإلا وقت الانتهاء
  banned INTEGER NOT NULL DEFAULT 0,
  ban_reason TEXT NOT NULL DEFAULT '',
  lang TEXT NOT NULL DEFAULT 'ar',
  inactivity_days INTEGER NOT NULL DEFAULT 30,
  last_active INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,          -- video | image
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  duration REAL NOT NULL DEFAULT 0,
  used INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,                 -- reel | post
  title TEXT NOT NULL DEFAULT '',
  body TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL,
  video_id TEXT,
  thumb_id TEXT,
  images TEXT NOT NULL DEFAULT '[]',
  duration REAL NOT NULL DEFAULT 0,
  subtitles TEXT NOT NULL DEFAULT '[]',
  source_lang TEXT NOT NULL DEFAULT 'ar',
  status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected
  reject_reason TEXT NOT NULL DEFAULT '',
  views INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  approved_at INTEGER
);
CREATE INDEX IF NOT EXISTS posts_status ON posts(status, kind, created_at);
CREATE TABLE IF NOT EXISTS likes (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, post_id)
);
CREATE TABLE IF NOT EXISTS comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reporter_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  target_type TEXT NOT NULL,   -- post | comment | user
  target_id INTEGER NOT NULL,
  reason TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open', -- open | resolved | dismissed
  handled_by INTEGER,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS codes (
  code TEXT PRIMARY KEY,
  grant_days INTEGER NOT NULL,      -- 0 = دائم
  max_uses INTEGER NOT NULL DEFAULT 1,
  uses INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS code_uses (
  code TEXT NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_at INTEGER NOT NULL,
  PRIMARY KEY (code, user_id)
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  to_id INTEGER NOT NULL,      -- 0 = إدارة مجازية
  body TEXT NOT NULL,
  via_support INTEGER NOT NULL DEFAULT 0, -- 1 = رد الإدارة باسم "مجازية" (لا يظهر حساب المشرف)
  is_read INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS msg_pair ON messages(from_id, to_id, created_at);
CREATE TABLE IF NOT EXISTS verify_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,           -- blue | gold
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS translations (
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  lang TEXT NOT NULL,
  data TEXT NOT NULL,
  PRIMARY KEY (post_id, lang)
);
CREATE TABLE IF NOT EXISTS settings ( key TEXT PRIMARY KEY, value TEXT NOT NULL );
CREATE TABLE IF NOT EXISTS staff_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  body TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS publish_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending', -- pending | granted | dismissed
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS control_sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  severity TEXT NOT NULL,       -- low | medium | high
  user_id INTEGER,
  username TEXT NOT NULL DEFAULT '',
  visitor TEXT NOT NULL,        -- بصمة مجهولة للزائر (HMAC) — لا نحفظ عنوان IP الحقيقي
  method TEXT NOT NULL DEFAULT '',
  path TEXT NOT NULL DEFAULT '',
  detail TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'new', -- new | handled
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS sec_visitor ON security_events(visitor, created_at);
CREATE TABLE IF NOT EXISTS blocked_visitors (
  visitor TEXT PRIMARY KEY,
  reason TEXT NOT NULL DEFAULT '',
  until INTEGER NOT NULL,       -- -1 دائم
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER,
  action TEXT NOT NULL,
  target TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
`);

const q = (sql) => db.prepare(sql);
const now = () => Date.now();

function getSetting(k, def) {
  const r = q('SELECT value FROM settings WHERE key=?').get(k);
  return r ? r.value : def;
}
function setSetting(k, v) {
  q('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(k, String(v));
}

// الإعدادات الافتراضية + مفاتيح الطوارئ (تتحكم بها لوحة المؤسس المنفصلة)
for (const [k, v] of [['approval_required', '1'], ['registration_open', '1'], ['maintenance', '0'], ['freeze_publishing', '0'], ['staff_locked', '0']]) {
  if (!getSetting(k, '')) setSetting(k, v);
}
const flag = (k) => getSetting(k, '0') === '1';
if (!getSetting('founder_final_approval', '')) setSetting('founder_final_approval', '1');
if (!getSetting('content_ttl_days', '')) setSetting('content_ttl_days', '0');
try { db.exec('ALTER TABLE posts ADD COLUMN pre_approved_by INTEGER'); } catch { /* موجود */ }
// الأجزاء (جزء 1، جزء 2…): كل أجزاء السلسلة تشير لأول فيديو فيها
try { db.exec('ALTER TABLE posts ADD COLUMN series_id INTEGER'); } catch { /* موجود */ }
try { db.exec('ALTER TABLE posts ADD COLUMN part_no INTEGER NOT NULL DEFAULT 0'); } catch { /* موجود */ }

// ---------------------------------------------------------------- تشفير الوسائط على القرص (AES-256-CTR)
// كل فيديو وصورة يُحفظ مشفّراً: من يسرق القرص لا يستطيع فتح أي ملف بدون المفتاح.
// الأفضل وضع المفتاح في متغير البيئة MEDIA_KEY (خارج القرص). إذا لم يوجد يُنشأ ملف مفتاح داخل مجلد البيانات.
function loadMediaKey() {
  const env = String(process.env.MEDIA_KEY || '').trim();
  if (/^[a-f0-9]{64}$/i.test(env)) return { key: Buffer.from(env, 'hex'), fromEnv: true };
  const kf = path.join(DATA_DIR, 'media.key');
  if (!fs.existsSync(kf)) fs.writeFileSync(kf, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  return { key: Buffer.from(fs.readFileSync(kf, 'utf8').trim(), 'hex'), fromEnv: false };
}
const MEDIA_KEY = loadMediaKey();
function ivAdd(iv, blocks) {
  const out = Buffer.from(iv);
  let carry = BigInt(blocks);
  for (let i = 15; i >= 0 && carry > 0n; i--) { const sum = BigInt(out[i]) + (carry & 0xffn); out[i] = Number(sum & 0xffn); carry = (carry >> 8n) + (sum >> 8n); }
  return out;
}
async function encryptFile(src, dst) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-ctr', MEDIA_KEY.key, iv);
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(dst, { mode: 0o600 });
    ws.write(iv);
    fs.createReadStream(src).on('error', reject).pipe(cipher).on('error', reject).pipe(ws);
    ws.on('finish', resolve); ws.on('error', reject);
  });
}
function decryptStream(file, start, end) {
  // يدعم القراءة من أي نقطة (Range) بدون فك تشفير الملف كله
  const { Transform } = require('node:stream');
  const fd = fs.openSync(file, 'r');
  const iv = Buffer.alloc(16); fs.readSync(fd, iv, 0, 16, 0); fs.closeSync(fd);
  const block = Math.floor(start / 16);
  const decipher = crypto.createDecipheriv('aes-256-ctr', MEDIA_KEY.key, ivAdd(iv, block));
  let skip = start - block * 16;
  const trim = new Transform({ transform(chunk, _e, cb) { if (skip) { const s = Math.min(skip, chunk.length); chunk = chunk.subarray(s); skip -= s; } cb(null, chunk); } });
  const rs = fs.createReadStream(file, { start: 16 + block * 16, end: 16 + end });
  rs.on('error', (e) => trim.destroy(e));
  return rs.pipe(decipher).pipe(trim);
}
async function decryptToFile(src, dst) {
  const st = await fsp.stat(src);
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(dst, { mode: 0o600 });
    decryptStream(src, 0, st.size - 17).on('error', reject).pipe(ws);
    ws.on('finish', resolve); ws.on('error', reject);
  });
}
function serveMedia(req, res, file, mime, { cache = 'private, max-age=3600', download = '' } = {}) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile() || st.size < 16) return send(res, 404, 'Not found');
    const size = st.size - 16;
    const base = { 'Content-Type': mime, 'Accept-Ranges': 'bytes', 'Cache-Control': cache, ...securityHeaders() };
    if (download) base['Content-Disposition'] = `attachment; filename="${download.replace(/[^\w.-]/g, '')}"`;
    let start = 0, end = size - 1, status = 200;
    const range = req.headers.range;
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      start = m && m[1] ? parseInt(m[1], 10) : 0;
      end = m && m[2] ? parseInt(m[2], 10) : size - 1;
      if (m && !m[1] && m[2]) { start = Math.max(0, size - parseInt(m[2], 10)); end = size - 1; }
      if (!m || start >= size || end < start) { res.writeHead(416, { 'Content-Range': `bytes */${size}`, ...securityHeaders() }); return res.end(); }
      end = Math.min(end, size - 1); status = 206;
      base['Content-Range'] = `bytes ${start}-${end}/${size}`;
    }
    res.writeHead(status, { ...base, 'Content-Length': end - start + 1 });
    if (req.method === 'HEAD' || size === 0) return res.end();
    try { decryptStream(file, start, end).on('error', () => res.destroy()).pipe(res); } catch { res.destroy(); }
  });
}
// مسح البيانات المخفية (الموقع، الجهاز، التاريخ…) من الفيديو والصور قبل الحفظ
function runTool(cmd, args, timeout = 600000) {
  return new Promise((resolve) => execFile(cmd, args, { timeout, maxBuffer: 1 << 20 }, (err) => resolve(!err)));
}
async function stripMetadata(file, kind, ext) {
  const out = file + '.clean.' + ext;
  let ok;
  if (kind === 'video') ok = await runTool('ffmpeg', ['-v', 'error', '-y', '-i', file, '-map', '0:v:0', '-map', '0:a?', '-map_metadata', '-1', '-map_chapters', '-1', '-c', 'copy', '-movflags', '+faststart', out]);
  else if (ext === 'gif') ok = await runTool('ffmpeg', ['-v', 'error', '-y', '-i', file, '-map_metadata', '-1', out], 60000);
  else ok = await runTool('ffmpeg', ['-v', 'error', '-y', '-i', file, '-map_metadata', '-1', '-frames:v', '1', ...(ext === 'png' ? [] : ['-q:v', '2']), out], 60000);
  if (ok && fs.existsSync(out) && fs.statSync(out).size > 0) { await fsp.rename(out, file); return true; }
  await fsp.rm(out, { force: true });
  return false;
}
// ترقية من النسخة السابقة: المشرف القديم = مستوى 2
db.prepare("UPDATE users SET role='mod2' WHERE role='mod'").run();
function founderExists() { return !!q("SELECT 1 FROM users WHERE role='founder'").get(); }

// ---------------------------------------------------------------- أدوات الأمان
function hashSecret(secret) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(String(secret), salt, 64, { N: 16384, r: 8, p: 1 });
  return salt.toString('hex') + ':' + h.toString('hex');
}
function checkSecret(secret, stored) {
  const [s, h] = String(stored).split(':');
  if (!s || !h) return false;
  const calc = crypto.scryptSync(String(secret), Buffer.from(s, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const want = Buffer.from(h, 'hex');
  return want.length === calc.length && crypto.timingSafeEqual(calc, want);
}
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
function makeSecurityKey() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part = () => Array.from(crypto.randomBytes(4), (b) => A[b % A.length]).join('');
  return `MJZ-${part()}-${part()}-${part()}-${part()}`;
}
const normKey = (k) => String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function makeCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return Array.from(crypto.randomBytes(10), (b) => A[b % A.length]).join('').replace(/(.{5})(.{5})/, '$1-$2');
}

// حماية بسيطة من التخمين: محاولات محدودة لكل اسم مستخدم + لكل اتصال
const attempts = new Map();
function tooMany(key, limit = 8, windowMs = 15 * 60 * 1000) {
  const t = now();
  const arr = (attempts.get(key) || []).filter((x) => t - x < windowMs);
  attempts.set(key, arr);
  return arr.length >= limit;
}
function noteAttempt(key) { const a = attempts.get(key) || []; a.push(now()); attempts.set(key, a); }
setInterval(() => { const t = now(); for (const [k, v] of attempts) if (!v.some((x) => t - x < 3600000)) attempts.delete(k); }, 600000).unref();

// ---------------------------------------------------------------- مراقبة الأمان
// كل زائر له بصمة مجهولة (HMAC لعنوانه) حتى نكشف المهاجم ونحظره دون حفظ عنوانه الحقيقي.
let VISITOR_SECRET = getSetting('visitor_secret', '');
if (!VISITOR_SECRET) { VISITOR_SECRET = crypto.randomBytes(32).toString('hex'); setSetting('visitor_secret', VISITOR_SECRET); }
function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    // نأخذ آخر عنوان (يضيفه البروكسي الموثوق)؛ الأول يكتبه العميل بنفسه ويمكن تزويره لحظر الأبرياء أو تجاوز الحدود
    const xf = String(req.headers['x-forwarded-for'] || '').split(',').pop().trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || '';
}
function visitorOf(req) {
  if (!req._visitor) req._visitor = crypto.createHmac('sha256', VISITOR_SECRET).update(clientIp(req)).digest('hex').slice(0, 16);
  return req._visitor;
}
const SEV_SCORE = { info: 0, low: 1, medium: 3, high: 6 };
const AUTO_BLOCK_SCORE = 15;      // مجموع النقاط خلال ساعة قبل الحظر التلقائي
const AUTO_BLOCK_HOURS = 24;
const lastEvent = new Map();      // منع تكرار نفس التنبيه بكثرة
function securityEvent(req, kind, severity, detail = '', user = null) {
  try {
    const visitor = visitorOf(req);
    const dedupe = visitor + kind + (detail || '').slice(0, 40);
    const t = now();
    if (lastEvent.has(dedupe) && t - lastEvent.get(dedupe) < 60000) return;
    lastEvent.set(dedupe, t);
    const u = user || req._user || null;
    q('INSERT INTO security_events(kind,severity,user_id,username,visitor,method,path,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
      .run(kind, severity, u ? u.id : null, u ? u.username : '', visitor, String(req.method || '').slice(0, 8), String(req.url || '').slice(0, 300), String(detail).slice(0, 300), t);
    // حظر تلقائي للزائر إذا تكررت المحاولات الخطيرة
    const rows = q("SELECT severity FROM security_events WHERE visitor=? AND created_at>?").all(visitor, t - 3600000);
    const score = rows.reduce((a, r) => a + (SEV_SCORE[r.severity] ?? 1), 0);
    if (score >= AUTO_BLOCK_SCORE && !isBlocked(visitor) && !(u && isStaff(u))) {
      q('INSERT OR REPLACE INTO blocked_visitors(visitor,reason,until,created_at) VALUES(?,?,?,?)').run(visitor, 'auto', t + AUTO_BLOCK_HOURS * 3600000, t);
      q('INSERT INTO security_events(kind,severity,user_id,username,visitor,method,path,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run('auto_blocked', 'high', u ? u.id : null, u ? u.username : '', visitor, '', '', `score=${score}`, t);
    }
  } catch (e) { console.error('[security]', e); }
}
function isBlocked(visitor) {
  const b = q('SELECT until FROM blocked_visitors WHERE visitor=?').get(visitor);
  if (!b) return false;
  if (b.until !== -1 && b.until < now()) { q('DELETE FROM blocked_visitors WHERE visitor=?').run(visitor); return false; }
  return true;
}
// مسارات يبحث عنها الماسحون الآليون والمخترقون عادةً
const PROBE_RE = /(\/\.env|\/\.git|\/\.aws|\/\.ssh|\/\.htaccess|\/\.htpasswd|wp-admin|wp-login|wp-content|wp-includes|xmlrpc\.php|phpmyadmin|\/pma\b|\.php\b|\.asp|\.aspx|\.jsp|cgi-bin|\/etc\/passwd|\/proc\/self|server-status|\/actuator|\/console\b|\/vendor\/|\/config\.(json|yml|yaml|js)|\/backup|\.sql\b|\.bak\b|\/administrator|\/admin\b|\/admin\/|\/login\.action|\/boaform|\/HNAP1|\/owa\/|\/solr\/|\/jenkins|\/manager\/html|\/debug|\/swagger|\/graphql|\/api\/v1\/admin)/i;
const INJECT_RE = /(\bunion\b[\s\S]{0,20}\bselect\b|'\s*or\s*'?\d|'\s*or\s+1\s*=\s*1|;\s*drop\s+table|\bsleep\s*\(|benchmark\s*\(|<\s*script|javascript:|onerror\s*=|onload\s*=|\$\{jndi:|\.\.\/|\.\.\\|%2e%2e|\/etc\/passwd|<\?php|\bexec\s*\(|\beval\s*\()/i;
function scanRequest(req, pathname, rawUrl) {
  let decoded = rawUrl;
  if (canaryUsed(req, rawUrl + ' ' + (req.headers.authorization || '') + ' ' + (req.headers.cookie || ''))) { securityEvent(req, 'canary_used', 'high', 'استخدم مفتاحاً مزيفاً سرقه من فخ — مخترق مؤكد'); return true; }
  try { decoded = decodeURIComponent(rawUrl); } catch { securityEvent(req, 'malformed_url', 'medium', rawUrl.slice(0, 120)); return true; }
  // نص البحث (q) حرّ ومُمرَّر كمعامل آمن: طالب برمجة يبحث عن "eval(" أو "union select" أو فرنسي يكتب "l'or 24" ليس مخترقاً
  let scanned = decoded;
  if (pathname.startsWith('/api/')) {
    try {
      const u = new URL(rawUrl, 'http://x');
      const sq = u.searchParams.get('q');
      if (sq != null) { u.searchParams.delete('q'); scanned = decodeURIComponent(u.pathname + u.search); if (INJECT_RE.test(sq)) securityEvent(req, 'suspicious_search', 'info', sq.slice(0, 200)); }
    } catch { /* */ }
  }
  if (INJECT_RE.test(scanned)) { securityEvent(req, 'injection_attempt', 'high', decoded.slice(0, 200)); return true; }
  if (!pathname.startsWith('/api/') && PROBE_RE.test(pathname)) { securityEvent(req, 'path_probe', 'medium', pathname.slice(0, 200)); return true; }
  return false;
}
// ---------------------------------------------------------------- الفخاخ (Honeypot) لتضييع وقت المخترقين
// من يبحث عن ثغرات يحصل على صفحات ومفاتيح مزيفة وردود بطيئة، وأي استخدام لاحق للمفاتيح المزيفة يكشفه فوراً.
let CANARIES = getSetting('canaries', '');
if (!CANARIES) {
  const r = (n) => crypto.randomBytes(n).toString('hex');
  CANARIES = JSON.stringify({ db_pass: 'Mjz!' + r(6), api_key: 'sk_live_' + r(20), jwt: r(24), admin_pass: 'Adm1n_' + r(5), aws: 'AKIA' + r(8).toUpperCase() });
  setSetting('canaries', CANARIES);
}
const CANARY = JSON.parse(CANARIES);
const CANARY_VALUES = Object.values(CANARY);
const DECOY_LOGIN = fs.readFileSync(path.join(ROOT, 'assets', 'decoy-login.html'), 'utf8');
let tarpitCount = 0;
const MAX_TARPITS = 60;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function canaryUsed(req, text) {
  const t = String(text || '');
  return CANARY_VALUES.some((v) => t.includes(v));
}
function fakeEnv() {
  return [
    'APP_ENV=production', 'APP_DEBUG=false', 'DB_HOST=10.0.3.17', 'DB_PORT=5432', 'DB_DATABASE=majazia_prod', 'DB_USERNAME=mjz_admin',
    'DB_PASSWORD=' + CANARY.db_pass, 'JWT_SECRET=' + CANARY.jwt, 'STRIPE_SECRET=' + CANARY.api_key,
    'AWS_ACCESS_KEY_ID=' + CANARY.aws, 'ADMIN_DEFAULT_PASSWORD=' + CANARY.admin_pass, '',
  ].join('\n');
}
async function serveDecoy(req, res, reason) {
  if (tarpitCount >= MAX_TARPITS) return send(res, 404, 'Not found');
  tarpitCount++;
  try {
    await sleep(2500 + Math.random() * 5000); // رد بطيء مقصود
    if (res.destroyed) return;
    const p = String(req.url || '').toLowerCase();
    if (req.method === 'POST') {
      // نقرأ اسم المستخدم المُجرَّب فقط (لا نحفظ كلمات المرور)
      let body = '';
      await new Promise((resolve) => { req.on('data', (c) => { if (body.length < 4000) body += c; }); req.on('end', resolve); req.on('error', resolve); });
      const tried = (/(?:^|&)(?:user|username|log|login|email)=([^&]{0,60})/i.exec(body) || [])[1] || '';
      if (canaryUsed(req, body)) securityEvent(req, 'canary_used', 'high', 'استخدم كلمة سر مزيفة سرقها من فخ .env — مخترق مؤكد');
      else securityEvent(req, 'decoy_login', 'high', 'جرّب الدخول في لوحة إدارة مزيفة' + (tried ? ` باسم: ${decodeURIComponent(tried.replace(/\+/g, ' ')).replace(/[^\w@.\- ]/g, '').slice(0, 40)}` : ''));
      return send(res, 200, DECOY_LOGIN.replace('{{ERR}}', '<div class="e">Invalid username or password. Attempts remaining: ' + (1 + Math.floor(Math.random() * 3)) + '</div>').replace('{{SID}}', crypto.randomBytes(8).toString('hex')), { 'Content-Type': 'text/html; charset=utf-8' });
    }
    if (/\.env|config|\.aws|credentials|\.git\/config/.test(p)) return send(res, 200, fakeEnv());
    if (/\.sql|backup|\.bak/.test(p)) return send(res, 200, `-- MySQL dump 10.13\n-- Host: 10.0.3.17\n-- Server version 8.0.35\n\nLOCK TABLES \`users\` WRITE;\nINSERT INTO \`users\` VALUES (1,'admin','$2y$10$${crypto.randomBytes(20).toString('base64').slice(0, 26)}','${CANARY.admin_pass}');\n-- dump interrupted: connection lost\n`);
    if (/passwd/.test(p)) return send(res, 200, 'root:x:0:0:root:/root:/bin/false\nwww:x:33:33:www:/var/www:/usr/sbin/nologin\n');
    if (p.startsWith('/api/')) return send(res, 200, { ok: true, token: crypto.randomBytes(16).toString('hex'), role: 'admin', expires_in: 3600, note: 'session pending verification' });
    return send(res, 200, DECOY_LOGIN.replace('{{ERR}}', '').replace('{{SID}}', crypto.randomBytes(8).toString('hex')), { 'Content-Type': 'text/html; charset=utf-8' });
  } finally { tarpitCount--; }
}
// صفحة "الموقع مغلق" للزائر المحظور: تبدو كصيانة وتبقى تتحمّل ببطء
const MAINTENANCE = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Maintenance</title></head>
<body style="font-family:Arial;background:#0b0f0d;color:#ddd;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;text-align:center">
<div><h2 style="font-weight:400">Service temporarily unavailable</h2><p style="color:#888">Scheduled maintenance. Please try again later.</p><p style="color:#555;font-size:12px">ref ${'#'}REF</p></div></body></html>`;
async function serveBlocked(req, res) {
  if (tarpitCount >= MAX_TARPITS) return send(res, 503, 'Service unavailable');
  tarpitCount++;
  try { await sleep(4000 + Math.random() * 6000); if (!res.destroyed) send(res, 503, MAINTENANCE.replace('#REF', crypto.randomBytes(6).toString('hex')), { 'Content-Type': 'text/html; charset=utf-8', 'Retry-After': '3600' }); }
  finally { tarpitCount--; }
}

// كثرة الطلبات لصفحات غير موجودة = فحص آلي للموقع
const notFoundHits = new Map();
function noteNotFound(req) {
  const v = visitorOf(req); const t = now();
  const arr = (notFoundHits.get(v) || []).filter((x) => t - x < 600000); arr.push(t); notFoundHits.set(v, arr);
  if (arr.length === 25) securityEvent(req, 'scanning', 'medium', `${arr.length} طلب لمسارات غير موجودة خلال 10 دقائق`);
}
setInterval(() => { const t = now(); for (const [k, v] of notFoundHits) if (!v.some((x) => t - x < 600000)) notFoundHits.delete(k); for (const [k, v] of lastEvent) if (t - v > 600000) lastEvent.delete(k); }, 600000).unref();

// ---------------------------------------------------------------- HTTP helpers
function send(res, status, body, headers = {}) {
  const isBuf = Buffer.isBuffer(body);
  const data = isBuf || typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': isBuf || typeof body === 'string' ? (headers['Content-Type'] || 'text/plain; charset=utf-8') : 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...securityHeaders(),
    ...headers,
  });
  res.end(data);
}
function securityHeaders() {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  };
}
class HttpError extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }
const fail = (status, code) => { throw new HttpError(status, code); };

function readJson(req, limit = 200 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, 'too_large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      let v;
      try { v = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { return reject(new HttpError(400, 'bad_json')); }
      if (!v || typeof v !== 'object' || Array.isArray(v)) return reject(new HttpError(400, 'bad_json')); // null / رقم / مصفوفة كانت تُسقط المعالج بخطأ 500
      resolve(v);
    });
    req.on('error', reject);
  });
}
function parseCookies(req) {
  const out = {};
  for (const p of String(req.headers.cookie || '').split(';')) {
    const i = p.indexOf('='); if (i < 0) continue;
    try { out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch { /* كوكي تالف لا يُسقط الطلب */ }
  }
  return out;
}
function sessionCookie(token, maxAge) {
  return `mjz_s=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${SECURE_COOKIE ? '; Secure' : ''}`;
}
function str(v, max, { required = false, multiline = false } = {}) {
  let s = typeof v === 'string' ? v : '';
  s = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '');
  if (!multiline) s = s.replace(/[\r\n]+/g, ' ');
  s = s.trim();
  if (s.length > max) s = s.slice(0, max);
  if (required && !s) fail(400, 'missing_fields');
  return s;
}

// ---------------------------------------------------------------- المستخدم الحالي
function currentUser(req) {
  const tok = parseCookies(req).mjz_s;
  if (!tok || tok.length < 20) return null;
  const s = q('SELECT user_id, created_at FROM sessions WHERE token_hash=?').get(sha(tok));
  if (!s) return null;
  if (now() - s.created_at > SESSION_DAYS * 86400000) { q('DELETE FROM sessions WHERE token_hash=?').run(sha(tok)); return null; }
  const u = q('SELECT * FROM users WHERE id=?').get(s.user_id);
  if (!u) return null;
  if (now() - u.last_active > 60000) q('UPDATE users SET last_active=? WHERE id=?').run(now(), u.id);
  return u;
}
// الأدوار: user · mod1 (مشرف مستوى 1) · mod2 (مشرف مستوى 2) · founder (المؤسس)
const STAFF_ROLES = ['mod1', 'mod2', 'founder'];
const isFounder = (u) => !!u && u.role === 'founder';
// إذا قفل المؤسس غرفة المشرفين من لوحة الطوارئ يفقد المشرفون صلاحياتهم فوراً
const isStaff = (u) => !!u && !u.banned && (u.role === 'founder' || (STAFF_ROLES.includes(u.role) && !flag('staff_locked')));
const isMod2 = (u) => isStaff(u) && (u.role === 'mod2' || u.role === 'founder');
function canPublish(u) {
  if (!u || u.banned) return false;
  if (u.role === 'founder') return true;
  if (flag('freeze_publishing')) return false;
  if (isStaff(u)) return true;
  return u.publish_until === -1 || u.publish_until > now();
}
function publicUser(u, viewer) {
  if (!u) return null;
  const o = { id: u.id, name: u.name, username: u.username, bio: u.bio, verified: u.verified, created_at: u.created_at };
  if (viewer && (viewer.id === u.id)) {
    Object.assign(o, { role: u.role, publish_until: u.publish_until, can_publish: canPublish(u), lang: u.lang, inactivity_days: u.inactivity_days, banned: !!u.banned, ban_reason: u.ban_reason });
  }
  return o;
}
function audit(admin, action, target = '') {
  q('INSERT INTO audit(admin_id,action,target,created_at) VALUES(?,?,?,?)').run(admin ? admin.id : null, action, String(target).slice(0, 200), now());
}

// ---------------------------------------------------------------- الترجمات (DeepL)
const DEEPL_TARGET = { ar: 'AR', en: 'EN-US', fr: 'FR' };
async function deeplTranslate(texts, target) {
  if (!DEEPL_KEY || !texts.length) return null;
  const host = DEEPL_KEY.endsWith(':fx') ? 'https://api-free.deepl.com' : 'https://api.deepl.com';
  const out = [];
  for (let i = 0; i < texts.length; i += 50) {
    const r = await fetch(host + '/v2/translate', {
      method: 'POST',
      headers: { 'Authorization': 'DeepL-Auth-Key ' + DEEPL_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: texts.slice(i, i + 50), target_lang: DEEPL_TARGET[target], preserve_formatting: true }),
    });
    if (!r.ok) throw new Error('deepl_' + r.status);
    const j = await r.json();
    for (const t of j.translations) out.push(t.text);
  }
  return out;
}
async function getTranslation(post, lang) {
  if (!LANGS.includes(lang) || lang === post.source_lang) return null;
  const c = q('SELECT data FROM translations WHERE post_id=? AND lang=?').get(post.id, lang);
  if (c) return JSON.parse(c.data);
  const subs = JSON.parse(post.subtitles || '[]');
  const texts = [post.title, post.body, ...subs.map((s) => s.text)];
  const nonEmpty = texts.map((t, i) => [t, i]).filter(([t]) => t && t.trim());
  const tr = await deeplTranslate(nonEmpty.map(([t]) => t), lang);
  if (!tr) return null;
  const full = texts.slice();
  nonEmpty.forEach(([, i], k) => { full[i] = tr[k]; });
  const data = { title: full[0], body: full[1], subtitles: subs.map((s, k) => ({ start: s.start, end: s.end, text: full[2 + k] })) };
  q('INSERT OR REPLACE INTO translations(post_id,lang,data) VALUES(?,?,?)').run(post.id, lang, JSON.stringify(data));
  return data;
}

// ---------------------------------------------------------------- الترجمة النصية للترجمات (SRT / VTT)
function parseTime(t) {
  const m = String(t).trim().replace(',', '.').match(/^(?:(\d+):)?(\d{1,2}):(\d{1,2})(?:\.(\d{1,3}))?$/);
  if (!m) return null;
  return (Number(m[1] || 0) * 3600) + Number(m[2]) * 60 + Number(m[3]) + Number((m[4] || '0').padEnd(3, '0')) / 1000;
}
function parseSubtitles(raw) {
  const text = String(raw || '').replace(/\r/g, '').replace(/^WEBVTT[^\n]*\n/, '');
  const blocks = text.split(/\n{2,}/);
  const out = [];
  for (const b of blocks) {
    const lines = b.split('\n').filter((l) => l.trim() !== '');
    const ti = lines.findIndex((l) => l.includes('-->'));
    if (ti < 0) continue;
    const [a, z] = lines[ti].split('-->');
    const start = parseTime(a); const end = parseTime(String(z).trim().split(/\s+/)[0]);
    const body = lines.slice(ti + 1).join('\n').replace(/<[^>]+>/g, '').trim();
    if (start == null || end == null || end <= start || !body) continue;
    out.push({ start, end, text: body.slice(0, 500) });
    if (out.length >= 3000) break;
  }
  return out.sort((x, y) => x.start - y.start);
}

// ---------------------------------------------------------------- تجهيز المنشورات للعرض
function postRow(p, viewer, { withAuthor = true } = {}) {
  const author = withAuthor ? q('SELECT * FROM users WHERE id=?').get(p.user_id) : null;
  const likes = q('SELECT COUNT(*) n FROM likes WHERE post_id=?').get(p.id).n;
  const comments = q('SELECT COUNT(*) n FROM comments WHERE post_id=?').get(p.id).n;
  const liked = viewer ? !!q('SELECT 1 FROM likes WHERE post_id=? AND user_id=?').get(p.id, viewer.id) : false;
  return {
    id: p.id, kind: p.kind, title: p.title, body: p.body, category: p.category,
    video: p.video_id ? '/media/' + p.video_id : null,
    thumb: p.thumb_id ? '/media/' + p.thumb_id : null,
    images: JSON.parse(p.images || '[]').map((i) => '/media/' + i),
    duration: p.duration, has_subtitles: JSON.parse(p.subtitles || '[]').length > 0,
    source_lang: p.source_lang, status: p.status, reject_reason: p.reject_reason,
    views: p.views, likes, comments, liked, created_at: p.created_at,
    series_id: p.series_id || null, part_no: p.part_no || 0,
    part_count: p.series_id ? q("SELECT COUNT(*) n FROM posts WHERE series_id=? AND status='approved'").get(p.series_id).n : 0,
    author: author ? publicUser(author) : null,
  };
}

// ترتيب: الموثّق الذهبي أولاً دائماً، ثم الأحدث
const ORDER_FEED = `CASE u.verified WHEN 'gold' THEN 0 ELSE 1 END, p.created_at DESC`;
const ORDER_EXPLORE = `CASE u.verified WHEN 'gold' THEN 0 ELSE 1 END,
  ((SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id)*3 + (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id)*2 + p.views) * 1.0
  / ((( ? - p.created_at) / 3600000.0) + 2) DESC`;

function listPosts({ kind, category, author, search, order = 'feed', limit = 20, offset = 0, viewer }) {
  const where = ["p.status='approved'", 'u.banned=0'];
  const args = [];
  if (kind) { where.push('p.kind=?'); args.push(kind); }
  if (category && CATEGORIES.includes(category)) { where.push('p.category=?'); args.push(category); }
  if (author) { where.push('p.user_id=?'); args.push(author); }
  if (search) {
    const like = '%' + search.replace(/[%_\\]/g, (m) => '\\' + m) + '%';
    where.push(`(p.title LIKE ? ESCAPE '\\' OR p.body LIKE ? ESCAPE '\\' OR p.subtitles LIKE ? ESCAPE '\\' OR u.name LIKE ? ESCAPE '\\' OR u.username LIKE ? ESCAPE '\\'
      OR p.id IN (SELECT post_id FROM translations WHERE data LIKE ? ESCAPE '\\'))`);
    args.push(like, like, like, like, like, like);
  }
  let orderSql = ORDER_FEED;
  const orderArgs = [];
  if (order === 'explore') { orderSql = ORDER_EXPLORE; orderArgs.push(now()); }
  const rows = q(`SELECT p.* FROM posts p JOIN users u ON u.id=p.user_id WHERE ${where.join(' AND ')} ORDER BY ${orderSql} LIMIT ? OFFSET ?`)
    .all(...args, ...orderArgs, Math.max(1, Math.min(50, limit)), Math.max(0, offset)); // LIMIT سالب في SQLite = بلا حد
  return rows.map((p) => postRow(p, viewer));
}

// ---------------------------------------------------------------- الوسائط
function sniff(buf) {
  const h = buf.subarray(0, 16);
  if (h[0] === 0xff && h[1] === 0xd8 && h[2] === 0xff) return ['image', 'image/jpeg', 'jpg'];
  if (h.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return ['image', 'image/png', 'png'];
  if (h.toString('ascii', 0, 4) === 'RIFF' && h.toString('ascii', 8, 12) === 'WEBP') return ['image', 'image/webp', 'webp'];
  if (h.toString('ascii', 0, 6) === 'GIF87a' || h.toString('ascii', 0, 6) === 'GIF89a') return ['image', 'image/gif', 'gif'];
  if (h.toString('ascii', 4, 8) === 'ftyp') {
    const brand = h.toString('ascii', 8, 12);
    if (brand.startsWith('qt')) return ['video', 'video/quicktime', 'mov'];
    return ['video', 'video/mp4', 'mp4'];
  }
  if (h[0] === 0x1a && h[1] === 0x45 && h[2] === 0xdf && h[3] === 0xa3) return ['video', 'video/webm', 'webm'];
  return null;
}
function probeDuration(file) {
  return new Promise((resolve) => {
    execFile('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file], { timeout: 20000 }, (err, out) => {
      if (err) return resolve(err.code === 'ENOENT' ? undefined : null); // undefined = ffprobe غير مثبت
      const d = parseFloat(String(out).trim());
      resolve(Number.isFinite(d) ? d : null);
    });
  });
}
async function handleUpload(req, res, user, kind) {
  if (!canPublish(user)) fail(403, 'no_publish_permission');
  if (!['video', 'image'].includes(kind)) fail(400, 'bad_kind');
  if (tooMany('up:' + user.id, 60, 3600000)) fail(429, 'too_many_attempts'); // حد لملء القرص بملفات يتيمة
  noteAttempt('up:' + user.id);
  const maxBytes = (kind === 'video' ? MAX_VIDEO_MB : MAX_IMAGE_MB) * 1024 * 1024;
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > maxBytes) fail(413, 'too_large');
  const id = crypto.randomBytes(16).toString('hex');
  const tmp = path.join(MEDIA_DIR, id + '.part');
  let size = 0; let head = Buffer.alloc(0);
  await new Promise((resolve, reject) => {
    const ws = fs.createWriteStream(tmp);
    req.on('data', (c) => {
      size += c.length;
      if (head.length < 16) head = Buffer.concat([head, c.subarray(0, 16)]);
      if (size > maxBytes) { req.unpipe(ws); ws.destroy(); req.destroy(); reject(new HttpError(413, 'too_large')); }
    });
    req.pipe(ws);
    ws.on('finish', resolve); ws.on('error', reject); req.on('error', reject);
  }).catch(async (e) => { await fsp.rm(tmp, { force: true }); throw e; });
  let kindInfo = sniff(head);
  if (!kindInfo || kindInfo[0] !== kind) { await fsp.rm(tmp, { force: true }); fail(415, 'bad_file_type'); }
  // الفيديو يُحفظ mp4 والصور jpg (عدا png/gif) بعد مسح البيانات المخفية، ثم يُشفَّر
  const ext = kind === 'video' ? 'mp4' : (['png', 'gif'].includes(kindInfo[2]) ? kindInfo[2] : 'jpg');
  const plain = path.join(MEDIA_DIR, id + '.plain.' + ext);
  await fsp.rename(tmp, plain);
  try {
    let duration = 0;
    if (kind === 'video') {
      const d = await probeDuration(plain);
      // ffprobe موجود: فشله يعني أن الملف ليس فيديو صالحاً (لا نثق بترويسة العميل لتجاوز حد الساعة)
      if (d === null) fail(415, 'bad_file_type');
      duration = d === undefined ? (Math.max(0, Number(req.headers['x-duration'])) || 0) : d;
      if (duration > MAX_VIDEO_SECONDS + 1) fail(400, 'video_too_long');
    }
    const cleaned = await stripMetadata(plain, kind, ext);
    if (!cleaned && kind === 'image') fail(415, 'bad_file_type');
    const finalExt = kind === 'video' && !cleaned ? kindInfo[2] : ext;
    const mime = kind === 'video' ? (cleaned ? 'video/mp4' : kindInfo[1]) : (ext === 'jpg' ? 'image/jpeg' : 'image/' + ext);
    const finalName = id + '.' + finalExt;
    await encryptFile(plain, path.join(MEDIA_DIR, finalName));
    q('INSERT INTO files(id,user_id,kind,mime,size,duration,created_at) VALUES(?,?,?,?,?,?,?)').run(finalName, user.id, kind, mime, size, duration, now());
    send(res, 200, { id: finalName, duration });
  } finally { await fsp.rm(plain, { force: true }); }
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.woff2': 'font/woff2' };
function serveFile(req, res, file, mime, { cache = 'public, max-age=3600' } = {}) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    const range = req.headers.range;
    const base = { 'Content-Type': mime, 'Accept-Ranges': 'bytes', 'Cache-Control': cache, ...securityHeaders() };
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      let start = m && m[1] ? parseInt(m[1], 10) : 0;
      let end = m && m[2] ? parseInt(m[2], 10) : st.size - 1;
      if (m && !m[1] && m[2]) { start = Math.max(0, st.size - parseInt(m[2], 10)); end = st.size - 1; }
      if (!m || start >= st.size || end < start) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}`, ...securityHeaders() }); return res.end(); }
      end = Math.min(end, st.size - 1);
      res.writeHead(206, { ...base, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Content-Length': end - start + 1 });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(file, { start, end }).on('error', () => res.destroy()).pipe(res);
    }
    res.writeHead(200, { ...base, 'Content-Length': st.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).on('error', () => res.destroy()).pipe(res); // ملف حُذف أثناء القراءة كان يُسقط العملية كلها
  });
}

// ---------------------------------------------------------------- حذف الحسابات وملفاتها
async function deleteUserCompletely(userId) {
  const files = q('SELECT id FROM files WHERE user_id=?').all(userId);
  q('DELETE FROM messages WHERE from_id=? OR to_id=?').run(userId, userId);
  q('DELETE FROM users WHERE id=?').run(userId);
  for (const f of files) await fsp.rm(path.join(MEDIA_DIR, f.id), { force: true }).catch(() => {});
}
async function deletePostCompletely(postId) {
  const p = q('SELECT * FROM posts WHERE id=?').get(postId);
  if (!p) return;
  const ids = [p.video_id, p.thumb_id, ...JSON.parse(p.images || '[]')].filter(Boolean);
  q('DELETE FROM reports WHERE target_type=? AND target_id=?').run('post', postId);
  for (const f of await fsp.readdir(path.join(DATA_DIR, 'exports')).catch(() => [])) if (f.startsWith(postId + '-')) await fsp.rm(path.join(DATA_DIR, 'exports', f), { force: true }).catch(() => {});
  q('DELETE FROM posts WHERE id=?').run(postId);
  for (const id of ids) {
    q('DELETE FROM files WHERE id=?').run(id);
    await fsp.rm(path.join(MEDIA_DIR, id), { force: true }).catch(() => {});
  }
}
// المرفوض يُحذف فوراً بملفاته — يبقى سطر صغير فقط ليعرف الناشر سبب الرفض
async function purgePostMedia(postId) {
  const p = q('SELECT * FROM posts WHERE id=?').get(postId);
  if (!p) return;
  const ids = [p.video_id, p.thumb_id, ...JSON.parse(p.images || '[]')].filter(Boolean);
  q("UPDATE posts SET video_id=NULL, thumb_id=NULL, images='[]', subtitles='[]', body='', title=substr(title,1,60) WHERE id=?").run(postId);
  q('DELETE FROM translations WHERE post_id=?').run(postId);
  for (const id of ids) { q('DELETE FROM files WHERE id=?').run(id); await fsp.rm(path.join(MEDIA_DIR, id), { force: true }).catch(() => {}); }
}
// تنظيف دوري: حذف الحسابات الغائبة، الجلسات القديمة، الملفات غير المستخدمة
async function sweep() {
  try {
    const t = now();
    const gone = q("SELECT id FROM users WHERE role='user' AND last_active < (? - inactivity_days*86400000)").all(t);
    for (const g of gone) await deleteUserCompletely(g.id);
    q('DELETE FROM sessions WHERE created_at < ?').run(t - SESSION_DAYS * 86400000);
    const orphan = q('SELECT id FROM files WHERE used=0 AND created_at < ?').all(t - 6 * 3600000);
    for (const f of orphan) { q('DELETE FROM files WHERE id=?').run(f.id); await fsp.rm(path.join(MEDIA_DIR, f.id), { force: true }).catch(() => {}); }
    const exp = path.join(DATA_DIR, 'exports');
    for (const f of await fsp.readdir(exp).catch(() => [])) { const st = await fsp.stat(path.join(exp, f)).catch(() => null); if (st && t - st.mtimeMs > 2 * 86400000) await fsp.rm(path.join(exp, f), { force: true }).catch(() => {}); }
    q('DELETE FROM security_events WHERE created_at < ?').run(t - 90 * 86400000);
    // الحذف التلقائي للمحتوى بعد مدة يحددها المؤسس (0 = يبقى)
    const ttl = Number(getSetting('content_ttl_days', '0')) || 0;
    if (ttl > 0) for (const p of q("SELECT id FROM posts WHERE status='approved' AND approved_at < ?").all(t - ttl * 86400000)) await deletePostCompletely(p.id);
    // سطر سبب الرفض يُمسح بعد 30 يوماً
    q("DELETE FROM posts WHERE status='rejected' AND created_at < ?").run(t - 30 * 86400000);
    // ملفات مؤقتة متروكة
    for (const f of await fsp.readdir(MEDIA_DIR).catch(() => [])) if (/\.(part|plain\.)/.test(f)) { const st = await fsp.stat(path.join(MEDIA_DIR, f)).catch(() => null); if (st && t - st.mtimeMs > 6 * 3600000) await fsp.rm(path.join(MEDIA_DIR, f), { force: true }).catch(() => {}); }
    if (gone.length) console.log(`[sweep] حُذف ${gone.length} حساب غائب`);
  } catch (e) { console.error('[sweep]', e); }
}
function startSweep() { setInterval(sweep, 3600000).unref(); setTimeout(sweep, 5000).unref(); }

// ---------------------------------------------------------------- الموجّه
function createRouter() {
  const routes = [];
  function route(method, pattern, handler, opts = {}) {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, handler, opts });
  }
  async function dispatch(req, res, pathname, ctx) {
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = r.re.exec(pathname);
      if (!m) continue;
      const params = {}; r.keys.forEach((k, i) => { params[k] = m[i + 1]; });
      await r.handler(req, res, { ...ctx, params });
      return true;
    }
    return false;
  }
  return { route, dispatch };
}
function need(u) { if (!u) fail(401, 'login_required'); if (u.banned) fail(403, 'banned'); return u; }
function needStaff(u) { if (!isStaff(u)) fail(404, 'not_found'); return u; }
function needMod2(u) { if (!isMod2(u)) fail(404, 'not_found'); return u; }
// المشرف لا يتصرّف في محتوى المؤسس (حذف/رفض) — المؤسس فقط
function guardOwner(actor, ownerId) { if (actor.id !== ownerId && !isFounder(actor)) { const o = q('SELECT role FROM users WHERE id=?').get(ownerId); if (o && o.role === 'founder') fail(403, 'forbidden'); } }
function needFounder(u) { if (!isFounder(u)) fail(404, 'not_found'); return u; }
const int = (v) => { const n = parseInt(v, 10); if (!Number.isSafeInteger(n)) fail(400, 'bad_id'); return n; };

// ---- عام

module.exports = {
  MEDIA_KEY, encryptFile, decryptStream, decryptToFile, serveMedia, stripMetadata, purgePostMedia, runTool,
  fs,
  fsp,
  path,
  crypto,
  ROOT,
  DATA_DIR,
  MEDIA_DIR,
  PUBLIC_DIR,
  PORT,
  HOST,
  DEEPL_KEY,
  SECURE_COOKIE,
  MAX_VIDEO_MB,
  MAX_IMAGE_MB,
  MAX_VIDEO_SECONDS,
  SESSION_DAYS,
  CATEGORIES,
  REPORT_REASONS,
  INACTIVITY_CHOICES,
  LANGS,
  db,
  q,
  now,
  getSetting,
  setSetting,
  flag,
  founderExists,
  hashSecret,
  checkSecret,
  sha,
  makeSecurityKey,
  normKey,
  makeCode,
  attempts,
  tooMany,
  noteAttempt,
  VISITOR_SECRET,
  clientIp,
  visitorOf,
  SEV_SCORE,
  AUTO_BLOCK_SCORE,
  AUTO_BLOCK_HOURS,
  lastEvent,
  securityEvent,
  isBlocked,
  PROBE_RE,
  INJECT_RE,
  scanRequest,
  CANARIES,
  CANARY,
  CANARY_VALUES,
  DECOY_LOGIN,
  MAX_TARPITS,
  sleep,
  canaryUsed,
  fakeEnv,
  serveDecoy,
  MAINTENANCE,
  serveBlocked,
  notFoundHits,
  noteNotFound,
  send,
  securityHeaders,
  HttpError,
  fail,
  readJson,
  parseCookies,
  sessionCookie,
  str,
  currentUser,
  STAFF_ROLES,
  isFounder,
  isStaff,
  isMod2,
  canPublish,
  publicUser,
  audit,
  DEEPL_TARGET,
  deeplTranslate,
  getTranslation,
  parseTime,
  parseSubtitles,
  postRow,
  ORDER_FEED,
  ORDER_EXPLORE,
  listPosts,
  sniff,
  probeDuration,
  handleUpload,
  MIME,
  serveFile,
  deleteUserCompletely,
  deletePostCompletely,
  sweep,
  startSweep,
  createRouter,
  need,
  needStaff,
  needMod2,
  guardOwner,
  needFounder,
  int,
};
