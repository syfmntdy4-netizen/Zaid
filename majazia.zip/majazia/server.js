'use strict';
/*
 * مجازية — Majazia · خادم الموقع
 * منصة ريلز ومنشورات تعليمية هادفة بدون موسيقى.
 * لوحة المؤسس قسم سري منفصل (رابط سري + دخول خاص + رقم أمان متغيّر)، لا علاقة له بحسابات الموقع.
 */
process.removeAllListeners('warning');
const http = require('node:http');
const core = require('./core');
const {
  fs, fsp, path, crypto,
} = { fs: require('node:fs'), fsp: require('node:fs/promises'), path: require('node:path'), crypto: require('node:crypto') };
const {
  ROOT, DATA_DIR, MEDIA_DIR, PUBLIC_DIR, PORT, HOST, DEEPL_KEY, MAX_VIDEO_MB, MAX_VIDEO_SECONDS, SESSION_DAYS,
  CATEGORIES, REPORT_REASONS, INACTIVITY_CHOICES, LANGS,
  q, now, getSetting, setSetting, flag, hashSecret, checkSecret, sha, makeSecurityKey, normKey,
  tooMany, noteAttempt, attempts, clientIp, visitorOf, securityEvent, isBlocked, scanRequest, INJECT_RE,
  canaryUsed, serveDecoy, serveBlocked, noteNotFound, send, HttpError, fail, readJson, parseCookies, sessionCookie, str,
  currentUser, isStaff, isFounder, isMod2, canPublish, publicUser, audit, getTranslation, parseSubtitles, postRow, listPosts,
  handleUpload, MIME, serveFile, serveMedia, encryptFile, decryptToFile, purgePostMedia, MEDIA_KEY, founderExists, makeCode, securityHeaders, sleep, deleteUserCompletely, deletePostCompletely, startSweep,
  createRouter, need, needStaff, needMod2, guardOwner, int, MAINTENANCE,
} = core;
const { route, dispatch } = createRouter();

// عدادات غرفة المشرفين
function staffCounts(user) {
  const c = (sql, ...a) => q(sql).get(...a).n;
  const out = {
    pending: c("SELECT COUNT(*) n FROM posts WHERE status='pending'"),
    reports: c("SELECT COUNT(*) n FROM reports WHERE status='open'"),
    requests: c("SELECT COUNT(*) n FROM publish_requests WHERE status='pending'"),
    room: c('SELECT COUNT(*) n FROM staff_messages WHERE created_at>? AND (user_id IS NULL OR user_id!=?)', Number(getSetting('room_seen_' + user.id, '0')), user.id),
  };
  if (isMod2(user)) out.complaints = c('SELECT COUNT(*) n FROM messages WHERE to_id=0 AND is_read=0');
  return out;
}

route('GET', '/api/config', (req, res, { user }) => send(res, 200, {
  categories: CATEGORIES, report_reasons: REPORT_REASONS, inactivity_choices: INACTIVITY_CHOICES,
  max_video_seconds: MAX_VIDEO_SECONDS, max_video_mb: MAX_VIDEO_MB, deepl: !!DEEPL_KEY,
  registration_open: getSetting('registration_open', '1') === '1',
  me: user ? publicUser(user, user) : null,
  staff: isStaff(user) ? { level: user.role === 'mod1' ? 1 : 2, founder: isFounder(user), counts: staffCounts(user) } : null,
  maintenance: flag('maintenance'),
  freeze_publishing: flag('freeze_publishing'),
  unread: user ? q('SELECT COUNT(*) n FROM messages WHERE to_id=? AND is_read=0').get(user.id).n : 0,
}));

// ---- الحسابات
route('POST', '/api/auth/register', async (req, res) => {
  if (getSetting('registration_open', '1') !== '1') fail(403, 'registration_closed');
  const ip = clientIp(req);
  if (tooMany('reg:' + sha(ip), 5, 3600000)) fail(429, 'too_many_attempts');
  const b = await readJson(req);
  const name = str(b.name, 40, { required: true });
  const username = str(b.username, 20, { required: true }).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';
  const lang = LANGS.includes(b.lang) ? b.lang : 'ar';
  const inactivity = INACTIVITY_CHOICES.includes(Number(b.inactivity_days)) ? Number(b.inactivity_days) : 30;
  if (!/^[a-z0-9_.]{3,20}$/.test(username)) { if (INJECT_RE.test(String(b.username)) || INJECT_RE.test(String(b.name))) securityEvent(req, 'injection_attempt', 'high', 'حقن داخل نموذج إنشاء الحساب'); fail(400, 'bad_username'); }
  if (password.length < 8 || password.length > 128) fail(400, 'weak_password');
  // "majazia" محجوز لمحادثة الإدارة (/api/chat/with/majazia) — تسجيله يسمح بانتحال صفة الدعم
  if (/^(majazia|admin|administrator|support|founder|moderator|root|system)$/.test(username)) fail(409, 'username_taken');
  if (q('SELECT 1 FROM users WHERE username=?').get(username)) fail(409, 'username_taken');
  noteAttempt('reg:' + sha(ip));
  const key = makeSecurityKey();
  const t = now();
  const r = q('INSERT INTO users(name,username,pass_hash,key_hash,lang,inactivity_days,last_active,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(name, username, hashSecret(password), hashSecret(normKey(key)), lang, inactivity, t, t);
  const token = crypto.randomBytes(32).toString('hex');
  q('INSERT INTO sessions(token_hash,user_id,created_at) VALUES(?,?,?)').run(sha(token), r.lastInsertRowid, t);
  const u = q('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);
  send(res, 200, { me: publicUser(u, u), security_key: key }, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
});

route('POST', '/api/auth/login', async (req, res) => {
  const b = await readJson(req);
  if (INJECT_RE.test(String(b.username))) securityEvent(req, 'injection_attempt', 'high', 'حقن داخل نموذج تسجيل الدخول');
  if (canaryUsed(req, JSON.stringify(b))) securityEvent(req, 'canary_used', 'high', 'استخدم كلمة سر مزيفة سرقها من فخ — مخترق مؤكد');
  const username = str(b.username, 20, { required: true }).toLowerCase();
  const ip = clientIp(req);
  if (tooMany('login:' + username + ':' + visitorOf(req)) || tooMany('loginip:' + sha(ip), 30)) fail(429, 'too_many_attempts');
  const u = q('SELECT * FROM users WHERE username=?').get(username);
  const ok = u && checkSecret(String(b.password || ''), u.pass_hash) && checkSecret(normKey(b.security_key), u.key_hash);
  if (!ok) {
    noteAttempt('login:' + username + ':' + visitorOf(req)); noteAttempt('loginip:' + sha(ip));
    const n = (attempts.get('login:' + username + ':' + visitorOf(req)) || []).length;
    if (n === 5) securityEvent(req, 'brute_force', 'medium', `محاولات دخول فاشلة متكررة على الحساب @${username}`);
    if (u && u.role !== 'user' && n >= 3) securityEvent(req, 'staff_login_attack', 'high', `محاولة دخول فاشلة على حساب إداري @${username}`);
    fail(401, 'bad_credentials');
  }
  if (u.banned) fail(403, 'banned');
  const token = crypto.randomBytes(32).toString('hex');
  q('INSERT INTO sessions(token_hash,user_id,created_at) VALUES(?,?,?)').run(sha(token), u.id, now());
  q('UPDATE users SET last_active=? WHERE id=?').run(now(), u.id);
  send(res, 200, { me: publicUser(u, u) }, { 'Set-Cookie': sessionCookie(token, SESSION_DAYS * 86400) });
});

route('POST', '/api/auth/reset', async (req, res) => {
  const b = await readJson(req);
  const username = str(b.username, 20, { required: true }).toLowerCase();
  if (tooMany('reset:' + username, 5)) fail(429, 'too_many_attempts');
  const u = q('SELECT * FROM users WHERE username=?').get(username);
  const pw = typeof b.new_password === 'string' ? b.new_password : '';
  if (pw.length < 8 || pw.length > 128) fail(400, 'weak_password');
  if (!u || !checkSecret(normKey(b.security_key), u.key_hash)) { noteAttempt('reset:' + username); fail(401, 'bad_credentials'); }
  q('UPDATE users SET pass_hash=? WHERE id=?').run(hashSecret(pw), u.id);
  q('DELETE FROM sessions WHERE user_id=?').run(u.id);
  send(res, 200, { ok: true });
});

route('POST', '/api/auth/logout', (req, res) => {
  const tok = parseCookies(req).mjz_s;
  if (tok) q('DELETE FROM sessions WHERE token_hash=?').run(sha(tok));
  send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', 0) });
});

route('POST', '/api/me', async (req, res, { user }) => {
  need(user);
  const b = await readJson(req);
  const name = b.name !== undefined ? str(b.name, 40, { required: true }) : user.name;
  const bio = b.bio !== undefined ? str(b.bio, 200, { multiline: true }) : user.bio;
  const lang = LANGS.includes(b.lang) ? b.lang : user.lang;
  const inact = INACTIVITY_CHOICES.includes(Number(b.inactivity_days)) ? Number(b.inactivity_days) : user.inactivity_days;
  q('UPDATE users SET name=?, bio=?, lang=?, inactivity_days=? WHERE id=?').run(name, bio, lang, inact, user.id);
  const u = q('SELECT * FROM users WHERE id=?').get(user.id);
  send(res, 200, { me: publicUser(u, u) });
});

route('POST', '/api/me/delete', async (req, res, { user }) => {
  if (!user) fail(401, 'login_required');
  if (user.role === 'founder') fail(400, 'founder_cannot_delete');
  const b = await readJson(req);
  if (!checkSecret(String(b.password || ''), user.pass_hash)) fail(401, 'bad_credentials');
  await deleteUserCompletely(user.id);
  send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', 0) });
});

route('POST', '/api/me/redeem', async (req, res, { user }) => {
  need(user);
  if (tooMany('redeem:' + user.id, 10)) fail(429, 'too_many_attempts');
  const b = await readJson(req);
  const code = str(b.code, 20, { required: true }).toUpperCase().replace(/[^A-Z0-9]/g, '').replace(/(.{5})(.{5})/, '$1-$2');
  const c = q('SELECT * FROM codes WHERE code=?').get(code);
  if (!c || !c.active || c.uses >= c.max_uses) { noteAttempt('redeem:' + user.id); fail(400, 'bad_code'); }
  if (q('SELECT 1 FROM code_uses WHERE code=? AND user_id=?').get(code, user.id)) fail(400, 'code_already_used');
  let until;
  if (c.grant_days === 0) until = -1;
  else { const base = user.publish_until > now() ? user.publish_until : now(); until = user.publish_until === -1 ? -1 : base + c.grant_days * 86400000; }
  q('UPDATE users SET publish_until=? WHERE id=?').run(until, user.id);
  q('UPDATE codes SET uses=uses+1 WHERE code=?').run(code);
  q('INSERT INTO code_uses(code,user_id,used_at) VALUES(?,?,?)').run(code, user.id, now());
  send(res, 200, { publish_until: until });
});

// ---- الحسابات العامة
route('GET', '/api/users/:username', (req, res, { user, params, query }) => {
  const u = q('SELECT * FROM users WHERE username=?').get(params.username);
  if (!u || (u.banned && !isStaff(user))) fail(404, 'not_found');
  const kind = query.get('kind') === 'post' ? 'post' : (query.get('kind') === 'reel' ? 'reel' : null);
  const posts = listPosts({ author: u.id, kind, viewer: user, limit: 30, offset: int(query.get('offset') || 0) });
  const counts = q("SELECT SUM(kind='reel') reels, SUM(kind='post') posts FROM posts WHERE user_id=? AND status='approved'").get(u.id);
  send(res, 200, { user: publicUser(u, user), posts, counts: { reels: counts.reels || 0, posts: counts.posts || 0 } });
});

// ---- المنشورات والريلز
route('GET', '/api/feed', (req, res, { user, query }) => {
  const kind = query.get('kind') === 'reel' ? 'reel' : (query.get('kind') === 'post' ? 'post' : null);
  const order = query.get('order') === 'explore' ? 'explore' : 'feed';
  send(res, 200, { posts: listPosts({ kind, order, category: query.get('category'), search: str(query.get('q') || '', 80), viewer: user, limit: int(query.get('limit') || 20), offset: int(query.get('offset') || 0) }) });
});
route('GET', '/api/posts/:id', async (req, res, { user, params, query }) => {
  const p = q('SELECT * FROM posts WHERE id=?').get(int(params.id));
  if (!p) fail(404, 'not_found');
  if (p.status !== 'approved' && !(user && (user.id === p.user_id || isStaff(user)))) fail(404, 'not_found');
  if (!isStaff(user) && q('SELECT banned FROM users WHERE id=?').get(p.user_id)?.banned) fail(404, 'not_found'); // منشورات المحظور مخفية في الخلاصة؛ تُخفى أيضاً بالرابط المباشر
  const out = postRow(p, user);
  out.subtitles = JSON.parse(p.subtitles || '[]');
  const lang = query.get('lang');
  if (lang && LANGS.includes(lang) && lang !== p.source_lang) {
    try { out.translation = await getTranslation(p, lang); } catch (e) { out.translation = null; out.translation_error = true; }
  }
  send(res, 200, { post: out });
});
const viewSeen = new Map(); // مشاهدة واحدة لكل زائر لكل فيديو خلال 6 ساعات (منع تضخيم الأرقام)
setInterval(() => { const t = now(); for (const [k, v] of viewSeen) if (t - v > 6 * 3600000) viewSeen.delete(k); }, 600000).unref();
route('POST', '/api/posts/:id/view', (req, res, { params }) => {
  const id = int(params.id); const k = visitorOf(req) + ':' + id;
  if (!viewSeen.has(k) && viewSeen.size < 500000) { viewSeen.set(k, now()); q("UPDATE posts SET views=views+1 WHERE id=? AND status='approved'").run(id); }
  send(res, 200, { ok: true });
});
route('POST', '/api/upload/:kind', async (req, res, { user, params }) => { need(user); await handleUpload(req, res, user, params.kind); }, { raw: true });

route('POST', '/api/posts', async (req, res, { user }) => {
  need(user);
  if (!canPublish(user)) fail(403, 'no_publish_permission');
  if (tooMany('post:' + user.id, 30, 3600000)) fail(429, 'too_many_attempts');
  const b = await readJson(req, 2 * 1024 * 1024);
  const kind = b.kind === 'reel' ? 'reel' : 'post';
  const category = CATEGORIES.includes(b.category) ? b.category : fail(400, 'bad_category');
  const title = str(b.title, 120);
  const body = str(b.body, 2000, { multiline: true });
  const source_lang = LANGS.includes(b.source_lang) ? b.source_lang : 'ar';
  const ownFile = (id, kindWanted) => {
    if (!id) return null;
    const f = q('SELECT * FROM files WHERE id=? AND user_id=? AND used=0').get(String(id), user.id);
    if (!f || f.kind !== kindWanted) fail(400, 'bad_file');
    return f;
  };
  let video = null, thumb = null, images = [], subtitles = [];
  if (kind === 'reel') {
    if (b.no_music !== true) fail(400, 'confirm_no_music');
    video = ownFile(b.video_id, 'video'); if (!video) fail(400, 'video_required');
    thumb = ownFile(b.thumb_id, 'image');
    subtitles = parseSubtitles(b.subtitles);
    if (!title) fail(400, 'title_required');
  } else {
    images = (Array.isArray(b.images) ? b.images.slice(0, 4) : []).map((i) => ownFile(i, 'image'));
    if (!body && !images.length) fail(400, 'empty_post');
  }
  const approval = getSetting('approval_required', '1') === '1' && !isFounder(user); // حتى منشورات المشرفين تمر بالمراجعة
  const status = approval ? 'pending' : 'approved';
  const t = now();
  // جزء من سلسلة: يتابع فيديو سابقاً لنفس الناشر
  let seriesId = null, partNo = 0;
  if (kind === 'reel' && b.continues) {
    const prev = q("SELECT * FROM posts WHERE id=? AND user_id=? AND kind='reel' AND status IN ('approved','pending')").get(int(b.continues), user.id);
    if (!prev) fail(400, 'bad_series');
    seriesId = prev.series_id || prev.id;
    if (!prev.series_id) q('UPDATE posts SET series_id=?, part_no=1 WHERE id=?').run(prev.id, prev.id);
    partNo = q('SELECT MAX(part_no) m FROM posts WHERE series_id=?').get(seriesId).m + 1;
    if (partNo > 50) fail(400, 'bad_series');
  }
  const r = q(`INSERT INTO posts(user_id,kind,title,body,category,video_id,thumb_id,images,duration,subtitles,source_lang,status,created_at,approved_at,series_id,part_no)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(user.id, kind, title, body, category, video ? video.id : null, thumb ? thumb.id : null,
    JSON.stringify(images.map((i) => i.id)), video ? video.duration : 0, JSON.stringify(subtitles), source_lang, status, t, status === 'approved' ? t : null, seriesId, partNo);
  for (const f of [video, thumb, ...images].filter(Boolean)) q('UPDATE files SET used=1 WHERE id=?').run(f.id);
  send(res, 200, { id: Number(r.lastInsertRowid), status, subtitle_count: subtitles.length });
});

route('POST', '/api/posts/:id/delete', async (req, res, { user, params }) => {
  need(user);
  const p = q('SELECT * FROM posts WHERE id=?').get(int(params.id));
  if (!p) fail(404, 'not_found');
  if (p.user_id !== user.id && !isStaff(user)) fail(403, 'forbidden');
  guardOwner(user, p.user_id);
  await deletePostCompletely(p.id);
  if (p.user_id !== user.id) audit(user, 'delete_post', p.id);
  send(res, 200, { ok: true });
});
// كل أجزاء السلسلة (المنشورة) — تظهر مثبّتة في التعليقات
route('GET', '/api/posts/:id/parts', (req, res, { params }) => {
  const p = q("SELECT series_id FROM posts WHERE id=?").get(int(params.id));
  if (!p || !p.series_id) return send(res, 200, { parts: [] });
  const rows = q("SELECT p.* FROM posts p JOIN users u ON u.id=p.user_id WHERE p.series_id=? AND p.status='approved' AND u.banned=0 ORDER BY p.part_no").all(p.series_id);
  send(res, 200, { parts: rows.map((x) => postRow(x, req._user)) });
});
// فيديوهاتي التي يمكن أن يتابعها جزء جديد
route('GET', '/api/my/reels', (req, res, { user }) => {
  need(user);
  const rows = q("SELECT id, title, part_no, series_id FROM posts WHERE user_id=? AND kind='reel' AND status IN ('approved','pending') ORDER BY created_at DESC LIMIT 50").all(user.id);
  send(res, 200, { reels: rows });
});
route('GET', '/api/my/posts', (req, res, { user }) => {
  need(user);
  const rows = q('SELECT * FROM posts WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(user.id);
  send(res, 200, { posts: rows.map((p) => postRow(p, user)) });
});

route('POST', '/api/posts/:id/like', (req, res, { user, params }) => {
  need(user);
  const id = int(params.id);
  if (!q("SELECT 1 FROM posts WHERE id=? AND status='approved'").get(id)) fail(404, 'not_found');
  const has = q('SELECT 1 FROM likes WHERE user_id=? AND post_id=?').get(user.id, id);
  if (has) q('DELETE FROM likes WHERE user_id=? AND post_id=?').run(user.id, id);
  else q('INSERT INTO likes(user_id,post_id) VALUES(?,?)').run(user.id, id);
  send(res, 200, { liked: !has, likes: q('SELECT COUNT(*) n FROM likes WHERE post_id=?').get(id).n });
});

route('GET', '/api/posts/:id/comments', (req, res, { params }) => {
  const rows = q(`SELECT c.*, u.name, u.username, u.verified FROM comments c JOIN users u ON u.id=c.user_id
    WHERE c.post_id=? AND u.banned=0 ORDER BY CASE u.verified WHEN 'gold' THEN 0 ELSE 1 END, c.created_at DESC LIMIT 200`).all(int(params.id));
  send(res, 200, { comments: rows.map((c) => ({ id: c.id, body: c.body, created_at: c.created_at, author: { id: c.user_id, name: c.name, username: c.username, verified: c.verified } })) });
});
route('POST', '/api/posts/:id/comments', async (req, res, { user, params }) => {
  need(user);
  if (tooMany('cmt:' + user.id, 40, 600000)) fail(429, 'too_many_attempts');
  noteAttempt('cmt:' + user.id);
  const id = int(params.id);
  if (!q("SELECT 1 FROM posts WHERE id=? AND status='approved'").get(id)) fail(404, 'not_found');
  const b = await readJson(req);
  const body = str(b.body, 500, { required: true, multiline: true });
  const r = q('INSERT INTO comments(post_id,user_id,body,created_at) VALUES(?,?,?,?)').run(id, user.id, body, now());
  send(res, 200, { id: Number(r.lastInsertRowid) });
});
route('POST', '/api/comments/:id/delete', (req, res, { user, params }) => {
  need(user);
  const c = q('SELECT * FROM comments WHERE id=?').get(int(params.id));
  if (!c) fail(404, 'not_found');
  const p = q('SELECT user_id FROM posts WHERE id=?').get(c.post_id);
  if (c.user_id !== user.id && !isStaff(user) && !(p && p.user_id === user.id)) fail(403, 'forbidden');
  if (!(p && p.user_id === user.id)) guardOwner(user, c.user_id);
  q('DELETE FROM comments WHERE id=?').run(c.id);
  q("DELETE FROM reports WHERE target_type='comment' AND target_id=?").run(c.id);
  if (isStaff(user) && c.user_id !== user.id) audit(user, 'delete_comment', c.id);
  send(res, 200, { ok: true });
});

// ---- البلاغات
route('POST', '/api/reports', async (req, res, { user }) => {
  need(user);
  if (tooMany('rep:' + user.id, 20, 3600000)) fail(429, 'too_many_attempts');
  noteAttempt('rep:' + user.id);
  const b = await readJson(req);
  const type = ['post', 'comment', 'user'].includes(b.target_type) ? b.target_type : fail(400, 'bad_target');
  const reason = REPORT_REASONS.includes(b.reason) ? b.reason : fail(400, 'bad_reason');
  const tid = int(b.target_id);
  const table = { post: 'posts', comment: 'comments', user: 'users' }[type];
  if (!q(`SELECT 1 FROM ${table} WHERE id=?`).get(tid)) fail(404, 'not_found');
  if (q("SELECT 1 FROM reports WHERE reporter_id=? AND target_type=? AND target_id=? AND status='open'").get(user.id, type, tid)) return send(res, 200, { ok: true });
  q('INSERT INTO reports(reporter_id,target_type,target_id,reason,details,created_at) VALUES(?,?,?,?,?,?)').run(user.id, type, tid, reason, str(b.details, 500, { multiline: true }), now());
  send(res, 200, { ok: true });
});

// ---- طلب التوثيق
route('POST', '/api/verify-request', async (req, res, { user }) => {
  need(user);
  const b = await readJson(req);
  const type = b.type === 'gold' ? 'gold' : 'blue';
  if (q("SELECT 1 FROM verify_requests WHERE user_id=? AND status='pending'").get(user.id)) fail(409, 'request_pending');
  const note = str(b.note, 500, { multiline: true });
  q('INSERT INTO verify_requests(user_id,type,note,created_at) VALUES(?,?,?,?)').run(user.id, type, note, now());
  q('INSERT INTO messages(from_id,to_id,body,created_at) VALUES(?,?,?,?)').run(user.id, 0, `${type === 'gold' ? '🟡' : '🔵'} ✔ ${note}`.trim(), now());
  send(res, 200, { ok: true });
});

// ---- الشات
route('GET', '/api/chat/threads', (req, res, { user }) => {
  need(user);
  const rows = q(`SELECT CASE WHEN via_support=1 AND to_id=? THEN 0 WHEN from_id=? AND via_support=0 THEN to_id ELSE from_id END peer, MAX(created_at) last,
      SUM(CASE WHEN to_id=? AND is_read=0 THEN 1 ELSE 0 END) unread
    FROM messages WHERE (from_id=? AND via_support=0) OR to_id=? GROUP BY peer ORDER BY last DESC LIMIT 50`).all(user.id, user.id, user.id, user.id, user.id);
  const threads = rows.map((r) => {
    const last = r.peer === 0
      ? q('SELECT body FROM messages WHERE (from_id=? AND to_id=0) OR (to_id=? AND via_support=1) ORDER BY created_at DESC LIMIT 1').get(user.id, user.id)
      : q('SELECT body FROM messages WHERE via_support=0 AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?)) ORDER BY created_at DESC LIMIT 1').get(user.id, r.peer, r.peer, user.id);
    const u = r.peer === 0 ? null : q('SELECT * FROM users WHERE id=?').get(r.peer);
    if (r.peer !== 0 && !u) return null;
    return { peer: r.peer === 0 ? { id: 0, name: 'Majazia', username: 'majazia', verified: 'gold', support: true } : publicUser(u), last: last ? last.body.slice(0, 80) : '', at: r.last, unread: r.unread };
  }).filter(Boolean);
  if (!threads.some((t) => t.peer.id === 0)) threads.push({ peer: { id: 0, name: 'Majazia', username: 'majazia', verified: 'gold', support: true }, last: '', at: 0, unread: 0 });
  send(res, 200, { threads });
});
route('GET', '/api/chat/with/:peer', (req, res, { user, params, query }) => {
  need(user);
  const peer = params.peer === 'majazia' ? 0 : (q('SELECT id FROM users WHERE username=?').get(params.peer) || fail(404, 'not_found')).id;
  const since = Number(query.get('since') || 0);
  let rows;
  if (peer === 0) {
    rows = q('SELECT * FROM messages WHERE ((from_id=? AND to_id=0) OR (to_id=? AND via_support=1)) AND created_at>? ORDER BY created_at DESC LIMIT 100').all(user.id, user.id, since);
    q('UPDATE messages SET is_read=1 WHERE to_id=? AND via_support=1').run(user.id);
  } else {
    rows = q('SELECT * FROM messages WHERE via_support=0 AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?)) AND created_at>? ORDER BY created_at DESC LIMIT 100').all(user.id, peer, peer, user.id, since);
    q('UPDATE messages SET is_read=1 WHERE from_id=? AND to_id=? AND via_support=0').run(peer, user.id);
  }
  send(res, 200, { messages: rows.reverse().map((m) => ({ id: m.id, mine: m.from_id === user.id && !m.via_support, body: m.body, at: m.created_at })) });
});
route('POST', '/api/chat/with/:peer', async (req, res, { user, params }) => {
  need(user);
  if (tooMany('chat:' + user.id, 60, 600000)) fail(429, 'too_many_attempts');
  noteAttempt('chat:' + user.id);
  const peerUser = params.peer === 'majazia' ? null : q('SELECT * FROM users WHERE username=?').get(params.peer);
  if (params.peer !== 'majazia' && (!peerUser || peerUser.banned)) fail(404, 'not_found');
  if (peerUser && peerUser.id === user.id) fail(400, 'bad_target');
  const b = await readJson(req);
  const body = str(b.body, 1000, { required: true, multiline: true });
  q('INSERT INTO messages(from_id,to_id,body,created_at) VALUES(?,?,?,?)').run(user.id, peerUser ? peerUser.id : 0, body, now());
  send(res, 200, { ok: true });
});


// ---- طلب صلاحية النشر (المستخدم) — يظهر في غرفة المشرفين ولوحة المؤسس
route('POST', '/api/publish-request', async (req, res, { user }) => {
  need(user);
  if (canPublish(user)) fail(400, 'already_publisher');
  if (q("SELECT 1 FROM publish_requests WHERE user_id=? AND status='pending'").get(user.id)) fail(409, 'request_pending');
  const b = await readJson(req);
  q('INSERT INTO publish_requests(user_id,note,created_at) VALUES(?,?,?)').run(user.id, str(b.note, 500, { multiline: true }), now());
  send(res, 200, { ok: true });
});

// ================================================================ غرفة المشرفين (داخل الموقع، للمشرفين فقط)
// المستوى 1: مراجعة المنشورات المنتظرة والمبلّغ عنها.
// المستوى 2: نفس الشيء + حذف الحسابات + الحظر وفكّه + استقبال الشكاوى.
// المؤسس عضو في الغرفة أيضاً، وصلاحياته الكاملة في لوحة التحكم المنفصلة.
const staffName = (u) => ({ id: u.id, name: u.name, username: u.username, level: u.role === 'mod1' ? 1 : u.role === 'mod2' ? 2 : 0, founder: u.role === 'founder' });
route('GET', '/api/staff/overview', (req, res, { user }) => {
  needStaff(user);
  const members = q("SELECT * FROM users WHERE role IN ('mod1','mod2','founder') AND banned=0 ORDER BY CASE role WHEN 'founder' THEN 0 WHEN 'mod2' THEN 1 ELSE 2 END, name").all();
  send(res, 200, { me: staffName(user), counts: staffCounts(user), members: members.map((m) => ({ ...staffName(m), online: now() - m.last_active < 5 * 60000 })) });
});
route('GET', '/api/staff/room', (req, res, { user, query }) => {
  needStaff(user);
  const since = Number(query.get('since') || 0) || 0;
  const rows = q(`SELECT s.*, u.name, u.username, u.role FROM staff_messages s LEFT JOIN users u ON u.id=s.user_id
    WHERE s.created_at>? ORDER BY s.created_at DESC LIMIT 150`).all(since);
  setSetting('room_seen_' + user.id, now());
  send(res, 200, { messages: rows.reverse().map((m) => ({ id: m.id, body: m.body, at: m.created_at, mine: m.user_id === user.id,
    author: m.username ? { name: m.name, username: m.username, level: m.role === 'mod1' ? 1 : m.role === 'mod2' ? 2 : 0, founder: m.role === 'founder' } : null })) });
});
route('POST', '/api/staff/room', async (req, res, { user }) => {
  needStaff(user);
  if (tooMany('room:' + user.id, 60, 600000)) fail(429, 'too_many_attempts');
  noteAttempt('room:' + user.id);
  const b = await readJson(req);
  q('INSERT INTO staff_messages(user_id,body,created_at) VALUES(?,?,?)').run(user.id, str(b.body, 1500, { required: true, multiline: true }), now());
  send(res, 200, { ok: true });
});
route('GET', '/api/staff/pending', (req, res, { user }) => {
  needStaff(user);
  const rows = q("SELECT * FROM posts WHERE status='pending' ORDER BY created_at ASC LIMIT 100").all();
  send(res, 200, { founder_final: flag('founder_final_approval'), posts: rows.map((p) => ({ ...postRow(p, user), subtitles: JSON.parse(p.subtitles || '[]'),
    pre_approved_by: p.pre_approved_by ? (q('SELECT username FROM users WHERE id=?').get(p.pre_approved_by) || {}).username || null : null })) });
});
route('POST', '/api/staff/posts/:id/review', async (req, res, { user, params }) => {
  needStaff(user);
  const b = await readJson(req);
  const p = q('SELECT * FROM posts WHERE id=?').get(int(params.id));
  if (!p) fail(404, 'not_found');
  guardOwner(user, p.user_id);
  if (p.status !== 'pending') fail(400, 'bad_action');
  if (b.action === 'approve') {
    // فصل الصلاحيات: المشرف لا يوافق على منشوره هو — المؤسس أو مشرف آخر فقط
    if (p.user_id === user.id && !isFounder(user)) fail(403, 'forbidden');
    // الموافقة الأخيرة للمؤسس: موافقة المشرف مبدئية فقط وتنتقل للمؤسس
    if (flag('founder_final_approval') && !isFounder(user)) { q('UPDATE posts SET pre_approved_by=? WHERE id=?').run(user.id, p.id); audit(user, 'preapprove_post', p.id); return send(res, 200, { ok: true, status: 'pre_approved' }); }
    q("UPDATE posts SET status='approved', approved_at=?, reject_reason='' WHERE id=?").run(now(), p.id); audit(user, 'approve_post', p.id);
  } else if (b.action === 'reject') {
    q("UPDATE posts SET status='rejected', reject_reason=? WHERE id=?").run(str(b.reason, 300), p.id); await purgePostMedia(p.id); audit(user, 'reject_post', p.id);
  } else fail(400, 'bad_action');
  send(res, 200, { ok: true, status: b.action === 'approve' ? 'approved' : 'rejected' });
});
function reportView(r, user) {
  const reporter = r.reporter_id ? q('SELECT name, username FROM users WHERE id=?').get(r.reporter_id) : null;
  let target = null;
  if (r.target_type === 'post') { const p = q('SELECT * FROM posts WHERE id=?').get(r.target_id); target = p ? postRow(p, user) : null; }
  if (r.target_type === 'comment') { const c = q('SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.id=?').get(r.target_id); target = c ? { id: c.id, body: c.body, username: c.username, user_id: c.user_id, post_id: c.post_id } : null; }
  if (r.target_type === 'user') { const u = q('SELECT * FROM users WHERE id=?').get(r.target_id); target = u ? publicUser(u) : null; }
  const same = q("SELECT COUNT(*) n FROM reports WHERE target_type=? AND target_id=? AND status='open'").get(r.target_type, r.target_id).n;
  const handler = r.handled_by ? q('SELECT username FROM users WHERE id=?').get(r.handled_by) : null;
  return { id: r.id, target_type: r.target_type, target_id: r.target_id, reason: r.reason, details: r.details, status: r.status, created_at: r.created_at,
    reporter: reporter ? reporter.username : null, reporter_name: reporter ? reporter.name : null, target, same_count: same, handled_by: handler ? handler.username : null };
}
route('GET', '/api/staff/reports', (req, res, { user, query }) => {
  needStaff(user);
  const status = ['open', 'resolved', 'dismissed'].includes(query.get('status')) ? query.get('status') : 'open';
  send(res, 200, { reports: q('SELECT * FROM reports WHERE status=? ORDER BY created_at DESC LIMIT 200').all(status).map((r) => reportView(r, user)) });
});
route('POST', '/api/staff/reports/:id', async (req, res, { user, params }) => {
  needStaff(user);
  const r = q('SELECT * FROM reports WHERE id=?').get(int(params.id));
  if (!r) fail(404, 'not_found');
  const b = await readJson(req);
  if (b.action === 'remove_content') {
    if (r.target_type === 'post') { const p = q('SELECT user_id FROM posts WHERE id=?').get(r.target_id); if (p) { guardOwner(user, p.user_id); await deletePostCompletely(r.target_id); } }
    else if (r.target_type === 'comment') { const c = q('SELECT user_id FROM comments WHERE id=?').get(r.target_id); if (c) { guardOwner(user, c.user_id); q('DELETE FROM comments WHERE id=?').run(r.target_id); } }
    else fail(400, 'bad_action');
    q("UPDATE reports SET status='resolved', handled_by=? WHERE target_type=? AND target_id=? AND status='open'").run(user.id, r.target_type, r.target_id);
  } else if (b.action === 'resolve') q("UPDATE reports SET status='resolved', handled_by=? WHERE id=?").run(user.id, r.id);
  else if (b.action === 'dismiss') q("UPDATE reports SET status='dismissed', handled_by=? WHERE id=?").run(user.id, r.id);
  else fail(400, 'bad_action');
  audit(user, 'report_' + b.action, r.id);
  send(res, 200, { ok: true });
});
route('GET', '/api/staff/publish-requests', (req, res, { user }) => {
  needStaff(user);
  const rows = q(`SELECT r.*, u.name, u.username, u.verified, u.created_at joined,
      (SELECT COUNT(*) FROM reports WHERE target_type='user' AND target_id=u.id) reports_on_user
    FROM publish_requests r JOIN users u ON u.id=r.user_id WHERE r.status='pending' ORDER BY r.created_at`).all();
  send(res, 200, { requests: rows });
});
// ---- المستوى 2 فقط: الشكاوى والحسابات
route('GET', '/api/staff/inbox', (req, res, { user }) => {
  needMod2(user);
  const rows = q(`SELECT u.id, u.username, u.name, u.verified, MAX(m.created_at) last,
      SUM(CASE WHEN m.to_id=0 AND m.is_read=0 THEN 1 ELSE 0 END) unread
    FROM messages m JOIN users u ON u.id = CASE WHEN m.to_id=0 THEN m.from_id ELSE m.to_id END
    WHERE m.to_id=0 OR m.via_support=1 GROUP BY u.id ORDER BY last DESC LIMIT 100`).all();
  send(res, 200, { threads: rows });
});
route('GET', '/api/staff/inbox/:uid', (req, res, { user, params }) => {
  needMod2(user);
  const uid = int(params.uid);
  const rows = q('SELECT m.*, u.username staff FROM messages m LEFT JOIN users u ON u.id=m.from_id WHERE (m.from_id=? AND m.to_id=0) OR (m.to_id=? AND m.via_support=1) ORDER BY m.created_at DESC LIMIT 200').all(uid, uid);
  q('UPDATE messages SET is_read=1 WHERE from_id=? AND to_id=0').run(uid);
  send(res, 200, { messages: rows.reverse().map((m) => ({ id: m.id, from_user: !m.via_support, by: m.via_support ? m.staff : null, body: m.body, at: m.created_at })) });
});
route('POST', '/api/staff/inbox/:uid', async (req, res, { user, params }) => {
  needMod2(user);
  const uid = int(params.uid);
  if (!q('SELECT 1 FROM users WHERE id=?').get(uid)) fail(404, 'not_found');
  const b = await readJson(req);
  q('INSERT INTO messages(from_id,to_id,body,via_support,created_at) VALUES(?,?,?,1,?)').run(user.id, uid, str(b.body, 1000, { required: true, multiline: true }), now());
  send(res, 200, { ok: true });
});
route('GET', '/api/staff/users', (req, res, { user, query }) => {
  needMod2(user);
  const s = str(query.get('q') || '', 40);
  const banned = query.get('filter') === 'banned';
  const rows = q(`SELECT * FROM users WHERE role='user' AND (?='' OR username LIKE ? OR name LIKE ?) ${banned ? 'AND banned=1' : ''} ORDER BY created_at DESC LIMIT 100`).all(s, '%' + s + '%', '%' + s + '%');
  send(res, 200, { users: rows.map((u) => ({ id: u.id, name: u.name, username: u.username, verified: u.verified, banned: !!u.banned, ban_reason: u.ban_reason, last_active: u.last_active, created_at: u.created_at,
    posts: q('SELECT COUNT(*) n FROM posts WHERE user_id=?').get(u.id).n,
    reports: q("SELECT COUNT(*) n FROM reports WHERE target_type='user' AND target_id=? AND status='open'").get(u.id).n })) });
});
route('POST', '/api/staff/users/:id', async (req, res, { user, params }) => {
  needMod2(user);
  const target = q('SELECT * FROM users WHERE id=?').get(int(params.id));
  if (!target) fail(404, 'not_found');
  if (target.role !== 'user') fail(403, 'forbidden'); // لا أحد من المشرفين يتصرف بحساب إداري
  const b = await readJson(req);
  if (b.action === 'ban') { q('UPDATE users SET banned=1, ban_reason=? WHERE id=?').run(str(b.reason, 200), target.id); q('DELETE FROM sessions WHERE user_id=?').run(target.id); }
  else if (b.action === 'unban') q("UPDATE users SET banned=0, ban_reason='' WHERE id=?").run(target.id);
  else if (b.action === 'delete') await deleteUserCompletely(target.id);
  else fail(400, 'bad_action');
  audit(user, 'user_' + b.action, target.username);
  send(res, 200, { ok: true });
});
// ---- التحميل: بدون علامة (الملف الأصلي) أو مع علامة مجازية المتنقلة أعلى/أسفل (بدون لقطة نهاية)
const EXPORT_DIR = path.join(DATA_DIR, 'exports');
fs.mkdirSync(EXPORT_DIR, { recursive: true });
const WATERMARK = path.join(ROOT, 'assets', 'watermark.png');
const WM_FONT = path.join(ROOT, 'assets', 'DejaVuSans-Bold.ttf');
const jobs = new Map(); // key -> {status, file, error, progress}
const queue = [];
let running = 0;
const MAX_JOBS = Number(process.env.EXPORT_CONCURRENCY || 1);
function runNext() {
  if (running >= MAX_JOBS || !queue.length) return;
  const job = queue.shift(); running++;
  job.status = 'working';
  job.run().then(() => { job.status = 'done'; }).catch((e) => { job.status = 'error'; job.error = String(e.message || e).slice(0, 200); console.error('[export]', e); })
    .finally(() => { running--; runNext(); });
}
function ffmpeg(args, onProgress) {
  return new Promise((resolve, reject) => {
    const p = require('node:child_process').spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '';
    p.stderr.on('data', (d) => { err = (err + d).slice(-4000); const m = /time=(\d+):(\d+):(\d+\.\d+)/.exec(String(d)); if (m && onProgress) onProgress(+m[1] * 3600 + +m[2] * 60 + +m[3]); });
    p.on('error', reject);
    p.on('close', (code) => code === 0 ? resolve() : reject(new Error('ffmpeg_failed: ' + err.split('\n').slice(-3).join(' '))));
  });
}
function wmFilters(username, isVideo) {
  // الشعار يتنقل بين أعلى اليسار وأسفل اليمين كل 6 ثوانٍ (مثل تيك توك)، مع اسم الناشر
  const pos = isVideo ? 'lt(mod(t\\,12)\\,6)' : '1';
  const handle = '@' + String(username).replace(/[^a-z0-9_.]/gi, '');
  return [
    `[1:v][0:v]scale2ref=w=iw*0.24:h=ow/mdar[wm][base]`,
    `[base][wm]overlay=x='if(${pos}\\,W*0.04\\,W-w-W*0.04)':y='if(${pos}\\,H*0.05\\,H-h-H*0.10)'[v1]`,
    `[v1]drawtext=fontfile='${WM_FONT.replace(/'/g, '')}':text='${handle}':fontcolor=white@0.92:fontsize=h*0.022:shadowcolor=black@0.6:shadowx=2:shadowy=2:` +
      `x='if(${pos}\\,w*0.04+(w*0.24-tw)/2\\,w-w*0.04-(w*0.24+tw)/2)':y='if(${pos}\\,h*0.05+w*0.24*0.61+6\\,h-h*0.10+8)'[v]`,
  ].join(';');
}
route('POST', '/api/posts/:id/export', async (req, res, { user, params }) => {
  need(user);
  if (tooMany('exp:' + user.id, 20, 3600000)) fail(429, 'too_many_attempts');
  const p = q("SELECT * FROM posts WHERE id=? AND status='approved'").get(int(params.id));
  if (!p) fail(404, 'not_found');
  const b = await readJson(req);
  const mark = b.mark === true;
  const images = JSON.parse(p.images || '[]');
  const idx = Math.max(0, Math.min(images.length - 1, Number(b.index) || 0));
  const src = p.kind === 'reel' ? p.video_id : images[idx];
  if (!src) fail(400, 'nothing_to_download');
  const ext = path.extname(src);
  const nice = `majazia-${p.id}${p.kind === 'post' && images.length > 1 ? '-' + (idx + 1) : ''}`;
  if (!mark) return send(res, 200, { status: 'done', url: `/api/download/orig/${p.id}/${idx}`, name: nice + ext });
  noteAttempt('exp:' + user.id);
  const author = q('SELECT username FROM users WHERE id=?').get(p.user_id);
  const isVideo = p.kind === 'reel';
  const outName = `${p.id}-${idx}-wm${isVideo ? '.mp4' : '.jpg'}`;
  const outPath = path.join(EXPORT_DIR, outName);
  const key = outName;
  let job = jobs.get(key);
  if (!job && fs.existsSync(outPath)) job = { status: 'done' };
  if (!job || job.status === 'error') {
    job = { status: 'queued', progress: 0, duration: p.duration || 0 };
    job.run = async () => {
      const tmp = outPath + '.tmp' + (isVideo ? '.mp4' : '.jpg');
      const plainSrc = outPath + '.src' + path.extname(src);
      await decryptToFile(path.join(MEDIA_DIR, src), plainSrc); // نسخة مؤقتة تُحذف فوراً بعد المعالجة
      const args = ['-y', '-hide_banner', '-i', plainSrc, '-i', WATERMARK, '-filter_complex', wmFilters(author ? author.username : 'majazia', isVideo), '-map', '[v]'];
      if (isVideo) args.push('-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '22', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', tmp);
      else args.push('-frames:v', '1', '-q:v', '2', tmp);
      try { await ffmpeg(args, (sec) => { job.progress = job.duration ? Math.min(99, Math.round(sec / job.duration * 100)) : 0; }); }
      catch (e) { await fsp.rm(plainSrc, { force: true }); await fsp.rm(tmp, { force: true }); throw e; }
      try { await encryptFile(tmp, outPath); } finally { await fsp.rm(tmp, { force: true }); await fsp.rm(plainSrc, { force: true }); }
    };
    jobs.set(key, job); queue.push(job); runNext();
  }
  send(res, 200, { status: job.status, progress: job.progress || 0, job: key, url: job.status === 'done' ? `/api/download/wm/${key}` : null, name: nice + '-majazia' + (isVideo ? '.mp4' : '.jpg') });
});
route('GET', '/api/export/:key', (req, res, { user, params }) => {
  need(user);
  const key = params.key;
  if (!/^\d+-\d+-wm\.(mp4|jpg)$/.test(key)) fail(404, 'not_found');
  const job = jobs.get(key) || (fs.existsSync(path.join(EXPORT_DIR, key)) ? { status: 'done' } : null);
  if (!job) fail(404, 'not_found');
  send(res, 200, { status: job.status, progress: job.progress || 0, url: job.status === 'done' ? `/api/download/wm/${key}` : null, error: job.status === 'error' ? 'export_failed' : undefined });
});
route('GET', '/api/download/orig/:id/:idx', (req, res, { user, params }) => {
  need(user);
  const p = q("SELECT * FROM posts WHERE id=? AND status='approved'").get(int(params.id));
  if (!p) fail(404, 'not_found');
  const images = JSON.parse(p.images || '[]');
  const src = p.kind === 'reel' ? p.video_id : images[int(params.idx)];
  if (!src) fail(404, 'not_found');
  const f = q('SELECT mime FROM files WHERE id=?').get(src);
  serveMedia(req, res, path.join(MEDIA_DIR, src), f ? f.mime : 'application/octet-stream', { download: `majazia-${p.id}${path.extname(src)}` });
});
route('GET', '/api/download/wm/:key', (req, res, { user, params }) => {
  need(user);
  const key = params.key;
  if (!/^\d+-\d+-wm\.(mp4|jpg)$/.test(key)) fail(404, 'not_found');
  const pid = int(key.split('-')[0]);
  if (!q("SELECT 1 FROM posts WHERE id=? AND status='approved'").get(pid)) fail(404, 'not_found');
  serveMedia(req, res, path.join(EXPORT_DIR, key), key.endsWith('.mp4') ? 'video/mp4' : 'image/jpeg', { download: `majazia-${pid}-majazia${path.extname(key)}` });
});



// ================================================================ قسم المؤسس السري
// رابط سري + دخول خاص (المستخدم + كلمة المرور + رقم أمان يتغيّر مع كل دخول وكل 3 أيام).
// 3 محاولات خاطئة = حظر دائم لجهاز المحاول.
let CONTROL_PATH = String(process.env.CONTROL_PATH || getSetting('control_path', '')).replace(/[^a-zA-Z0-9_-]/g, '');
if (CONTROL_PATH.length < 12) CONTROL_PATH = 'cp-' + crypto.randomBytes(12).toString('hex');
setSetting('control_path', CONTROL_PATH);
const CP = '/' + CONTROL_PATH;
const CONTROL_UI = path.join(ROOT, 'control-ui');
const CONTROL_SESSION_HOURS = 12;
const CONTROL_KEY_DAYS = 3;
const CONTROL_MAX_FAILS = 3;
let SETUP_TOKEN = getSetting('setup_token', '');
if (!founderExists() && !SETUP_TOKEN) { SETUP_TOKEN = crypto.randomBytes(16).toString('hex'); setSetting('setup_token', SETUP_TOKEN); }

function makeControlKey() {
  const A = '23456789';
  return Array.from(crypto.randomBytes(9), (b) => A[b % A.length]).join('').replace(/(\d{3})(\d{3})(\d{3})/, '$1-$2-$3');
}
function rotateControlKey() {
  const k = makeControlKey();
  setSetting('control_key_hash', hashSecret(k.replace(/\D/g, '')));
  setSetting('control_key_at', String(now()));
  return k;
}
function controlCookie(token, maxAge) {
  return `mjz_c=${token}; Path=${CP}; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${process.env.SECURE_COOKIE === '1' ? '; Secure' : ''}`;
}
function controlUser(req) {
  const tok = parseCookies(req).mjz_c;
  if (!tok || tok.length < 20) return null;
  const s = q('SELECT user_id, created_at FROM control_sessions WHERE token_hash=?').get(sha(tok));
  if (!s) return null;
  if (now() - s.created_at > CONTROL_SESSION_HOURS * 3600000) { q('DELETE FROM control_sessions WHERE token_hash=?').run(sha(tok)); return null; }
  const u = q('SELECT * FROM users WHERE id=?').get(s.user_id);
  return u && u.role === 'founder' && !u.banned ? u : null;
}
const controlFails = new Map();
function controlFailed(req, username) {
  const v = visitorOf(req);
  // العدّ محفوظ في قاعدة البيانات (لا يُصفَّر بإعادة تشغيل الخادم)
  const n = q("SELECT COUNT(*) n FROM security_events WHERE visitor=? AND kind='control_login_failed' AND created_at>?").get(v, now() - 86400000).n + 1;
  controlFails.set(v, n);
  securityEvent(req, 'control_login_failed', 'high', `محاولة دخول خاطئة إلى لوحة المؤسس (${n}/${CONTROL_MAX_FAILS})` + (username ? ` باسم: ${String(username).replace(/[^\w.@-]/g, '').slice(0, 30)}` : ''));
  if (n >= CONTROL_MAX_FAILS) {
    q('INSERT OR REPLACE INTO blocked_visitors(visitor,reason,until,created_at) VALUES(?,?,?,?)').run(v, 'control_login', -1, now());
    securityEvent(req, 'control_blocked', 'high', `حظر دائم بعد ${n} محاولات خاطئة على لوحة المؤسس`);
    controlFails.delete(v);
  }
}

const { route: croute, dispatch: cdispatch } = createRouter();

croute('POST', '/api/login', async (req, res) => {
  const b = await readJson(req);
  if (tooMany('cglobal', 30, 3600000)) fail(429, 'too_many_attempts'); // حماية إضافية من الهجوم الموزع
  noteAttempt('cglobal');
  const username = str(b.username, 20).toLowerCase();
  const u = q("SELECT * FROM users WHERE username=? AND role='founder'").get(username);
  const keyOk = checkSecret(String(b.key || '').replace(/\D/g, ''), getSetting('control_key_hash', 'x:x'));
  const ok = u && !u.banned && checkSecret(String(b.password || ''), u.pass_hash) && keyOk;
  if (!ok) { await sleep(800 + Math.random() * 1200); controlFailed(req, username); fail(401, 'bad_credentials'); }
  controlFails.delete(visitorOf(req));
  q("UPDATE security_events SET kind='control_login_failed_ok', status='handled' WHERE visitor=? AND kind='control_login_failed'").run(visitorOf(req)); // دخول ناجح يصفّر العدّ
  const token = crypto.randomBytes(32).toString('hex');
  q('DELETE FROM control_sessions WHERE created_at < ?').run(now() - CONTROL_SESSION_HOURS * 3600000);
  q('INSERT INTO control_sessions(token_hash,user_id,created_at) VALUES(?,?,?)').run(sha(token), u.id, now());
  const next = rotateControlKey(); // رقم أمان جديد لكل دخول
  audit(u, 'control_login', '');
  send(res, 200, { ok: true, next_key: next }, { 'Set-Cookie': controlCookie(token, CONTROL_SESSION_HOURS * 3600) });
});
croute('POST', '/api/logout', (req, res) => {
  const tok = parseCookies(req).mjz_c;
  if (tok) q('DELETE FROM control_sessions WHERE token_hash=?').run(sha(tok));
  send(res, 200, { ok: true }, { 'Set-Cookie': controlCookie('', 0) });
});
croute('POST', '/api/setup', async (req, res) => {
  if (founderExists()) fail(404, 'not_found');
  const b = await readJson(req);
  const tok = Buffer.from(String(b.token || '')); const want = Buffer.from(SETUP_TOKEN);
  if (!SETUP_TOKEN || tok.length !== want.length || !crypto.timingSafeEqual(tok, want)) { controlFailed(req, 'setup'); fail(403, 'bad_token'); }
  const name = str(b.name, 40, { required: true });
  const username = str(b.username, 20, { required: true }).toLowerCase();
  const password = String(b.password || '');
  if (!/^[a-z0-9_.]{3,20}$/.test(username)) fail(400, 'bad_username');
  if (password.length < 10) fail(400, 'weak_password');
  if (q('SELECT 1 FROM users WHERE username=?').get(username)) fail(409, 'username_taken');
  const siteKey = makeSecurityKey(); const t = now();
  q("INSERT INTO users(name,username,pass_hash,key_hash,role,verified,publish_until,inactivity_days,last_active,created_at) VALUES(?,?,?,?,'founder','gold',-1,36500,?,?)")
    .run(name, username, hashSecret(password), hashSecret(normKey(siteKey)), t, t);
  setSetting('setup_token', ''); SETUP_TOKEN = '';
  const controlKey = rotateControlKey();
  send(res, 200, { site_key: siteKey, control_key: controlKey });
});
// ---- بعد الدخول
croute('GET', '/api/me', (req, res, { user }) => {
  // رقم الأمان يتغيّر تلقائياً كل 3 أيام — يظهر الرقم الجديد هنا مرة واحدة
  let rotated = null;
  if (now() - Number(getSetting('control_key_at', '0')) > CONTROL_KEY_DAYS * 86400000) rotated = rotateControlKey();
  send(res, 200, { name: user.name, username: user.username, rotated_key: rotated,
    key_age_hours: Math.floor((now() - Number(getSetting('control_key_at', '0'))) / 3600000), key_days: CONTROL_KEY_DAYS });
});
croute('POST', '/api/rotate-key', (req, res, { user }) => { audit(user, 'control_rotate_key', ''); send(res, 200, { next_key: rotateControlKey() }); });
croute('POST', '/api/emergency', async (req, res, { user }) => {
  const b = await readJson(req);
  if (b.action === 'logout_all') { q('DELETE FROM sessions').run(); }
  else if (b.action === 'logout_staff') { q("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE role IN ('mod1','mod2','founder'))").run(); }
  else if (b.action === 'lockdown') { for (const k of ['maintenance', 'freeze_publishing', 'staff_locked']) setSetting(k, '1'); setSetting('registration_open', '0'); q('DELETE FROM sessions').run(); }
  else if (b.action === 'reopen') { for (const k of ['maintenance', 'freeze_publishing', 'staff_locked']) setSetting(k, '0'); setSetting('registration_open', '1'); }
  else fail(400, 'bad_action');
  audit(user, 'emergency_' + b.action, '');
  send(res, 200, { ok: true });
});
croute('GET', '/api/publish-requests', (req, res) => {
  const rows = q(`SELECT r.*, u.name, u.username, u.verified, u.created_at joined,
      (SELECT COUNT(*) FROM reports WHERE target_type='user' AND target_id=u.id) reports_on_user
    FROM publish_requests r JOIN users u ON u.id=r.user_id WHERE r.status='pending' ORDER BY r.created_at`).all();
  send(res, 200, { requests: rows });
});
croute('POST', '/api/publish-requests/:id', async (req, res, { user, params }) => {
  const r = q('SELECT * FROM publish_requests WHERE id=?').get(int(params.id));
  if (!r) fail(404, 'not_found');
  const b = await readJson(req);
  if (b.action === 'grant') {
    const days = Number(b.days);
    if (![1, 2, 3, 4, 7, 30, 0].includes(days)) fail(400, 'bad_days');
    q('UPDATE users SET publish_until=? WHERE id=?').run(days === 0 ? -1 : now() + days * 86400000, r.user_id);
    q("UPDATE publish_requests SET status='granted' WHERE id=?").run(r.id);
  } else if (b.action === 'dismiss') q("UPDATE publish_requests SET status='dismissed' WHERE id=?").run(r.id);
  else fail(400, 'bad_action');
  audit(user, 'publish_request_' + b.action, r.user_id);
  send(res, 200, { ok: true });
});
croute('GET', '/api/room', (req, res, { query }) => {
  const since = Number(query.get('since') || 0) || 0;
  const rows = q(`SELECT s.*, u.name, u.username, u.role FROM staff_messages s LEFT JOIN users u ON u.id=s.user_id WHERE s.created_at>? ORDER BY s.created_at DESC LIMIT 200`).all(since);
  send(res, 200, { messages: rows.reverse().map((m) => ({ id: m.id, body: m.body, at: m.created_at, author: m.username ? { name: m.name, username: m.username, role: m.role } : null })) });
});
croute('POST', '/api/room', async (req, res, { user }) => {
  const b = await readJson(req);
  q('INSERT INTO staff_messages(user_id,body,created_at) VALUES(?,?,?)').run(user.id, str(b.body, 1500, { required: true, multiline: true }), now());
  send(res, 200, { ok: true });
});
croute('POST', '/api/posts/:id/delete', async (req, res, { user, params }) => {
  await deletePostCompletely(int(params.id)); audit(user, 'delete_post', params.id); send(res, 200, { ok: true });
});
// ================================================================ لوحة المؤسس (قسم سري منفصل بجلسة ودخول خاص)
croute('GET', '/api/stats', (req, res, { user }) => {
  const c = (sql, ...a) => q(sql).get(...a).n;
  send(res, 200, {
    role: 'founder',
    preapproved: c("SELECT COUNT(*) n FROM posts WHERE status='pending' AND pre_approved_by IS NOT NULL"),
    requests: c("SELECT COUNT(*) n FROM publish_requests WHERE status='pending'"),
    staff: c("SELECT COUNT(*) n FROM users WHERE role IN ('mod1','mod2')"),
    users: c('SELECT COUNT(*) n FROM users'),
    banned: c('SELECT COUNT(*) n FROM users WHERE banned=1'),
    publishers: c('SELECT COUNT(*) n FROM users WHERE publish_until=-1 OR publish_until>?', now()),
    reels: c("SELECT COUNT(*) n FROM posts WHERE kind='reel' AND status='approved'"),
    posts: c("SELECT COUNT(*) n FROM posts WHERE kind='post' AND status='approved'"),
    pending: c("SELECT COUNT(*) n FROM posts WHERE status='pending'"),
    reports: c("SELECT COUNT(*) n FROM reports WHERE status='open'"),
    verify: c("SELECT COUNT(*) n FROM verify_requests WHERE status='pending'"),
    support_unread: c('SELECT COUNT(*) n FROM messages WHERE to_id=0 AND is_read=0'),
    security_new: c("SELECT COUNT(*) n FROM security_events WHERE status='new'"),
    security_high: c("SELECT COUNT(*) n FROM security_events WHERE status='new' AND severity='high'"),
    active_24h: c('SELECT COUNT(*) n FROM users WHERE last_active>?', now() - 86400000),
    settings: {
      approval_required: flag('approval_required'), registration_open: flag('registration_open'),
      founder_final_approval: flag('founder_final_approval'), maintenance: flag('maintenance'),
      freeze_publishing: flag('freeze_publishing'), staff_locked: flag('staff_locked'),
      content_ttl_days: Number(getSetting('content_ttl_days', '0')) || 0,
    },
    media_key_env: MEDIA_KEY.fromEnv,
    control_key_age_days: Math.floor((now() - Number(getSetting('control_key_at', '0'))) / 86400000),
    deepl: !!DEEPL_KEY,
  });
});
croute('GET', '/api/pending', (req, res, { user }) => {
  const rows = q("SELECT * FROM posts WHERE status='pending' ORDER BY (pre_approved_by IS NULL), created_at ASC LIMIT 100").all();
  send(res, 200, { posts: rows.map((p) => ({ ...postRow(p, user), subtitles: JSON.parse(p.subtitles || '[]'),
    pre_approved_by: p.pre_approved_by ? (q('SELECT username FROM users WHERE id=?').get(p.pre_approved_by) || {}).username || null : null })) });
});
croute('POST', '/api/posts/:id/review', async (req, res, { user, params }) => {
  const b = await readJson(req);
  const p = q('SELECT * FROM posts WHERE id=?').get(int(params.id));
  if (!p) fail(404, 'not_found');
  guardOwner(user, p.user_id);
  if (b.action === 'approve') { q("UPDATE posts SET status='approved', approved_at=?, reject_reason='' WHERE id=?").run(now(), p.id); audit(user, 'approve_post', p.id); }
  else if (b.action === 'reject') { q("UPDATE posts SET status='rejected', reject_reason=? WHERE id=?").run(str(b.reason, 300), p.id); await purgePostMedia(p.id); audit(user, 'reject_post', p.id); }
  else fail(400, 'bad_action');
  send(res, 200, { ok: true });
});
croute('GET', '/api/posts', (req, res, { user, query }) => {
  const s = str(query.get('q') || '', 80);
  const like = '%' + s + '%';
  const rows = q(`SELECT p.* FROM posts p JOIN users u ON u.id=p.user_id WHERE p.status='approved' AND (?='' OR p.title LIKE ? OR p.body LIKE ? OR u.username LIKE ?) ORDER BY p.created_at DESC LIMIT 100`).all(s, like, like, like);
  send(res, 200, { posts: rows.map((p) => postRow(p, user)) });
});
croute('GET', '/api/users', (req, res, { user, query }) => {
  const s = str(query.get('q') || '', 40);
  const filter = query.get('filter') || 'all';
  const where = ['(?=\'\' OR username LIKE ? OR name LIKE ?)'];
  if (filter === 'banned') where.push('banned=1');
  if (filter === 'publishers') where.push('(publish_until=-1 OR publish_until>' + now() + ')');
  if (filter === 'verified') where.push("verified!='none'");
  if (filter === 'staff') where.push("role!='user'");
  const rows = q(`SELECT * FROM users WHERE ${where.join(' AND ')} ORDER BY created_at DESC LIMIT 200`).all(s, '%' + s + '%', '%' + s + '%');
  send(res, 200, { users: rows.map((u) => ({
    id: u.id, name: u.name, username: u.username, role: u.role, verified: u.verified, publish_until: u.publish_until,
    banned: !!u.banned, ban_reason: u.ban_reason, last_active: u.last_active, created_at: u.created_at, inactivity_days: u.inactivity_days,
    posts: q("SELECT COUNT(*) n FROM posts WHERE user_id=?").get(u.id).n,
    reports: q("SELECT COUNT(*) n FROM reports WHERE target_type='user' AND target_id=? AND status='open'").get(u.id).n,
  })) });
});
croute('POST', '/api/users/:id', async (req, res, { user, params }) => {
  const target = q('SELECT * FROM users WHERE id=?').get(int(params.id));
  if (!target) fail(404, 'not_found');
  if (target.role === 'founder') fail(403, 'forbidden');
  const b = await readJson(req);
  switch (b.action) {
    case 'ban':
      q('UPDATE users SET banned=1, ban_reason=? WHERE id=?').run(str(b.reason, 200), target.id);
      q('DELETE FROM sessions WHERE user_id=?').run(target.id); break;
    case 'unban': q("UPDATE users SET banned=0, ban_reason='' WHERE id=?").run(target.id); break;
    case 'delete': await deleteUserCompletely(target.id); break;
    case 'grant_publish': {
          const days = Number(b.days);
      if (!Number.isFinite(days)) fail(400, 'bad_days'); // NaN كان يُكتب في عمود NOT NULL → 500
      const until = days === 0 ? -1 : now() + Math.max(1, Math.min(3650, days)) * 86400000;
      q('UPDATE users SET publish_until=? WHERE id=?').run(until, target.id); break;
    }
    case 'revoke_publish': q('UPDATE users SET publish_until=0 WHERE id=?').run(target.id); break;
    case 'verify':
          if (!['none', 'blue', 'gold'].includes(b.level)) fail(400, 'bad_level');
      q('UPDATE users SET verified=? WHERE id=?').run(b.level, target.id);
      q("UPDATE verify_requests SET status='done' WHERE user_id=? AND status='pending'").run(target.id); break;
    case 'set_role':
      if (!['user', 'mod1', 'mod2'].includes(b.role)) fail(400, 'bad_role');
      q('UPDATE users SET role=? WHERE id=?').run(b.role, target.id);
      q('DELETE FROM sessions WHERE user_id=?').run(target.id); // يعيد الدخول بالصلاحية الجديدة
      break;
    default: fail(400, 'bad_action');
  }
  audit(user, 'user_' + b.action, target.username);
  send(res, 200, { ok: true });
});
croute('GET', '/api/reports', (req, res, { user, query }) => {
  const status = ['open', 'resolved', 'dismissed'].includes(query.get('status')) ? query.get('status') : 'open';
  const rows = q('SELECT * FROM reports WHERE status=? ORDER BY created_at DESC LIMIT 200').all(status);
  send(res, 200, { reports: rows.map((r) => {
    const reporter = r.reporter_id ? q('SELECT username FROM users WHERE id=?').get(r.reporter_id) : null;
    let target = null;
    if (r.target_type === 'post') { const p = q('SELECT * FROM posts WHERE id=?').get(r.target_id); target = p ? postRow(p, user) : null; }
    if (r.target_type === 'comment') { const c = q('SELECT c.*, u.username FROM comments c JOIN users u ON u.id=c.user_id WHERE c.id=?').get(r.target_id); target = c ? { id: c.id, body: c.body, username: c.username, user_id: c.user_id, post_id: c.post_id } : null; }
    if (r.target_type === 'user') { const u = q('SELECT * FROM users WHERE id=?').get(r.target_id); target = u ? publicUser(u) : null; }
    const same = q("SELECT COUNT(*) n FROM reports WHERE target_type=? AND target_id=? AND status='open'").get(r.target_type, r.target_id).n;
    return { id: r.id, target_type: r.target_type, target_id: r.target_id, reason: r.reason, details: r.details, status: r.status, created_at: r.created_at, reporter: reporter ? reporter.username : null, target, same_count: same };
  }) });
});
croute('POST', '/api/reports/:id', async (req, res, { user, params }) => {
  const r = q('SELECT * FROM reports WHERE id=?').get(int(params.id));
  if (!r) fail(404, 'not_found');
  const b = await readJson(req);
  if (b.action === 'remove_content') {
    if (r.target_type === 'post') { const tp = q('SELECT user_id FROM posts WHERE id=?').get(r.target_id); if (tp) guardOwner(user, tp.user_id); }
    if (r.target_type === 'comment') { const tc = q('SELECT user_id FROM comments WHERE id=?').get(r.target_id); if (tc) guardOwner(user, tc.user_id); }
    if (r.target_type === 'post') await deletePostCompletely(r.target_id);
    else if (r.target_type === 'comment') q('DELETE FROM comments WHERE id=?').run(r.target_id);
    q("UPDATE reports SET status='resolved', handled_by=? WHERE target_type=? AND target_id=? AND status='open'").run(user.id, r.target_type, r.target_id);
  } else if (b.action === 'resolve') q("UPDATE reports SET status='resolved', handled_by=? WHERE id=?").run(user.id, r.id);
  else if (b.action === 'dismiss') q("UPDATE reports SET status='dismissed', handled_by=? WHERE id=?").run(user.id, r.id);
  else fail(400, 'bad_action');
  audit(user, 'report_' + b.action, r.id);
  send(res, 200, { ok: true });
});
croute('GET', '/api/verify', (req, res, { user }) => {
  const rows = q("SELECT v.*, u.username, u.name, u.verified FROM verify_requests v JOIN users u ON u.id=v.user_id WHERE v.status='pending' ORDER BY v.created_at").all();
  send(res, 200, { requests: rows });
});
croute('POST', '/api/verify/:id/dismiss', (req, res, { user, params }) => {
  q("UPDATE verify_requests SET status='dismissed' WHERE id=?").run(int(params.id));
  send(res, 200, { ok: true });
});
// أكواد النشر — للمؤسس فقط
croute('GET', '/api/codes', (req, res, { user }) => {
  const rows = q('SELECT * FROM codes ORDER BY created_at DESC LIMIT 200').all();
  send(res, 200, { codes: rows.map((c) => ({ ...c, users: q('SELECT u.username FROM code_uses cu JOIN users u ON u.id=cu.user_id WHERE cu.code=?').all(c.code).map((x) => x.username) })) });
});
croute('POST', '/api/codes', async (req, res, { user }) => {
  const b = await readJson(req);
  const days = Number(b.grant_days);
  if (!Number.isInteger(days) || days < 0 || days > 3650) fail(400, 'bad_days');
  const maxUses = Math.max(1, Math.min(1000, Number(b.max_uses) || 1));
  const code = makeCode();
  q('INSERT INTO codes(code,grant_days,max_uses,note,created_by,created_at) VALUES(?,?,?,?,?,?)').run(code, days, maxUses, str(b.note, 100), user.id, now());
  audit(user, 'create_code', code);
  send(res, 200, { code });
});
croute('POST', '/api/codes/:code/toggle', (req, res, { user, params }) => {
  q('UPDATE codes SET active=1-active WHERE code=?').run(params.code);
  send(res, 200, { ok: true });
});
croute('POST', '/api/settings', async (req, res, { user }) => {
  const b = await readJson(req);
  if (typeof b.approval_required === 'boolean') setSetting('approval_required', b.approval_required ? '1' : '0');
  if (typeof b.registration_open === 'boolean') setSetting('registration_open', b.registration_open ? '1' : '0');
  for (const k of ['founder_final_approval', 'maintenance', 'freeze_publishing', 'staff_locked']) if (typeof b[k] === 'boolean') setSetting(k, b[k] ? '1' : '0');
  if (b.content_ttl_days !== undefined) { const d = Number(b.content_ttl_days); if (![0, 7, 30, 90, 180, 365].includes(d)) fail(400, 'bad_days'); setSetting('content_ttl_days', String(d)); }
  audit(user, 'settings', JSON.stringify(b));
  send(res, 200, { ok: true });
});
// صندوق رسائل الإدارة
croute('GET', '/api/inbox', (req, res, { user }) => {
  const rows = q(`SELECT u.id, u.username, u.name, u.verified, MAX(m.created_at) last,
      SUM(CASE WHEN m.to_id=0 AND m.is_read=0 THEN 1 ELSE 0 END) unread
    FROM messages m JOIN users u ON u.id = CASE WHEN m.to_id=0 THEN m.from_id ELSE m.to_id END
    WHERE m.to_id=0 OR m.via_support=1
    GROUP BY u.id ORDER BY last DESC LIMIT 100`).all();
  send(res, 200, { threads: rows });
});
croute('GET', '/api/inbox/:uid', (req, res, { user, params }) => {
  const uid = int(params.uid);
  const rows = q('SELECT m.*, u.username staff FROM messages m LEFT JOIN users u ON u.id=m.from_id WHERE (m.from_id=? AND m.to_id=0) OR (m.to_id=? AND m.via_support=1) ORDER BY m.created_at DESC LIMIT 200').all(uid, uid);
  q('UPDATE messages SET is_read=1 WHERE from_id=? AND to_id=0').run(uid);
  send(res, 200, { messages: rows.reverse().map((m) => ({ id: m.id, from_user: !m.via_support, by: m.via_support ? m.staff : null, body: m.body, at: m.created_at })) });
});
croute('POST', '/api/inbox/:uid', async (req, res, { user, params }) => {
  const uid = int(params.uid);
  if (!q('SELECT 1 FROM users WHERE id=?').get(uid)) fail(404, 'not_found');
  const b = await readJson(req);
  const body = str(b.body, 1000, { required: true, multiline: true });
  // تُحفظ كرسالة من "مجازية" إلى المستخدم (from = مشرف، تظهر عند المستخدم ضمن محادثة مجازية)
  q('INSERT INTO messages(from_id,to_id,body,via_support,created_at) VALUES(?,?,?,1,?)').run(user.id, uid, body, now());
  send(res, 200, { ok: true });
});
croute('GET', '/api/audit', (req, res, { user }) => {
  const rows = q('SELECT a.*, u.username FROM audit a LEFT JOIN users u ON u.id=a.admin_id ORDER BY a.created_at DESC LIMIT 200').all();
  send(res, 200, { audit: rows });
});
croute('POST', '/api/comments/:id/delete', (req, res, { user, params }) => {
  const tc = q('SELECT user_id FROM comments WHERE id=?').get(int(params.id)); if (tc) guardOwner(user, tc.user_id);
  q('DELETE FROM comments WHERE id=?').run(int(params.id));
  q("UPDATE reports SET status='resolved', handled_by=? WHERE target_type='comment' AND target_id=? AND status='open'").run(user.id, int(params.id));
  audit(user, 'delete_comment', params.id);
  send(res, 200, { ok: true });
});

// ---- الأمان (لوحة المؤسس)
croute('GET', '/api/security', (req, res, { user, query }) => {
  const status = query.get('status') === 'handled' ? 'handled' : 'new';
  const rows = q('SELECT * FROM security_events WHERE status=? ORDER BY created_at DESC LIMIT 300').all(status);
  // تجميع حسب الزائر لمعرفة الأخطر
  const t = now();
  const offenders = q(`SELECT visitor, COUNT(*) n, MAX(created_at) last,
      SUM(CASE severity WHEN 'high' THEN 6 WHEN 'medium' THEN 3 WHEN 'info' THEN 0 ELSE 1 END) score,
      GROUP_CONCAT(DISTINCT username) usernames, GROUP_CONCAT(DISTINCT kind) kinds
    FROM security_events WHERE created_at>? GROUP BY visitor ORDER BY score DESC LIMIT 30`).all(t - 7 * 86400000);
  const blocked = q('SELECT * FROM blocked_visitors ORDER BY created_at DESC').all().filter((b) => b.until === -1 || b.until > t);
  send(res, 200, { events: rows, offenders: offenders.map((o) => ({ ...o, usernames: (o.usernames || '').split(',').filter(Boolean), kinds: (o.kinds || '').split(','), blocked: blocked.some((b) => b.visitor === o.visitor) })), blocked });
});
croute('POST', '/api/security/handle', async (req, res, { user }) => {
  const b = await readJson(req);
  if (b.all === true) q("UPDATE security_events SET status='handled' WHERE status='new'").run();
  else if (b.visitor) q("UPDATE security_events SET status='handled' WHERE visitor=?").run(String(b.visitor));
  else q("UPDATE security_events SET status='handled' WHERE id=?").run(int(b.id));
  send(res, 200, { ok: true });
});
croute('POST', '/api/security/block', async (req, res, { user }) => {
  const b = await readJson(req);
  const visitor = str(b.visitor, 32, { required: true });
  if (visitor === visitorOf(req)) fail(400, 'cannot_block_self');
  if (b.unblock === true) { q('DELETE FROM blocked_visitors WHERE visitor=?').run(visitor); audit(user, 'unblock_visitor', visitor); return send(res, 200, { ok: true }); }
  const hours = Number(b.hours);
  const until = hours === 0 ? -1 : now() + Math.max(1, Math.min(8760, hours || 24)) * 3600000;
  q('INSERT OR REPLACE INTO blocked_visitors(visitor,reason,until,created_at) VALUES(?,?,?,?)').run(visitor, str(b.reason, 100) || 'manual', until, now());
  q("UPDATE security_events SET status='handled' WHERE visitor=?").run(visitor);
  audit(user, 'block_visitor', visitor);
  send(res, 200, { ok: true });
});


const CONTROL_STATIC = { '/panel.js': ['panel.js', MIME['.js']], '/setup.js': ['setup.js', MIME['.js']] };
async function handleControl(req, res, url) {
  const sub = url.pathname.slice(CP.length) || '/';
  // الأجهزة المحظورة (ومنها من أخطأ 3 مرات) لا تصل للوحة أبداً
  if (isBlocked(visitorOf(req))) return serveBlocked(req, res);
  const cuser = controlUser(req);
  const noindex = { 'X-Robots-Tag': 'noindex, nofollow' };
  if (sub === '/' || sub === '') {
    return send(res, 200, fs.readFileSync(path.join(CONTROL_UI, 'index.html'), 'utf8').replace('{{CP}}', CP), { 'Content-Type': MIME['.html'], ...noindex });
  }
  if (sub === '/setup') {
    if (founderExists()) return send(res, 404, 'Not found');
    return send(res, 200, fs.readFileSync(path.join(CONTROL_UI, 'setup.html'), 'utf8').replace('{{CP}}', CP), { 'Content-Type': MIME['.html'], ...noindex });
  }
  if (CONTROL_STATIC[sub]) {
    const [f, mime] = CONTROL_STATIC[sub];
    if (f === 'panel.js' || (f === 'setup.js' && !founderExists())) return serveFile(req, res, path.join(CONTROL_UI, f), mime, { cache: 'no-store' });
    return send(res, 404, 'Not found');
  }
  if (sub.startsWith('/api/')) {
    if (req.method !== 'GET' && req.headers['x-majazia'] !== '1') fail(403, 'csrf');
    const open = ['/api/login', '/api/setup', '/api/logout'].includes(sub);
    if (!open && !cuser) fail(401, 'login_required');
    if (await cdispatch(req, res, sub, { user: cuser, query: url.searchParams })) return;
    fail(404, 'not_found');
  }
  return send(res, 404, 'Not found');
}

// ---------------------------------------------------------------- الخادم
const MAINT_OPEN = new Set(['/api/config', '/api/auth/login', '/api/auth/logout']);
const server = http.createServer(async (req, res) => {
  try {
    const visitor = visitorOf(req);
    const user = currentUser(req);
    req._user = user;
    // الإدارة لا تُحظر أبداً بالخطأ (مثلاً إذا شارك المهاجم نفس شبكة الإنترنت)
    if (!isStaff(user) && isBlocked(visitor)) return serveBlocked(req, res);
    const url = new URL(req.url, 'http://x');
    if (url.pathname === CP || url.pathname.startsWith(CP + '/')) return await handleControl(req, res, url);
    if (scanRequest(req, url.pathname, req.url)) return serveDecoy(req, res);
    const pathname = decodeURIComponent(url.pathname);
    if (user && user.banned && pathname.startsWith('/api/') && !pathname.startsWith('/api/auth/') && pathname !== '/api/config') fail(403, 'banned');
    // لا توجد أي لوحة إدارة في هذا الخادم — من يبحث عنها يقع في الفخ
    // مشرف والغرفة مقفلة من المؤسس: رفض هادئ بدون تنبيه أمني
    if (pathname.startsWith('/api/staff') && user && ['mod1', 'mod2'].includes(user.role) && !user.banned && flag('staff_locked')) fail(403, 'staff_locked');
    if (pathname.startsWith('/api/admin') || pathname.startsWith('/api/control') || (pathname.startsWith('/api/staff') && !isStaff(user))) {
      securityEvent(req, 'admin_api_denied', user ? 'high' : 'medium', user ? `الحساب @${user.username} حاول الوصول إلى أوامر الإدارة` : 'زائر حاول الوصول إلى أوامر الإدارة');
      return serveDecoy(req, res);
    }
    // وضع الصيانة (من لوحة الطوارئ): الموقع مغلق للجميع إلا الإدارة
    if (flag('maintenance') && !isStaff(user) && pathname.startsWith('/api/') && !MAINT_OPEN.has(pathname)) fail(503, 'maintenance');

    if (pathname.startsWith('/api/')) {
      // حماية CSRF: كل طلبات التعديل يجب أن تحمل الترويسة الخاصة
      if (req.method !== 'GET' && req.method !== 'HEAD' && req.headers['x-majazia'] !== '1') fail(403, 'csrf');
      if (await dispatch(req, res, pathname, { user, query: url.searchParams })) return;
      noteNotFound(req);
      fail(404, 'not_found');
    }

    if (pathname.startsWith('/media/')) {
      const id = pathname.slice(7);
      if (!/^[a-f0-9]{32}\.(mp4|mov|webm|jpg|png|webp|gif)$/.test(id)) return send(res, 404, 'Not found');
      const f = q('SELECT mime FROM files WHERE id=?').get(id);
      if (!f) return send(res, 404, 'Not found');
      return serveMedia(req, res, path.join(MEDIA_DIR, id), f.mime, { cache: 'private, max-age=86400' });
    }

    // واجهة غرفة المشرفين تُرسل للمشرفين فقط
    if (pathname === '/staff.js') {
      if (isStaff(user)) return serveFile(req, res, path.join(PUBLIC_DIR, 'staff.js'), MIME['.js'], { cache: 'no-store' });
      securityEvent(req, 'admin_file_probe', 'medium', 'محاولة تحميل واجهة غرفة المشرفين بدون صلاحية');
      return send(res, 404, 'Not found');
    }

    // ملفات الواجهة
    const safe = path.normalize(pathname).replace(/^([/\\])+/, '');
    const file = path.join(PUBLIC_DIR, safe);
    if (file.startsWith(PUBLIC_DIR) && safe && fs.existsSync(file) && fs.statSync(file).isFile()) {
      return serveFile(req, res, file, MIME[path.extname(file)] || 'application/octet-stream', { cache: 'no-cache' });
    }
    if (path.extname(pathname)) { noteNotFound(req); return send(res, 404, 'Not found'); }
    // تطبيق الصفحة الواحدة
    return serveFile(req, res, path.join(PUBLIC_DIR, 'index.html'), MIME['.html'], { cache: 'no-cache' });
  } catch (e) {
    if (e instanceof HttpError) {
      if (e.status === 429) securityEvent(req, 'rate_limited', 'low', 'تجاوز الحد المسموح من المحاولات');
      else if (e.code === 'csrf') securityEvent(req, 'csrf_attempt', 'medium', 'طلب تعديل من خارج الموقع (بدون ترويسة الحماية)');
      else if (e.code === 'bad_file_type') securityEvent(req, 'bad_upload', 'medium', 'رفع ملف نوعه الحقيقي لا يطابق صورة أو فيديو');
      else if (e.code === 'bad_json') securityEvent(req, 'malformed_body', 'low', 'بيانات مرسلة بصيغة غير صحيحة');
      if (!res.headersSent) send(res, e.status, { error: e.code });
      return;
    }
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: 'server_error' });
  }
});
server.requestTimeout = 0; // رفع فيديوهات حتى ساعة
server.headersTimeout = 60000;
// أوامر الطوارئ من السيرفر نفسه (لمن يملك الوصول للسيرفر فقط)
if (process.argv.includes('--reset-control-key')) { console.log('رقم أمان لوحة المؤسس الجديد: ' + rotateControlKey()); process.exit(0); }
if (process.argv.includes('--unblock-all')) { q('DELETE FROM blocked_visitors').run(); console.log('تم فك حظر كل الأجهزة'); process.exit(0); }
if (process.argv.includes('--show-control-path')) { console.log(CP); process.exit(0); }
startSweep();
server.listen(PORT, HOST, () => {
  console.log(`\n  مجازية — Majazia (الموقع) يعمل على المنفذ ${PORT}`);
  console.log(`  لوحة المؤسس (سرية — لا تشاركها): ${CP}`);
  if (!founderExists()) console.log(`  إنشاء حساب المؤسس (مرة واحدة): ${CP}/setup?token=${SETUP_TOKEN}`);
  console.log(`  الترجمة DeepL: ${DEEPL_KEY ? 'مفعّلة' : 'غير مفعّلة (ضع DEEPL_API_KEY)'}\n`);
});
